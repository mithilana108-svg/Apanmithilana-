(()=>{
'use strict';
try{sessionStorage.removeItem('mithManagedSlugs')}catch(e){}
const products=window.products;           // same array object is edited in place by every script
if(!Array.isArray(products))return;
let lastSig='',busy=false;
const grid=()=>document.getElementById('productGrid');

function variantsOf(x){
 return x.variants&&x.variants.length
  ? x.variants.map(v=>({label:v.name||'Standard',price:Number(v.price),available:Number(v.stock)>0}))
  : [{label:'Standard',price:Number(x.base_price),available:Number(x.stock)>0}];
}
function newProductsButton(){
 const has=products.some(p=>p.cat==='New Products');
 const existing=document.querySelector('[data-filter="New Products"]');
 if(!has){existing?.remove();return}
 if(existing||!document.querySelector('.cat-grid'))return;
 const btn=document.createElement('button');btn.type='button';btn.className='mith-range-card';btn.dataset.filter='New Products';btn.textContent='New Products';
 btn.addEventListener('click',()=>{renderProducts('New Products');document.getElementById('products')?.scrollIntoView({behavior:'smooth'})});
 document.querySelector('.cat-grid').append(btn);
}
function rerender(){
 const overlay=document.getElementById('mithRouteOverlay');
 if(overlay&&overlay.getAttribute('aria-hidden')==='false')return;   // a category page is open; it reads the fresh list when opened
 if(typeof renderProducts==='function')renderProducts('All');
}
async function sync(force){
 if(busy)return;busy=true;
 try{
  const response=await fetch('/api/products?_='+Date.now(),{cache:'no-store'});
  if(!response.ok)return;
  const data=await response.json(),records=data.products||[],hidden=new Set(data.hidden_slugs||[]);
  const sig=JSON.stringify([records.map(x=>[x.slug,x.name,x.description,x.base_price,x.stock,(x.images||[]).map(i=>i.url),x.variants]),[...hidden].sort()]);
  if(!force&&sig===lastSig)return;
  lastSig=sig;
  const active=new Set(records.map(x=>x.slug));
  // 1. Remove products that were created in Admin and have since been deleted/archived,
  //    and built-in products that Admin has archived under the same slug.
  for(let i=products.length-1;i>=0;i--){
   const p=products[i];
   if(p.dbProductId&&!active.has(p.id))products.splice(i,1);
   else if(!p.dbProductId&&hidden.has(p.id)&&!active.has(p.id))products.splice(i,1);
  }
  // 2. Add / update products from the database.
  for(const x of records){
   const images=(x.images||[]).map(i=>i.url).filter(Boolean);
   let found=products.find(p=>p.id===x.slug);
   if(found&&!found.dbProductId){            // built-in product: only refresh its photos
    if(images.length){found.livePhotos=images;found.img=images[0];if(found.variants?.[0])found.variants[0].liveImage=images[0];}
    continue;
   }
   if(!found&&/-[0-9]+$/.test(x.slug)&&products.some(p=>!p.dbProductId&&x.slug.startsWith(p.id+'-')))continue; // size-pack rows of built-in products
   const data2={id:x.slug,name:x.name,desc:x.description||'',cat:'New Products',img:images[0]||'',livePhotos:images,variants:variantsOf(x),dbProductId:x.id};
   if(found)Object.assign(found,data2);else products.push(data2);
  }
  newProductsButton();
  rerender();
 }catch(e){console.warn('Live catalog sync',e)}
 finally{busy=false}
}

/* ---- photo gallery on product cards (swipe or ‹ › buttons) ---- */
const grid2=grid();
function galleries(){
  (grid())?.querySelectorAll('.pm-img,.product-img').forEach(box=>{
   if(box.dataset.galleryReady)return;
   const card=box.closest('.pm-card,.product'),id=card?.dataset.pmId||card?.dataset.mithId,p=products.find(x=>x.id===id),photos=p?.livePhotos||[];
   if(photos.length<2)return;const img=box.querySelector('img');if(!img)return;
   box.dataset.galleryReady='1';box.style.position='relative';let index=0,start=0;img.src=photos[0];
   const count=document.createElement('span');count.textContent='1 / '+photos.length;count.style.cssText='position:absolute;bottom:8px;left:50%;transform:translateX(-50%);background:#ffffffe8;border-radius:12px;padding:2px 8px;z-index:3;font-size:12px';box.append(count);
   const move=d=>{index=(index+d+photos.length)%photos.length;img.src=photos[index];count.textContent=(index+1)+' / '+photos.length};
   box.addEventListener('touchstart',e=>{start=e.touches[0].clientX},{passive:true});box.addEventListener('touchend',e=>{const d=e.changedTouches[0].clientX-start;if(Math.abs(d)>40)move(d<0?1:-1)},{passive:true});
   for(const [label,d,side] of [['‹',-1,'left'],['›',1,'right']]){const b=document.createElement('button');b.type='button';b.textContent=label;b.setAttribute('aria-label',d<0?'Previous photo':'Next photo');b.style.cssText='position:absolute;top:45%;'+side+':4px;z-index:3;background:#ffffffe8;border:0;border-radius:20px;padding:2px 10px;font-size:23px';b.onclick=e=>{e.preventDefault();e.stopPropagation();move(d)};box.append(b)}
  });
 }
 if(grid2){new MutationObserver(galleries).observe(grid2,{childList:true});galleries()}

/* ---- same gallery inside the product detail window ---- */
const origDetail=window.openProductDetail;
if(typeof origDetail==='function'){
 window.openProductDetail=function(id){
  const out=origDetail.apply(this,arguments);
  try{
   const p=products.find(x=>x.id===id),photos=p?.livePhotos||[],img=document.getElementById('detailImage');
   if(!img)return out;
   img.parentElement?.querySelectorAll('.mith-detail-nav').forEach(n=>n.remove());
   if(photos.length<2)return out;
   const box=img.parentElement;box.style.position='relative';let i=0;img.src=photos[0];
   const mk=(label,d,side)=>{const b=document.createElement('button');b.type='button';b.className='mith-detail-nav';b.textContent=label;
    b.style.cssText='position:absolute;top:45%;'+side+':6px;z-index:5;background:#ffffffe8;border:0;border-radius:20px;padding:2px 12px;font-size:24px';
    b.onclick=e=>{e.preventDefault();e.stopPropagation();i=(i+d+photos.length)%photos.length;img.src=photos[i]};box.append(b)};
   mk('‹',-1,'left');mk('›',1,'right');
  }catch(e){}
  return out;
 };
}

/* ---- run after every other script has loaded, then keep in sync ---- */
const start=()=>sync(true);
if(document.readyState==='complete')start();else window.addEventListener('load',start);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)sync(false)});
setInterval(()=>{if(!document.hidden)sync(false)},60000);
})();
