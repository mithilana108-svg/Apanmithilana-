'use strict';
const flavourNames=new Set(['flavourmakhana','flavourmakahna','flavouredmakhana','flavouredmakahna','flavoredmakhana','flavoredmakahna']);
function canonicalCategory(value){const name=value.trim();return flavourNames.has(name.toLowerCase().replace(/[^a-z]/g,''))?'Flavoured Makhana':name}
module.exports={canonicalCategory};
