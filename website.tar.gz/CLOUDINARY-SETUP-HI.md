# Mithilana Cloudinary Admin Photo Upload

1. Cloudinary Free account बनाएं।
2. Render Web Service > Environment में `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` भरें। Secret किसी को न भेजें और GitHub में commit न करें।
3. वेबसाइट Deploy करें। Admin > Products > Manage photos में JPEG/PNG/WebP/AVIF (8MB तक) Upload करें।
4. Front / primary का sort order 0 है; Back 1 है। एक ही sort order की कई सक्रिय फोटो हों तो पुरानी फोटो को Hide करें।
5. Hide करने से फोटो Cloudinary से delete नहीं होती; storage बचाने के लिए बाद में सुरक्षित delete workflow चाहिए।
6. Render Database और Cloudinary setup के बिना Upload काम नहीं करेगा।
7. इस बदलाव का Live Integration Test अभी नहीं हुआ है।
