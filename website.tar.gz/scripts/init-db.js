const fs=require('fs');
const path=require('path');
const {Pool}=require('pg');
const bcrypt=require('bcryptjs');

const RETRYABLE=new Set(['40P01','40001','55P03','57014','57P01','08006','08001','08003','08004','53300','ECONNRESET','ETIMEDOUT']);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

async function runOnce(){
  const pool=new Pool({
    connectionString:process.env.DATABASE_URL,
    ssl:process.env.DB_SSL==='false'?false:{rejectUnauthorized:true},
    connectionTimeoutMillis:10000
  });
  pool.on('error',()=>{});
  let client;
  try{
    client=await pool.connect();
    try{
      await client.query('BEGIN');
      await client.query("SET LOCAL lock_timeout='20s'");
      await client.query('SELECT pg_advisory_xact_lock($1)',[93741521]);
      for(const file of ['schema.sql','migrate-auth-payments.sql','catalog-draft.sql']){
        await client.query(fs.readFileSync(path.join(__dirname,'..',file),'utf8'));
      }
      const email=String(process.env.ADMIN_BOOTSTRAP_EMAIL||'').trim().toLowerCase();
      const password=String(process.env.ADMIN_BOOTSTRAP_PASSWORD||'');
      if(email||password){
        if(!/^\S+@\S+\.\S+$/.test(email)||password.length<12||Buffer.byteLength(password)>72)throw Error('Admin bootstrap needs an email and a password of at least 12 characters and at most 72 UTF-8 bytes.');
        const hash=await bcrypt.hash(password,12);
        await client.query(`INSERT INTO admins(email,password_hash) VALUES($1,$2)
          ON CONFLICT(email) DO NOTHING`,[email,hash]);
      }
      await client.query('COMMIT');
    }catch(error){await client.query('ROLLBACK').catch(()=>{});throw error}
  }finally{
    if(client)client.release();
    await pool.end().catch(()=>{});
  }
}

async function main(){
  if(!process.env.DATABASE_URL)throw Error('DATABASE_URL is required before starting the website.');
  const maxAttempts=8;
  let lastError;
  for(let attempt=1;attempt<=maxAttempts;attempt++){
    try{
      await runOnce();
      console.log('Database schema and draft catalog are ready.');
      return;
    }catch(error){
      lastError=error;
      if(!RETRYABLE.has(error.code))throw error; // real problem (config/SQL): stop and show it
      const wait=Math.min(1000*attempt+Math.floor(Math.random()*1500),8000);
      console.warn(`Database setup attempt ${attempt}/${maxAttempts} hit a temporary error (${error.code||error.message}); retrying in ${wait}ms...`);
      await sleep(wait);
    }
  }
  // Temporary database contention that never cleared. The schema is idempotent and was applied by earlier
  // deploys, so start the website instead of failing the whole deploy.
  console.warn('Database setup could not finish after several retries ('+(lastError&&(lastError.code||lastError.message))+'). Starting the website with the existing schema.');
}
main().catch(error=>{console.error('Database initialization failed:',error.message);process.exitCode=1});
