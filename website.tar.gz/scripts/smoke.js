const base=process.argv[2]||process.env.BASE_URL;
if(!base){console.error('Usage: npm run smoke -- https://YOUR-SITE.onrender.com');process.exit(2)}
(async()=>{
  for(const route of ['/api/health','/api/public-config','/api/products']){
    const r=await fetch(new URL(route,base),{signal:AbortSignal.timeout(10000)});
    const data=await r.json();
    if(!r.ok||!data.ok&&route!=='/api/public-config')throw Error(`${route}: ${r.status} ${JSON.stringify(data)}`);
    console.log(route,route==='/api/products'?`${data.products.length} active products`:JSON.stringify(data));
  }
})().catch(e=>{console.error('Smoke check failed:',e.message);process.exitCode=1});
