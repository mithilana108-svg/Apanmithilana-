// Local tests only: database/provider behavior is mocked; no real orders or messages.
const assert=require('node:assert/strict');
const crypto=require('node:crypto');
process.env.NODE_ENV='test';process.env.DATABASE_URL='postgres://unused:unused@localhost/unused';
process.env.JWT_SECRET='customer-test-secret-'.repeat(3);
process.env.ADMIN_JWT_SECRET='admin-test-secret-'.repeat(3);
process.env.PUBLIC_ORIGIN='https://shop.example';
process.env.META_APP_SECRET='test-meta-secret';
const jwt=require('jsonwebtoken');
const bcrypt=require('bcryptjs');
let adminActive=true,adminHash=bcrypt.hashSync('test-password-123',4);
const {Pool}=require('pg');
Pool.prototype.query=async function(sql){
 if(sql.includes('SELECT is_active,password_hash FROM admins'))return {rowCount:1,rows:[{is_active:adminActive,password_hash:adminHash}]};
 return {rowCount:0,rows:[]};
};
const {app,pool,secureEqual,verifyMetaSignature,priceCart,finalizeCapturedPayment}=require('../server');
const id='11111111-1111-4111-8111-111111111111';
let checks=0;
const ok=(condition)=>{assert(condition);checks++};
(async()=>{
 const server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));
 const base='http://127.0.0.1:'+server.address().port;
 try{
  for(const route of ['/api/me','/api/orders','/api/admin/products','/api/admin/orders','/api/admin/offers']){
   const r=await fetch(base+route);ok(r.status===401);
  }
  let r=await fetch(base+'/api/me',{headers:{Origin:'https://evil.example'}});ok(r.status===403);ok(!r.headers.has('access-control-allow-origin'));
  r=await fetch(base+'/api/public-config',{headers:{Origin:'https://shop.example'}});ok(r.status===200);ok(r.headers.get('access-control-allow-origin')==='https://shop.example');
  r=await fetch(base+'/');const body=await r.text();const csp=r.headers.get('content-security-policy');ok(!csp.split('style-src')[0].includes('unsafe-inline'));ok(!/<script\b[^>]*>\s*[^<\s]/i.test(body));ok(!/\bonclick\s*=/i.test(body));
  for(const route of ['/server.js','/schema.sql','/.env','/package.json','/scripts/create-admin.js']){r=await fetch(base+route);ok(r.status===404)}
  r=await fetch(base+'/api/auth/google',{method:'POST',headers:{'Content-Type':'application/json'},body:'{"sensitive":"private-test",broken'});ok(r.status===400);ok(!(await r.text()).includes('private-test'));
  r=await fetch(base+'/webhook',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});ok(r.status===403);
  ok(secureEqual('abc','abc'));ok(!secureEqual('abc','abd'));ok(!secureEqual('é','a'));ok(!secureEqual(undefined,'abc'));
  const raw=Buffer.from('{"object":"whatsapp_business_account"}');
  const sig=crypto.createHmac('sha256',process.env.META_APP_SECRET).update(raw).digest('hex');
  ok(verifyMetaSignature({headers:{'x-hub-signature-256':'sha256='+sig},rawBody:raw}));
  ok(!verifyMetaSignature({headers:{'x-hub-signature-256':'sha256='+sig+'garbage'},rawBody:raw}));
  const q={query:async()=>({rowCount:1,rows:[{id,name:'test',base_price:'12.50',stock:10}]})};
  const priced=await priceCart(q,[{product_id:id,quantity:2}],null,false);ok(priced.totalP===2500);
  for(const quantity of [1.9,true,0,-1,101]){await assert.rejects(priceCart(q,[{product_id:id,quantity}],null,false));checks++}
  const adminToken=()=>jwt.sign({type:'admin',sub:id,passwordVersion:crypto.createHash('sha256').update(adminHash).digest('hex')},process.env.ADMIN_JWT_SECRET,{algorithm:'HS256',issuer:'mithilana',expiresIn:'1h'});
  const goodToken=adminToken();
  r=await fetch(base+'/api/admin/products',{headers:{Authorization:'Bearer '+goodToken}});ok(r.status===200);
  adminActive=false;r=await fetch(base+'/api/admin/products',{headers:{Authorization:'Bearer '+goodToken}});ok(r.status===401);adminActive=true;
  adminHash=bcrypt.hashSync('changed-password-123',4);r=await fetch(base+'/api/admin/products',{headers:{Authorization:'Bearer '+goodToken}});ok(r.status===401);
  const customerToken=jwt.sign({type:'customer',sub:id},process.env.JWT_SECRET,{issuer:'mithilana',expiresIn:'1h'});
  r=await fetch(base+'/api/admin/products',{headers:{Authorization:'Bearer '+customerToken}});ok(r.status===401);
  const order={id,status:'pending_payment',payment_status:'pending',total_amount:'25.00'};
  let updates=0;
  pool.connect=async()=>({release(){},query:async sql=>{if(sql.startsWith('SELECT * FROM orders'))return {rowCount:1,rows:[order]};if(sql.startsWith('UPDATE'))updates++;return {rowCount:1,rows:[]}}});
  const payment={id:'pay_test',order_id:'order_test',status:'captured',amount:2500,currency:'INR'};
  for(const change of [{amount:1},{currency:'USD'},{status:'authorized'},{order_id:'other_order'}]){await assert.rejects(finalizeCapturedPayment('order_test','pay_test',{...payment,...change}));checks++}
  ok(updates===0);await finalizeCapturedPayment('order_test','pay_test',payment);ok(updates===2);
  const html=require('node:fs').readFileSync(require('node:path').join(__dirname,'../assets/secure-index-1.js'),'utf8');
  const vm=require('node:vm'),context={window:{},document:{addEventListener(){}},URL,location:{href:base}};vm.createContext(context);vm.runInContext(html,context);
  ok(context.htmlEscape('<img onerror="alert(1)">').startsWith('&lt;img'));ok(context.safeImageUrl('javascript:alert(1)')==='');
  console.log(`${checks} security assertions passed.`);
 }finally{server.close();server.closeAllConnections();await pool.end()}
})().catch(e=>{console.error(e);process.exitCode=1});
