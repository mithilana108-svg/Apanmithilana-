"""Extract embedded media from index.html for the deployed ZIP; keep standalone HTML separate."""
from pathlib import Path
import base64
import hashlib
import re

root = Path(__file__).resolve().parents[1]
html = root / 'index.html'
text = html.read_text()
assets = root / 'assets'
assets.mkdir(exist_ok=True)
suffixes = {'jpeg': 'jpg', 'jpg': 'jpg', 'png': 'png', 'webp': 'webp', 'gif': 'gif', 'svg+xml': 'svg', 'otf': 'otf', 'woff': 'woff', 'woff2': 'woff2', 'ttf': 'ttf'}
pattern = re.compile(r'data:(image|font)/([\w+.-]+);base64,([A-Za-z0-9+/=]+)')
found = {}

def replace(match):
    kind, mime, value = match.groups()
    ext = suffixes.get(mime)
    if not ext:
        return match.group(0)
    raw = base64.b64decode(value, validate=True)
    digest = hashlib.sha256(raw).hexdigest()[:20]
    name = f'{kind}-{digest}.{ext}'
    file = assets / name
    if not file.exists():
        file.write_bytes(raw)
    found[name] = len(raw)
    return '/assets/' + name

converted = pattern.sub(replace, text)
html.write_text(converted)
print(f'{len(found)} distinct assets, {sum(found.values())} media bytes; HTML {len(converted.encode())} bytes')
