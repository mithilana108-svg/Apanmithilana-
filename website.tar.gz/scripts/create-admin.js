const {Pool}=require('pg');
const bcrypt=require('bcryptjs');
(async()=>{
  const [email,password]=process.argv.slice(2);
  if(!email||!password){console.error('Usage: node scripts/create-admin.js email password');process.exit(1);}
  if(password.length<12 || Buffer.byteLength(password)>72){console.error('Password must have at least 12 characters and at most 72 UTF-8 bytes.');process.exit(1);}
  if(!process.env.DATABASE_URL){console.error('DATABASE_URL is required');process.exit(1);}
  const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DB_SSL==='false'?false:{rejectUnauthorized:true}});
  try{
    const hash=await bcrypt.hash(password,12);
    await pool.query(`INSERT INTO admins(email,password_hash) VALUES($1,$2)
      ON CONFLICT(email) DO UPDATE SET password_hash=EXCLUDED.password_hash,is_active=true`,[email.toLowerCase(),hash]);
    console.log('Admin created/updated:',email.toLowerCase());
  }finally{await pool.end();}
})();
