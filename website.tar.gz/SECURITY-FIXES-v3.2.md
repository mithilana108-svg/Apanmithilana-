# v3.2 - security & bug-fix pass (12 Oct 2026)

## Fixed
1. Storefront never showed/removed admin products reliably: rewrote assets/mith-catalog-live-fix.js (runs after all scripts, no sessionStorage, deleted products vanish, multi-photo gallery on cards and in detail view).
2. Language script set new products' name to "undefined" (assets/secure-index-20.js).
3. Inline script in index.html was blocked by the site's own CSP; moved to assets/mith-auth-state-fix.js.
4. Stored-HTML injection: admin-entered product name/description/category/size labels are now HTML-escaped on the storefront (secure-index-3/31/5.js).
5. /assets cache: scripts were cached for 1 year "immutable"; now only content-hashed images/fonts are, everything else revalidates (server.js).
6. Unpaid online orders held stock forever (stock-lockout abuse): they are now auto-cancelled after 60 min and stock is restored (server.js, expireUnpaidOrders).
7. Admin site-content image fields only accept /assets paths, https links or small data:image (server.js).
8. /api/products also returns hidden_slugs so archived built-in products can be hidden.
9. Checkout now requires accepting Terms / Privacy / Refund policy (checkbox); Terms & Conditions page added (terms.html) and linked in the footer.
10. Privacy and Refund policies corrected (no "test mode", no WhatsApp login, Razorpay/PIN lookup/WhatsApp disclosed).

## You must still do
- Fill the [..यहाँ भरें] seller/FSSAI/grievance-officer details at the bottom of terms.html, privacy.html and refund-cancellation.html.
- Make the GitHub repository Private.
- Run `npm audit` on your machine / Render build and update dependencies if it reports problems.
- Known, not changed: no refund API for online payments, coupons have no per-user usage limit, customer login token lasts 30 days.
