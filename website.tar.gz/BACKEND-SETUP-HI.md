# Mithilana — Production Backend v3

इस package में uploaded v41 frontend को बदला नहीं गया है। `index.html` उसी uploaded file का frontend है।

## Production protections
- PostgreSQL-backed OTP (RAM-only OTP नहीं)
- Customer JWT authentication
- Separate admin JWT + bcrypt password hashes
- Product archive instead of destructive delete
- Server-side product/price/stock calculation
- Transaction + row locking during orders
- Immutable order-item price/name snapshots
- Separate offers table
- Order status history/audit
- WhatsApp webhook GET/POST foundation
- Helmet, CORS allow-list, API/OTP rate limits
- Parameterized PostgreSQL queries
- Secrets only through Render Environment Variables
- Health endpoint: `/api/health`

## Render setup
1. Create PostgreSQL and Web Service.
2. Run `schema.sql` once against the database.
3. Add all variables from `.env.example` in Render.
4. Build command: `npm install`
5. Start command: `npm start`
6. Create admin: `node scripts/create-admin.js your@email.com "STRONG-PASSWORD"`

## Important
The frontend currently calls `/api/auth/request-otp` and `/api/auth/verify-otp`; those routes are preserved.

Razorpay is deliberately not enabled in this build. COD remains the safe default. Razorpay can be added later with server-side order creation, signature verification, and webhooks without changing the catalog/order snapshot model.

- WhatsApp webhook production में `META_APP_SECRET` से signature verify करता है.
- Order status बदलने पर optional `WHATSAPP_ORDER_STATUS_TEMPLATE` template भेजा जा सकता है; template configure न होने पर order process नहीं रुकता.
- Old orders में `order_items.product_name` और `unit_price` snapshot रहते हैं, इसलिए बाद में product price/name बदलने से पुराने order totals नहीं बदलते.
- Product delete API destructive DELETE नहीं करता; product archive/inactive करता है.
