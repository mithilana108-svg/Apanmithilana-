-- Catalog v2: preserve old records and order snapshots; run in init-db transaction.
CREATE TABLE IF NOT EXISTS schema_migrations (version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());
ALTER TABLE products ADD COLUMN IF NOT EXISTS version integer NOT NULL DEFAULT 0;
ALTER TABLE product_variants ADD COLUMN IF NOT EXISTS version integer NOT NULL DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS category varchar(120) NOT NULL DEFAULT 'Other Products';
ALTER TABLE products ADD COLUMN IF NOT EXISTS quality varchar(120) NOT NULL DEFAULT '';
ALTER TABLE products ADD COLUMN IF NOT EXISTS legacy_parent_id uuid REFERENCES products(id);
ALTER TABLE product_variants ADD COLUMN IF NOT EXISTS compare_at_price numeric(12,2) CHECK(compare_at_price IS NULL OR compare_at_price>=0);
ALTER TABLE product_variants ADD COLUMN IF NOT EXISTS quality varchar(120) NOT NULL DEFAULT '';
ALTER TABLE product_variants ADD COLUMN IF NOT EXISTS legacy_product_id uuid UNIQUE REFERENCES products(id);
ALTER TABLE product_images ADD COLUMN IF NOT EXISTS variant_id uuid REFERENCES product_variants(id) ON DELETE RESTRICT;
ALTER TABLE product_images ADD COLUMN IF NOT EXISTS source_image_id uuid UNIQUE;
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS variant_id uuid REFERENCES product_variants(id) ON DELETE RESTRICT;
ALTER TABLE order_items ADD COLUMN IF NOT EXISTS variant_name text;
ALTER TABLE order_items ALTER COLUMN variant_name TYPE text;
ALTER TABLE order_items ALTER COLUMN product_name TYPE text;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS idempotency_key varchar(100);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS request_hash char(64);
CREATE UNIQUE INDEX IF NOT EXISTS idx_order_idempotency ON orders(customer_id,idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_images_variant_active ON product_images(variant_id,is_active,sort_order);
CREATE TABLE IF NOT EXISTS inventory_history (
 id bigserial PRIMARY KEY,variant_id uuid NOT NULL REFERENCES product_variants(id),delta integer NOT NULL,
 stock_after integer NOT NULL CHECK(stock_after>=0),reason varchar(500) NOT NULL,
 admin_id uuid REFERENCES admins(id),order_id uuid REFERENCES orders(id),created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS catalog_history (
 id bigserial PRIMARY KEY,admin_id uuid REFERENCES admins(id),entity_type varchar(30) NOT NULL,
 entity_id uuid NOT NULL,action varchar(40) NOT NULL,before_data jsonb,after_data jsonb,created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS revoked_sessions (token_hash char(64) PRIMARY KEY, expires_at timestamptz NOT NULL);
DO $$
DECLARE parent record; pack record; variant record; item record;
BEGIN
 IF EXISTS(SELECT 1 FROM schema_migrations WHERE version='catalog-v2') THEN RETURN; END IF;
 FOR item IN SELECT * FROM (VALUES
 ('classic','Flavoured Makhana'),('plain','Flavoured Makhana'),('peri','Flavoured Makhana'),('tandoori','Flavoured Makhana'),
 ('raisins','Dry Fruits'),('almonds','Dry Fruits'),('cashews','Dry Fruits'),('kumrauri','Kumrauri'),('adhori','Adhori'),
 ('flav-combo','Combo'),('adho-kum','Combo'),('premium-raw','Phool Makhana'),('normal-raw','Phool Makhana'),
 ('tangy-tomato','Flavoured Makhana'),('pudina-mint','Flavoured Makhana'),('chocolate','Flavoured Makhana'),('jaggery','Flavoured Makhana'),
 ('saree','Accessories'),('paag','Accessories'),('dupatta','Accessories'),('shawl','Accessories'),('gamchha','Accessories'),
 ('handbag','Accessories'),('carry-bag','Accessories'),('phone-cover','Accessories'),('mithila-painting','Accessories')
 ) AS mapping(slug,category) LOOP
  SELECT * INTO parent FROM products WHERE slug=item.slug;
  IF NOT FOUND THEN CONTINUE; END IF;
  UPDATE products SET category=item.category WHERE id=parent.id;
  FOR variant IN SELECT * FROM product_variants WHERE product_id=parent.id ORDER BY sort_order,id LOOP
   SELECT * INTO pack FROM products WHERE slug=parent.slug||'-'||variant.sort_order::text;
   IF FOUND THEN
    -- The old checkout sold this numbered pack; preserve its actual price/stock/visibility.
    UPDATE product_variants SET price=pack.base_price,compare_at_price=pack.compare_at_price,
      stock=pack.stock,is_active=pack.is_active,legacy_product_id=pack.id WHERE id=variant.id;
    UPDATE products SET legacy_parent_id=parent.id WHERE id=pack.id;
    INSERT INTO product_images(product_id,variant_id,image_url,alt_text,sort_order,is_active,created_at,source_image_id)
      SELECT parent.id,variant.id,image_url,alt_text,sort_order,is_active,created_at,id FROM product_images
      WHERE product_id=pack.id ON CONFLICT(source_image_id) DO NOTHING;
    UPDATE order_items SET variant_id=variant.id,variant_name=variant.name WHERE product_id=pack.id AND variant_id IS NULL;
   END IF;
  END LOOP;
 END LOOP;
 -- Administrator-created products without variants receive one real purchasable pack.
 INSERT INTO product_variants(product_id,name,price,compare_at_price,stock,sort_order,is_active)
 SELECT p.id,'Standard',p.base_price,p.compare_at_price,p.stock,0,p.is_active FROM products p
 WHERE p.legacy_parent_id IS NULL AND NOT EXISTS(SELECT 1 FROM product_variants v WHERE v.product_id=p.id);
 -- Only unambiguous historical parent orders can be linked automatically.
 UPDATE order_items oi SET variant_id=v.id,variant_name=v.name FROM product_variants v
 WHERE oi.product_id=v.product_id AND oi.variant_id IS NULL
 AND (SELECT count(*) FROM product_variants x WHERE x.product_id=v.product_id)=1;
 -- Preserve the original approved photo galleries, only where the old database still has its untouched bundled seed image.
 FOR item IN SELECT * FROM (VALUES ('peri','/assets/image-89ce7656934cf9c7d484.webp','/assets/product-images/peri-front.jpg','/assets/product-images/peri-ingredients.jpg','/assets/product-images/peri-back.jpg'),
('chocolate','/assets/image-a49a937df4b51b50b508.webp','/assets/product-images/chocolate-front.jpg','/assets/product-images/chocolate-ingredients.jpg','/assets/product-images/chocolate-back.jpg'),
('pudina-mint','/assets/image-784db2ff5d3ed5ece850.webp','/assets/product-images/pudina-mint-front.jpg','/assets/product-images/pudina-mint-ingredients.jpg','/assets/product-images/pudina-mint-back.jpg'),
('tangy-tomato','/assets/image-e581362ef4d8bdd4e0e1.webp','/assets/product-images/tangy-tomato-front.jpg','/assets/product-images/tangy-tomato-ingredients.jpg','/assets/product-images/tangy-tomato-back.jpg'),
('adhori','/assets/image-083a6f3cea4dbe1f833c.webp','/assets/product-images/adhori-front.jpg','/assets/product-images/adhori-ingredients.jpg',NULL),
('kumrauri','/assets/image-85bad100c2af50a6fc0c.webp','/assets/product-images/kumrauri-front.jpg','/assets/product-images/kumrauri-ingredients.jpg',NULL)) AS originals(slug,seed,front,ingredients,back) LOOP
  SELECT * INTO parent FROM products WHERE slug=item.slug AND legacy_parent_id IS NULL;
  IF NOT FOUND THEN CONTINUE; END IF;
  UPDATE product_images SET image_url=item.front WHERE product_id=parent.id AND variant_id IS NULL AND image_url=item.seed;
  IF FOUND THEN
   IF item.ingredients IS NOT NULL THEN INSERT INTO product_images(product_id,image_url,sort_order) SELECT parent.id,item.ingredients,1 WHERE NOT EXISTS(SELECT 1 FROM product_images WHERE product_id=parent.id AND variant_id IS NULL AND sort_order=1); END IF;
   IF item.back IS NOT NULL THEN INSERT INTO product_images(product_id,image_url,sort_order) SELECT parent.id,item.back,2 WHERE NOT EXISTS(SELECT 1 FROM product_images WHERE product_id=parent.id AND variant_id IS NULL AND sort_order=2); END IF;
  END IF;
 END LOOP;
 -- Give every pack its own photo rows. Never fall back to a different pack's newly uploaded photo.
 INSERT INTO product_images(product_id,variant_id,image_url,alt_text,sort_order,is_active,created_at)
 SELECT v.product_id,v.id,i.image_url,i.alt_text,i.sort_order,i.is_active,i.created_at FROM product_variants v JOIN product_images i ON i.product_id=v.product_id AND i.variant_id IS NULL
 WHERE NOT EXISTS(SELECT 1 FROM product_images existing WHERE existing.variant_id=v.id AND existing.sort_order=i.sort_order);
 DELETE FROM product_images i WHERE variant_id IS NULL AND EXISTS(SELECT 1 FROM products p WHERE p.id=i.product_id AND p.legacy_parent_id IS NULL);
 INSERT INTO schema_migrations(version) VALUES('catalog-v2');
END $$;
ALTER TABLE product_images ADD COLUMN IF NOT EXISTS cloud_public_id text;
CREATE TABLE IF NOT EXISTS image_cleanup_jobs (
 id bigserial PRIMARY KEY,image_url text NOT NULL,public_id text,state varchar(20) NOT NULL DEFAULT 'pending',
 attempts integer NOT NULL DEFAULT 0,next_attempt_at timestamptz NOT NULL DEFAULT now(),last_error varchar(500)
);
CREATE TABLE IF NOT EXISTS retired_asset_urls (image_url text PRIMARY KEY,retired_at timestamptz NOT NULL DEFAULT now());

-- Category covers are independent of pack photos; preserve saved edits on redeploy.
CREATE TABLE IF NOT EXISTS category_covers (category varchar(120) PRIMARY KEY,display_name varchar(120) NOT NULL,image_url text,cloud_public_id text,sort_order integer NOT NULL DEFAULT 0,version integer NOT NULL DEFAULT 0);
INSERT INTO category_covers(category,display_name,image_url,sort_order) VALUES('Phool Makhana','Phool Makhana','/assets/image-1382bfa0b63b2f947ab0.webp',0) ON CONFLICT DO NOTHING;
INSERT INTO category_covers(category,display_name,image_url,sort_order) VALUES('Flavoured Makhana','Flavoured Makhana','/assets/image-89ce7656934cf9c7d484.webp',1) ON CONFLICT DO NOTHING;
INSERT INTO category_covers(category,display_name,image_url,sort_order) VALUES('Dry Fruits','Dry Fruits','/assets/image-e8bc367d1825b47a7521.webp',2) ON CONFLICT DO NOTHING;
INSERT INTO category_covers(category,display_name,image_url,sort_order) VALUES('Adhori','Adhori','/assets/image-83368e6fceea64ea7202.webp',3) ON CONFLICT DO NOTHING;
INSERT INTO category_covers(category,display_name,image_url,sort_order) VALUES('Kumrauri','Kumrauri','/assets/image-b6455b9f3d257a20c728.webp',4) ON CONFLICT DO NOTHING;
INSERT INTO category_covers(category,display_name,image_url,sort_order) VALUES('Combo','Mithila Combos','/assets/image-908b472f37a97a938468.webp',5) ON CONFLICT DO NOTHING;
INSERT INTO category_covers(category,display_name,image_url,sort_order) VALUES('Accessories','Mithilana Accessories','/assets/image-6d6f5066f6f788c12260.webp',6) ON CONFLICT DO NOTHING;

CREATE TABLE IF NOT EXISTS home_slides(id uuid PRIMARY KEY DEFAULT gen_random_uuid(),name varchar(200) NOT NULL,image_url text,cloud_public_id text,sort_order integer NOT NULL DEFAULT 0,is_active boolean NOT NULL DEFAULT true,version integer NOT NULL DEFAULT 0);
DO $$ BEGIN
IF NOT EXISTS(SELECT 1 FROM schema_migrations WHERE version='home-slider-v1') THEN
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Classic Butter Makhana','/assets/image-784db2ff5d3ed5ece850.webp',0);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Plain Salted Makhana','/assets/image-a49a937df4b51b50b508.webp',1);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Peri Peri Makhana','/assets/image-89ce7656934cf9c7d484.webp',2);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Tandoori Makhana','/assets/image-e581362ef4d8bdd4e0e1.webp',3);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Golden Raisins (Kishmish)','/assets/image-5f025821f095c5feeb6b.webp',4);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Golden Almonds (Badam)','/assets/image-e9021e31ef02171107f4.webp',5);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Golden Cashews (Kaju)','/assets/image-ea562493528ba72134c8.webp',6);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Authentic Mithila Kumrauri','/assets/image-85bad100c2af50a6fc0c.webp',7);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Authentic Mithila Adhori','/assets/image-083a6f3cea4dbe1f833c.webp',8);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Flavoured Makhana Combo','/assets/image-0d5363c326cd780c7550.webp',9);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Adhori + Kumrauri Combo','/assets/image-908b472f37a97a938468.webp',10);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Premium Raw Makhana','/assets/image-a637c9309447c745639e.webp',11);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('22 Carat / Normal Raw Makhana','/assets/image-a49a937df4b51b50b508.webp',12);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Tangy Tomato Makhana','/assets/image-e581362ef4d8bdd4e0e1.webp',13);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Pudina Mint Makhana','/assets/image-784db2ff5d3ed5ece850.webp',14);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Chocolate Makhana','/assets/image-a49a937df4b51b50b508.webp',15);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Jaggery Makhana','/assets/image-a637c9309447c745639e.webp',16);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Madhubani Printed Saree','/assets/image-47d16448b8de72adb58b.webp',17);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Madhubani Printed Paag','/assets/image-2730a3150c13bc51ee4c.webp',18);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Madhubani Printed Dupatta','/assets/image-3f0d5827f2f4b8fae220.webp',19);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Madhubani Printed Shawl','/assets/image-58fecd16c2aa933226e6.webp',20);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Madhubani Printed Gamchha','/assets/image-353d21121c75973f6b0d.webp',21);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Madhubani Handbag','/assets/image-f4b999315b081297d98f.webp',22);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Madhubani Carry Bag','/assets/image-228f58034ddf8d9ec609.webp',23);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Madhubani Phone Cover','/assets/image-5df72cdd98d69f0f9b8b.webp',24);
INSERT INTO home_slides(name,image_url,sort_order) VALUES('Mithilana Mithila Painting (Trial)','/assets/image-f6ba822b085fb60ddde3.svg',25);
INSERT INTO schema_migrations(version) VALUES('home-slider-v1');
END IF; END $$;

ALTER TABLE image_cleanup_jobs ADD COLUMN IF NOT EXISTS resource_type varchar(10) NOT NULL DEFAULT 'image';
CREATE TABLE IF NOT EXISTS about_media (id uuid PRIMARY KEY DEFAULT gen_random_uuid(),section varchar(10) NOT NULL CHECK(section IN ('company','culture')),kind varchar(10) NOT NULL CHECK(kind IN ('image','video')),name varchar(200) NOT NULL,image_url text NOT NULL,cloud_public_id text,sort_order integer NOT NULL DEFAULT 0,version integer NOT NULL DEFAULT 0);
DO $$ BEGIN
IF NOT EXISTS(SELECT 1 FROM schema_migrations WHERE version='about-media-v1') THEN
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 1','/assets/image-dc783cf16331a92eb45e.webp',0);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 2','/assets/image-ed519b2d00644ef839cf.webp',1);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 3','/assets/image-b9ff0dd137fca2652dee.webp',2);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 4','/assets/image-41eaeb148ef64c9381ba.webp',3);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 5','/assets/image-0e990a6661d5bd0717b0.webp',4);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 6','/assets/image-929a70d574a40b273ca1.webp',5);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 7','/assets/image-597074d1f1d81a4ad977.webp',6);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 8','/assets/image-25f45bf143fb6150d08c.webp',7);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 9','/assets/image-ee0d7c2cc43567354b43.webp',8);
INSERT INTO about_media(section,kind,name,image_url,sort_order) VALUES('culture','image','Mithila culture 10','/assets/image-be9839de27dbfc92f281.webp',9);
INSERT INTO schema_migrations(version) VALUES('about-media-v1');
END IF; END $$;

-- Fix the explicit flavour spelling aliases without merging arbitrary custom categories.
DO $$ DECLARE alias record; BEGIN
IF NOT EXISTS(SELECT 1 FROM schema_migrations WHERE version='flavour-category-names-v1') THEN
FOR alias IN SELECT * FROM category_covers WHERE category<>'Flavoured Makhana' AND regexp_replace(lower(category),'[^a-z]','','g') IN ('flavourmakhana','flavourmakahna','flavouredmakhana','flavouredmakahna','flavoredmakhana','flavoredmakahna') ORDER BY version DESC LOOP
 UPDATE category_covers SET display_name='Flavoured Makhana',image_url=alias.image_url,cloud_public_id=alias.cloud_public_id,version=version+1 WHERE category='Flavoured Makhana' AND version=0 AND alias.version>0;
END LOOP;
UPDATE products SET category='Flavoured Makhana',version=version+1,updated_at=clock_timestamp() WHERE category<>'Flavoured Makhana' AND regexp_replace(lower(category),'[^a-z]','','g') IN ('flavourmakhana','flavourmakahna','flavouredmakhana','flavouredmakahna','flavoredmakhana','flavoredmakahna');
INSERT INTO schema_migrations(version) VALUES('flavour-category-names-v1');
END IF; END $$;
