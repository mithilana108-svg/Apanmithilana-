const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const path = require('path');
const adminOrderEmail = require('./admin-order-email');

const app = express();
const PORT = Number(process.env.PORT || 10000);
const ROOT = __dirname;

const isProd = process.env.NODE_ENV === 'production';
const DATABASE_URL = process.env.DATABASE_URL || '';
const JWT_SECRET = process.env.JWT_SECRET || '';
const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET || JWT_SECRET;
const PUBLIC_ORIGIN = (process.env.PUBLIC_ORIGIN || (process.env.RENDER_EXTERNAL_HOSTNAME ? 'https://'+process.env.RENDER_EXTERNAL_HOSTNAME : '')).replace(/\/+$/, '');
const APP_MODE = process.env.APP_MODE || 'test';
const META_ACCESS_TOKEN = process.env.META_ACCESS_TOKEN || '';
const META_PHONE_NUMBER_ID = process.env.META_PHONE_NUMBER_ID || '';
const META_GRAPH_VERSION = process.env.META_GRAPH_VERSION || 'v25.0';
const WHATSAPP_VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN || '';
const WHATSAPP_SUPPORT_NUMBER = process.env.WHATSAPP_SUPPORT_NUMBER || '';
const META_APP_SECRET = process.env.META_APP_SECRET || '';
const WHATSAPP_ORDER_STATUS_TEMPLATE = process.env.WHATSAPP_ORDER_STATUS_TEMPLATE || '';
const WHATSAPP_ORDER_TEMPLATE_LANGUAGE = process.env.WHATSAPP_ORDER_TEMPLATE_LANGUAGE || 'en_US';
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || '';
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || '';
const RAZORPAY_WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || '';
// Seconds before a paid/COD order is auto-confirmed. 0 turns auto-confirm off (admin confirms by hand).
const AUTO_CONFIRM_SECONDS = Math.max(0, Math.floor(Number(process.env.AUTO_CONFIRM_SECONDS ?? 5)) || 0);
// Content-Security-Policy mode: enforce (default) | report-only | off.
const CSP_MODE = process.env.CSP_MODE || 'enforce';

if (isProd && (!JWT_SECRET || !ADMIN_JWT_SECRET || JWT_SECRET === ADMIN_JWT_SECRET || !DATABASE_URL)) throw new Error('Production requires DATABASE_URL and distinct customer/admin JWT secrets.');
if (isProd && (Buffer.byteLength(JWT_SECRET)<32 || Buffer.byteLength(ADMIN_JWT_SECRET)<32)) throw new Error('Production JWT secrets must each contain at least 32 bytes.');
if (isProd && CSP_MODE !== 'enforce') throw new Error('Production requires CSP_MODE=enforce.');
if (!['test','live'].includes(APP_MODE)) throw new Error('APP_MODE must be test or live.');
if (APP_MODE==='live' && process.env.LIVE_ORDERS_ENABLED!=='true') throw new Error('Set LIVE_ORDERS_ENABLED=true after completing live checkout tests.');
if (APP_MODE==='live' && (!GOOGLE_CLIENT_ID || !PUBLIC_ORIGIN))
  throw new Error('Live mode requires Google Client ID and public origin.');
if (!GOOGLE_CLIENT_ID) console.warn('WARNING: GOOGLE_CLIENT_ID is not set. Google is the only login, so customers cannot log in or order until it is set.');
if (RAZORPAY_KEY_ID && !RAZORPAY_KEY_ID.startsWith(APP_MODE==='live'?'rzp_live_':'rzp_test_'))
  throw new Error('Razorpay key mode does not match APP_MODE.');


const pool = DATABASE_URL ? new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.DB_SSL === 'false' ? false : { rejectUnauthorized: true },
  max: Number(process.env.DB_POOL_MAX || 10),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
}) : null;

app.set('trust proxy', 1);
app.disable('x-powered-by');

const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'", 'https://accounts.google.com', 'https://checkout.razorpay.com'],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://accounts.google.com'],
  imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
  fontSrc: ["'self'", 'data:'],
  connectSrc: ["'self'", 'https://accounts.google.com', 'https://api.razorpay.com', 'https://lumberjack.razorpay.com'],
  frameSrc: ['https://accounts.google.com', 'https://api.razorpay.com', 'https://checkout.razorpay.com'],
  objectSrc: ["'none'"],
  baseUri: ["'self'"],
  formAction: ["'self'"],
  frameAncestors: ["'self'"]
};
app.use(helmet({
  contentSecurityPolicy: CSP_MODE === 'off' ? false : { useDefaults: false, reportOnly: CSP_MODE === 'report-only', directives: cspDirectives },
  // Google Identity Services popup must communicate its result to this page.
  crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));
app.use(cors({
  origin(origin, cb) {
    if (!origin || origin === PUBLIC_ORIGIN) return cb(null, true);
    return cb(publicError('CORS origin not allowed.', 403));
  },
  credentials: true
}));
app.use(express.json({
  limit: '100kb',
  verify: (req, res, buf) => { if (req.path === '/webhook' || req.path === '/api/payments/razorpay/webhook') req.rawBody = Buffer.from(buf); }
}));
app.use(express.urlencoded({ extended: false, limit: '50kb' }));

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: 'draft-7',
  legacyHeaders: false
});
// Login is Google-only; this limits repeated login attempts per IP.
const googleLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again later.' }
});
app.use('/api/', apiLimiter);
// Personal data must never be cached by browsers or proxies.
app.use('/api', (req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
// Every ":id" route parameter in this app is a UUID. Anything else is a plain 404, not a database error.
app.param('id', (req, res, next, id) => UUID_RE.test(String(id)) ? next() : res.status(404).json({ error: 'Not found.' }));

function normalizePhone(value) {
  const digits = String(value || '').replace(/\D/g, '');
  if (digits.length === 10) return '91' + digits;
  if (digits.length >= 11 && digits.length <= 15) return digits;
  return null;
}
function publicError(message, status=400) {
  const e = new Error(message); e.status = status; return e;
}
function signToken(payload, admin=false) {
  const secret = admin ? ADMIN_JWT_SECRET : JWT_SECRET;
  if (!secret) throw publicError('Authentication is not configured on the server.', 503);
  return jwt.sign(payload, secret, { algorithm: 'HS256', expiresIn: admin ? '8h' : '30d', issuer: 'mithilana' });
}
function verifyToken(token, admin=false) {
  const secret = admin ? ADMIN_JWT_SECRET : JWT_SECRET;
  if (!secret) throw publicError('Authentication is not configured on the server.', 503);
  return jwt.verify(token, secret, { algorithms: ['HS256'], issuer: 'mithilana' });
}
function getBearer(req) {
  const h = String(req.headers.authorization || '');
  return h.startsWith('Bearer ') ? h.slice(7) : '';
}
function requireCustomer(req, res, next) {
  try {
    req.user = verifyToken(getBearer(req), false);
    if (req.user.type !== 'customer') throw new Error('Invalid token');
    next();
  } catch { res.status(401).json({ error: 'Authentication required.' }); }
}
async function requireAdmin(req, res, next) {
  let claims;
  try {
    claims = verifyToken(getBearer(req), true);
    if (claims.type !== 'admin' || !UUID_RE.test(String(claims.sub))) throw new Error('Invalid token');
  } catch { return res.status(401).json({ error: 'Admin authentication required.' }); }
  try {
    const q = await requireDb().query('SELECT is_active,password_hash FROM admins WHERE id=$1', [claims.sub]);
    if (!q.rowCount || !q.rows[0].is_active || !secureEqual(claims.passwordVersion, sha256(q.rows[0].password_hash)))
      return res.status(401).json({ error: 'Admin authentication required.' });
    req.admin = claims;
    next();
  } catch (e) { next(e); }
}
function sha256(s) { return crypto.createHash('sha256').update(String(s)).digest('hex'); }
function randomSecret(bytes=32) { return crypto.randomBytes(bytes).toString('hex'); }
function validMoney(n) {
  if (n === null || n === undefined || n === '' || typeof n === 'boolean') return false;
  const v = Number(n); return Number.isFinite(v) && v >= 0 && v <= 100000000;
}
const money2 = n => Math.round(Number(n) * 100) / 100;
function optMoney(v) { if (v === null || v === undefined || v === '') return null; if (!validMoney(v)) throw publicError('Invalid price.'); return money2(v); }
function boolField(v, label) {
  if (typeof v === 'boolean') return v;
  if (v === 'true') return true;
  if (v === 'false') return false;
  throw publicError(`Invalid ${label}.`);
}
function intField(v, label, min = 0) {
  const n = Number(v);
  if (v === '' || v === null || typeof v === 'boolean' || !Number.isSafeInteger(n) || n < min || n > 1000000000) throw publicError(`Invalid ${label}.`);
  return n;
}
function slugField(v) {
  const s = cleanText(v, 180).toLowerCase();
  if (!/^[a-z0-9][a-z0-9_-]{0,179}$/.test(s)) throw publicError('Slug may only use letters, numbers, - and _.');
  return s;
}
function dateField(v) {
  if (v === null || v === undefined || v === '') return null;
  const d = new Date(v); if (Number.isNaN(d.getTime())) throw publicError('Invalid date.');
  return d.toISOString();
}
const DUMMY_PASSWORD_HASH = bcrypt.hashSync('not-a-real-password', 10);
function cleanText(v, max=500) { return String(v ?? '').trim().slice(0,max); }
function secureEqual(a,b) {
  if(typeof a!=='string'||typeof b!=='string')return false;
  const left=Buffer.from(a),right=Buffer.from(b);
  return left.length===right.length && crypto.timingSafeEqual(left,right);
}
let googleKeys={until:0,keys:[]};
async function verifyGoogleIdToken(credential) {
  if(!GOOGLE_CLIENT_ID)throw publicError('Google login is not configured.',503);
  if(typeof credential!=='string'||credential.length>10000)throw publicError('Invalid Google credential.');
  const parts=credential.split('.');if(parts.length!==3)throw publicError('Invalid Google credential.');
  let header,payload;
  try{header=JSON.parse(Buffer.from(parts[0],'base64url'));payload=JSON.parse(Buffer.from(parts[1],'base64url'))}catch{throw publicError('Invalid Google credential.')}
  if(header.alg!=='RS256'||!header.kid||payload.aud!==GOOGLE_CLIENT_ID||
     !['accounts.google.com','https://accounts.google.com'].includes(payload.iss)||
     !Number.isFinite(payload.exp)||payload.exp*1000<=Date.now()||
     !payload.sub||payload.email_verified!==true||!payload.email)
    throw publicError('Google account verification failed.',401);
  if(googleKeys.until<Date.now()){
    const r=await fetch('https://www.googleapis.com/oauth2/v3/certs',{signal:AbortSignal.timeout(7000)});
    if(!r.ok)throw publicError('Google verification is temporarily unavailable.',503);
    const data=await r.json();googleKeys={keys:data.keys||[],until:Date.now()+30*60*1000};
  }
  const jwk=googleKeys.keys.find(k=>k.kid===header.kid&&k.kty==='RSA');
  if(!jwk)throw publicError('Google signing key not found.',401);
  const ok=crypto.verify('RSA-SHA256',Buffer.from(parts[0]+'.'+parts[1]),
    crypto.createPublicKey({key:jwk,format:'jwk'}),Buffer.from(parts[2],'base64url'));
  if(!ok)throw publicError('Google signature mismatch.',401);
  return payload;
}
async function razorpayApi(method,endpoint,data){
  if(!RAZORPAY_KEY_ID||!RAZORPAY_KEY_SECRET)throw publicError('Razorpay is not configured.',503);
  const r=await fetch('https://api.razorpay.com/v1/'+endpoint,{
    method,signal:AbortSignal.timeout(10000),
    headers:{Authorization:'Basic '+Buffer.from(RAZORPAY_KEY_ID+':'+RAZORPAY_KEY_SECRET).toString('base64'),'Content-Type':'application/json'},
    ...(data?{body:JSON.stringify(data)}:{})
  });
  const body=await r.json().catch(()=>({}));
  if(!r.ok)throw publicError(body.error?.description||'Payment provider is unavailable.',502);
  return body;
}

async function sendWhatsAppTemplate(to, templateName, language, components=[]) {
  if (!META_ACCESS_TOKEN || !META_PHONE_NUMBER_ID) throw publicError('WhatsApp API is not configured.', 503);
  const url = `https://graph.facebook.com/${META_GRAPH_VERSION}/${META_PHONE_NUMBER_ID}/messages`;
  const payload = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to,
    type: 'template',
    template: { name: templateName, language: { code: language || 'en_US' }, components }
  };
  const r = await fetch(url, {
    signal: AbortSignal.timeout(10000),
    method: 'POST',
    headers: { Authorization: `Bearer ${META_ACCESS_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw publicError(data?.error?.message || 'WhatsApp API rejected the message.', 502);
  return data;
}

function verifyMetaSignature(req) {
  if (!META_APP_SECRET) return false; // Explicitly require signature verification in production.
  const signature = String(req.headers['x-hub-signature-256'] || '');
  if (!/^sha256=[a-f0-9]{64}$/i.test(signature) || !req.rawBody) return false;
  const expected = crypto.createHmac('sha256', META_APP_SECRET).update(req.rawBody).digest('hex');
  const a = Buffer.from(signature.slice(7), 'hex');
  const b = Buffer.from(expected, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function requireDb() {
  if (!pool) throw publicError('DATABASE_URL is not configured.', 503);
  return pool;
}

// Health: does not expose secrets.
app.get('/api/health', async (req,res) => {
  let db = false, activeProducts=0;
  if (pool) { try { const q=await pool.query('SELECT COUNT(*)::integer AS count FROM products WHERE is_active=true');activeProducts=q.rows[0].count;db=true; } catch {} }
  res.status(db ? 200 : 503).json({
    ok: db,
    service: 'mithilana',
    mode: APP_MODE,
    database: db,
    activeProducts,
    whatsapp: Boolean(META_ACCESS_TOKEN && META_PHONE_NUMBER_ID),
    google: Boolean(GOOGLE_CLIENT_ID),
    razorpay: Boolean(RAZORPAY_KEY_ID && RAZORPAY_KEY_SECRET && RAZORPAY_WEBHOOK_SECRET),
    whatsappWebhookVerified: Boolean(META_APP_SECRET),
    version: process.env.APP_VERSION || 'production'
  });
});

app.get('/api/public-config',(req,res)=>res.json({
  build:'mithilana-secure-fixes-v8-20261008',
  appMode:APP_MODE,
  googleClientId:GOOGLE_CLIENT_ID||null,
  razorpayEnabled:Boolean(RAZORPAY_KEY_ID&&RAZORPAY_KEY_SECRET&&RAZORPAY_WEBHOOK_SECRET)
}));

const pincodeCache=new Map();
app.get('/api/pincode/:pin',async(req,res)=>{
  const pin=String(req.params.pin||'');
  if(!/^[1-9][0-9]{5}$/.test(pin))return res.status(400).json({error:'Enter a valid 6 digit PIN code.'});
  const cached=pincodeCache.get(pin);
  if(cached && cached.until>Date.now())return res.json(cached.value);
  try{
    const response=await fetch('https://api.pincodeapi.in/api/v1/pincode/'+pin,{signal:AbortSignal.timeout(5000)});
    if(!response.ok)throw Error('PIN lookup unavailable');
    const data=await response.json();
    const offices=data?.data?.post_offices;
    if(!data.success||!Array.isArray(offices)||!offices.length)return res.status(404).json({error:'PIN code not found. Enter city and state manually.'});
    const first=offices[0];
    const value={city:cleanText(first.district,100),state:cleanText(first.state,100)};
    if(!value.city||!value.state)throw Error('PIN lookup incomplete');
    if(pincodeCache.size>=5000)pincodeCache.delete(pincodeCache.keys().next().value);
    pincodeCache.set(pin,{value,until:Date.now()+24*60*60*1000});
    res.json(value);
  }catch{res.status(503).json({error:'PIN lookup unavailable. Enter city and state manually.'})}
});

app.post('/api/auth/google',googleLimiter,async(req,res,next)=>{
  try{
    const claims=await verifyGoogleIdToken(req.body.credential);
    const db=requireDb();
    const name=cleanText(claims.name,200);
    const email=cleanText(claims.email,254).toLowerCase();
    // Google subject, not email, is the stable identity.
    const q=await db.query(`INSERT INTO customers(google_sub,email,name)
      VALUES($1,$2,$3) ON CONFLICT(google_sub)
      DO UPDATE SET last_login_at=NOW(),email=EXCLUDED.email
      RETURNING id,phone,email,name`,[claims.sub,email,name]);
    const customer=q.rows[0];
    res.json({ok:true,token:signToken({type:'customer',sub:customer.id,phone:customer.phone||null}),user:customer});
  }catch(e){next(e)}
});

app.get('/api/me', requireCustomer, async (req,res,next)=>{
  try {
    const db=requireDb();
    const q=await db.query(`SELECT id,phone,name,email,address_line1,address_line2,city,state,pincode,preferred_language FROM customers WHERE id=$1`,[req.user.sub]);
    if(!q.rowCount) throw publicError('Customer not found.',404);
    res.json({ok:true,user:q.rows[0]});
  } catch(e){next(e);}
});

// Profile changes are limited to the authenticated customer; phone is no longer used for login.
app.patch('/api/me', requireCustomer, async(req,res,next)=>{
  try {
    const fields=['name','email','address_line1','address_line2','city','state','pincode','preferred_language'];
    const sets=[], values=[];
    for(const field of fields) if(Object.hasOwn(req.body,field)) {
      const value=cleanText(req.body[field],field.startsWith('address')?500:254);
      if(field==='preferred_language' && !['hi','en'].includes(value)) throw publicError('Choose Hindi or English.');
      if(field==='email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) throw publicError('Invalid email.');
      if(field==='pincode' && value && !/^\d{6}$/.test(value)) throw publicError('Enter a 6 digit PIN code.');
      values.push(value||null); sets.push(`${field}=$${values.length}`);
    }
    if(!sets.length) throw publicError('No profile changes supplied.');
    values.push(req.user.sub);
    const q=await requireDb().query(`UPDATE customers SET ${sets.join(',')} WHERE id=$${values.length} RETURNING id,phone,name,email,address_line1,address_line2,city,state,pincode,preferred_language`,values);
    if(!q.rowCount) throw publicError('Customer not found.',404);
    res.json({ok:true,user:q.rows[0]});
  }catch(e){next(e);}
});

// Public catalog. Product edits do not touch orders because order_items stores snapshots.
app.get('/api/products', async (req,res,next)=>{
  try {
    const db=requireDb();
    const q=await db.query(`
      SELECT p.id,p.slug,p.name,p.description,p.base_price,p.compare_at_price,p.stock,p.is_active,
             (SELECT image_url FROM product_images pi WHERE pi.product_id=p.id AND pi.is_active=true ORDER BY pi.sort_order,pi.created_at LIMIT 1) AS image_url,
             COALESCE(json_agg(json_build_object('id',v.id,'name',v.name,'price',v.price,'stock',v.stock)
             ORDER BY v.sort_order,v.id) FILTER (WHERE v.id IS NOT NULL),'[]') AS variants
      FROM products p
      LEFT JOIN product_variants v ON v.product_id=p.id AND v.is_active=true
      WHERE (p.is_active=true OR $1='test')
      GROUP BY p.id ORDER BY p.sort_order,p.created_at DESC`,[APP_MODE]);
    res.json({ok:true,products:q.rows});
  } catch(e){next(e);}
});

app.get('/api/orders', requireCustomer, async(req,res,next)=>{
  try {
    const db=requireDb();
    const q=await db.query(`SELECT id,status,payment_method,payment_status,subtotal,discount_amount,shipping_amount,total_amount,created_at,updated_at,
      COALESCE((SELECT json_agg(json_build_object('status',h.status,'created_at',h.created_at) ORDER BY h.created_at)
      FROM order_status_history h WHERE h.order_id=orders.id),'[]'::json) AS history
      FROM orders WHERE customer_id=$1 ORDER BY created_at DESC LIMIT 100`,[req.user.sub]);
    res.json({ok:true,orders:q.rows});
  } catch(e){next(e);}
});
app.get('/api/orders/:id', requireCustomer, async(req,res,next)=>{
  try {
    const db=requireDb();
    const q=await db.query(`SELECT id,status,payment_method,payment_status,subtotal,discount_amount,shipping_amount,total_amount,shipping_address,created_at,updated_at
      FROM orders WHERE id=$1 AND customer_id=$2`,[req.params.id,req.user.sub]);
    if(!q.rowCount) throw publicError('Order not found.',404);
    const items=await db.query(`SELECT product_id,product_name,unit_price,quantity,line_total FROM order_items WHERE order_id=$1 ORDER BY created_at`,[req.params.id]);
    const history=await db.query(`SELECT status,note,created_at FROM order_status_history WHERE order_id=$1 ORDER BY created_at`,[req.params.id]);
    res.json({ok:true,order:{...q.rows[0],items:items.rows,history:history.rows}});
  }catch(e){next(e);}
});

// Admin login.
app.post('/api/admin/login', rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:'draft-7',legacyHeaders:false,message:{error:'Too many login attempts. Please try again later.'}}), async (req,res,next)=>{
  try {
    const db=requireDb();
    const email=cleanText(req.body.email,254).toLowerCase();
    const password=String(req.body.password||'');
    if(!email || !password) throw publicError('Email and password are required.');
    if(Buffer.byteLength(password)>72) throw publicError('Invalid admin credentials.',401);
    const q=await db.query(`SELECT id,email,password_hash,is_active FROM admins WHERE email=$1`,[email]);
    // Always run bcrypt so response time does not reveal whether the email exists.
    const passwordOk=await bcrypt.compare(password,q.rowCount?q.rows[0].password_hash:DUMMY_PASSWORD_HASH);
    if(!q.rowCount || !q.rows[0].is_active || !passwordOk)
      throw publicError('Invalid admin credentials.',401);
    await db.query(`UPDATE admins SET last_login_at=NOW() WHERE id=$1`,[q.rows[0].id]);
    res.json({ok:true,token:signToken({type:'admin',sub:q.rows[0].id,email,passwordVersion:sha256(q.rows[0].password_hash)},true)});
  } catch(e){next(e);}
});

// Admin product CRUD. Archive instead of destructive delete.
app.get('/api/admin/products',requireAdmin,async(req,res,next)=>{
  try { const db=requireDb(); const q=await db.query(`
    SELECT p.*, COALESCE(json_agg(json_build_object('id',v.id,'name',v.name,'price',v.price,'stock',v.stock,'is_active',v.is_active)
    ORDER BY v.sort_order,v.id) FILTER(WHERE v.id IS NOT NULL),'[]') variants
    FROM products p LEFT JOIN product_variants v ON v.product_id=p.id GROUP BY p.id ORDER BY p.sort_order,p.id`);
    res.json({ok:true,products:q.rows});
  }catch(e){next(e);}
});

app.post('/api/admin/products',requireAdmin,async(req,res,next)=>{
  try {
    const b=req.body||{};
    const name=cleanText(b.name,200);
    if(!name) throw publicError('Product name is required.');
    if(!validMoney(b.base_price)) throw publicError('Invalid price.');
    const q=await requireDb().query(`
      INSERT INTO products(slug,name,description,base_price,compare_at_price,stock,sort_order,is_active)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [b.slug?slugField(b.slug):crypto.randomUUID(),name,cleanText(b.description,5000),money2(b.base_price),optMoney(b.compare_at_price),
       intField(b.stock??0,'stock'),intField(b.sort_order??0,'sort order',-1000000),b.is_active===undefined?true:boolField(b.is_active,'status')]);
    res.status(201).json({ok:true,product:q.rows[0]});
  }catch(e){next(e);}
});

app.patch('/api/admin/products/:id',requireAdmin,async(req,res,next)=>{
  try {
    const b=req.body||{}; const sets=[], vals=[];
    const add=(k,v)=>{vals.push(v);sets.push(`${k}=$${vals.length}`)};
    const has=k=>Object.hasOwn(b,k);
    if(has('slug')) add('slug',slugField(b.slug));
    if(has('name')){const n=cleanText(b.name,200);if(!n)throw publicError('Product name is required.');add('name',n)}
    if(has('description')) add('description',cleanText(b.description,5000));
    if(has('base_price')){if(!validMoney(b.base_price))throw publicError('Invalid price.');add('base_price',money2(b.base_price))}
    if(has('compare_at_price')) add('compare_at_price',optMoney(b.compare_at_price));
    if(has('stock')) add('stock',intField(b.stock,'stock'));
    if(has('sort_order')) add('sort_order',intField(b.sort_order,'sort order',-1000000));
    if(has('is_active')) add('is_active',boolField(b.is_active,'status'));
    if(!sets.length) throw publicError('No changes supplied.');
    vals.push(req.params.id);
    const q=await requireDb().query(`UPDATE products SET ${sets.join(',')},updated_at=NOW() WHERE id=$${vals.length} RETURNING *`,vals);
    if(!q.rowCount) throw publicError('Product not found.',404);
    res.json({ok:true,product:q.rows[0]});
  }catch(e){next(e);}
});
app.delete('/api/admin/products/:id',requireAdmin,async(req,res,next)=>{
  try {
    const db=requireDb();
    const q=await db.query(`UPDATE products SET is_active=false,updated_at=NOW() WHERE id=$1 RETURNING id`,[req.params.id]);
    if(!q.rowCount) throw publicError('Product not found.',404);
    res.json({ok:true,archived:true});
  }catch(e){next(e);}
});

// Offers are isolated from products and can be enabled/disabled without changing catalog records.
app.get('/api/offers',async(req,res,next)=>{
  try { const db=requireDb(); const q=await db.query(`
    SELECT id,code,name,discount_type,discount_value,min_order_amount,max_discount_amount,
           starts_at,ends_at,is_active FROM offers
    WHERE is_active=true AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW())
    ORDER BY created_at DESC`);
    res.json({ok:true,offers:q.rows});
  }catch(e){next(e);}
});

// Admin managed offers and image URLs; images live in durable external storage.
app.get('/api/admin/offers',requireAdmin,async(req,res,next)=>{
  try { const q=await requireDb().query('SELECT * FROM offers ORDER BY created_at DESC LIMIT 500'); res.json({ok:true,offers:q.rows}); }catch(e){next(e);}
});
app.post('/api/admin/offers',requireAdmin,async(req,res,next)=>{
  try {
    const x=req.body||{}, code=cleanText(x.code,50).toUpperCase(), type=x.discount_type;
    if(!/^[A-Z0-9_-]{3,50}$/.test(code)||!cleanText(x.name,200)||!['fixed','percent'].includes(type)||!validMoney(x.discount_value)||Number(x.discount_value)<=0||(type==='percent'&&Number(x.discount_value)>100)) throw publicError('Invalid offer.');
    const minOrder=x.min_order_amount===undefined||x.min_order_amount===null||x.min_order_amount===''?0:x.min_order_amount;
    if(!validMoney(minOrder)) throw publicError('Invalid minimum order amount.');
    const q=await requireDb().query(`INSERT INTO offers(code,name,discount_type,discount_value,min_order_amount,max_discount_amount,starts_at,ends_at,is_active) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [code,cleanText(x.name,200),type,money2(x.discount_value),money2(minOrder),optMoney(x.max_discount_amount),dateField(x.starts_at),dateField(x.ends_at),x.is_active===undefined?true:boolField(x.is_active,'status')]);
    res.status(201).json({ok:true,offer:q.rows[0]});
  }catch(e){next(e);}
});
app.patch('/api/admin/offers/:id',requireAdmin,async(req,res,next)=>{
  try {
    const db=requireDb(), b=req.body||{}, sets=[], values=[];
    const add=(k,v)=>{values.push(v);sets.push(`${k}=$${values.length}`)};
    const has=k=>Object.hasOwn(b,k);
    const cur=await db.query('SELECT discount_type FROM offers WHERE id=$1',[req.params.id]);
    if(!cur.rowCount) throw publicError('Offer not found.',404);
    if(has('name')){const n=cleanText(b.name,200);if(!n)throw publicError('Offer name is required.');add('name',n)}
    if(has('discount_value')){
      if(!validMoney(b.discount_value)||Number(b.discount_value)<=0||(cur.rows[0].discount_type==='percent'&&Number(b.discount_value)>100)) throw publicError('Invalid discount value.');
      add('discount_value',money2(b.discount_value));
    }
    if(has('min_order_amount')){
      const v=b.min_order_amount===null||b.min_order_amount===''?0:b.min_order_amount;
      if(!validMoney(v)) throw publicError('Invalid minimum order amount.');
      add('min_order_amount',money2(v));
    }
    if(has('max_discount_amount')) add('max_discount_amount',optMoney(b.max_discount_amount));
    if(has('starts_at')) add('starts_at',dateField(b.starts_at));
    if(has('ends_at')) add('ends_at',dateField(b.ends_at));
    if(has('is_active')) add('is_active',boolField(b.is_active,'status'));
    if(!sets.length) throw publicError('No changes supplied.');
    values.push(req.params.id);
    const q=await db.query(`UPDATE offers SET ${sets.join(',')},updated_at=NOW() WHERE id=$${values.length} RETURNING *`,values);
    res.json({ok:true,offer:q.rows[0]});
  }catch(e){next(e);}
});
// Signed Cloudinary upload: credentials remain server-side; the browser uploads directly.
app.post('/api/admin/cloudinary/sign',requireAdmin,(req,res,next)=>{
  try {
    const cloud=process.env.CLOUDINARY_CLOUD_NAME, key=process.env.CLOUDINARY_API_KEY, secret=process.env.CLOUDINARY_API_SECRET;
    if(!cloud||!key||!secret) throw publicError('Cloudinary is not configured.',503);
    if(!/^[a-zA-Z0-9_-]+$/.test(cloud)) throw publicError('Invalid Cloudinary configuration.',503);
    const timestamp=Math.floor(Date.now()/1000), folder='mithilana/products';
    const signature=crypto.createHash('sha1').update(`folder=${folder}&timestamp=${timestamp}${secret}`).digest('hex');
    res.json({cloud_name:cloud,api_key:key,timestamp,folder,signature});
  }catch(e){next(e)}
});
// Verify Cloudinary actually owns the image before accepting the URL into the catalog.
app.post('/api/admin/products/:id/cloudinary-image',requireAdmin,async(req,res,next)=>{
  try {
    const cloud=process.env.CLOUDINARY_CLOUD_NAME,key=process.env.CLOUDINARY_API_KEY,secret=process.env.CLOUDINARY_API_SECRET;
    if(!cloud||!key||!secret) throw publicError('Cloudinary is not configured.',503);
    const publicId=String(req.body.public_id||'');
    if(!/^mithilana\/products\/[a-zA-Z0-9_\/-]{1,180}$/.test(publicId)) throw publicError('Invalid image ID.');
    const auth=Buffer.from(`${key}:${secret}`).toString('base64');
    const response=await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/resources/image/upload/${publicId.split('/').map(encodeURIComponent).join('/')}`,{headers:{Authorization:`Basic ${auth}`},signal:AbortSignal.timeout(10000)});
    if(!response.ok) throw publicError('Could not verify uploaded image.',400);
    const asset=await response.json();
    if(asset.resource_type!=='image'||asset.type!=='upload'||!asset.secure_url||!asset.public_id.startsWith('mithilana/products/')) throw publicError('Invalid image asset.');
    const db=requireDb(), product=await db.query('SELECT id,name FROM products WHERE id=$1',[req.params.id]);
    if(!product.rowCount) throw publicError('Product not found.',404);
    const sort=Number(req.body.sort_order);
    const order=Number.isSafeInteger(sort)&&sort>=0&&sort<=10000?sort:0;
    const result=await db.query('INSERT INTO product_images(product_id,image_url,alt_text,sort_order) VALUES($1,$2,$3,$4) RETURNING *',[req.params.id,asset.secure_url,cleanText(req.body.alt_text||product.rows[0].name,250),order]);
    res.status(201).json({ok:true,image:result.rows[0]});
  }catch(e){next(e)}
});
app.get('/api/admin/products/:id/images',requireAdmin,async(req,res,next)=>{
  try{const r=await requireDb().query('SELECT id,image_url,alt_text,sort_order,is_active FROM product_images WHERE product_id=$1 ORDER BY sort_order,created_at',[req.params.id]);res.json({ok:true,images:r.rows})}catch(e){next(e)}
});
app.post('/api/admin/products/:id/images',requireAdmin,async(req,res,next)=>{
  try {
    const url=String(req.body.image_url||'');
    let parsed; try{parsed=new URL(url)}catch{throw publicError('Enter a valid image URL.')}
    if(parsed.protocol!=='https:'||url.length>2000) throw publicError('Image URL must be HTTPS.');
    const q=await requireDb().query(`INSERT INTO product_images(product_id,image_url,alt_text,sort_order) VALUES($1,$2,$3,$4) RETURNING *`,[req.params.id,url,cleanText(req.body.alt_text,250),Number.isSafeInteger(Number(req.body.sort_order))?Number(req.body.sort_order):0]);
    res.status(201).json({ok:true,image:q.rows[0]});
  }catch(e){next(e);}
});
app.patch('/api/admin/images/:id',requireAdmin,async(req,res,next)=>{
  try { const q=await requireDb().query(`UPDATE product_images SET is_active=$1 WHERE id=$2 RETURNING *`,[req.body.is_active===true,req.params.id]);if(!q.rowCount)throw publicError('Image not found.',404);res.json({ok:true,image:q.rows[0]}); }catch(e){next(e);}
});

// Orders: server calculates price from DB; client-submitted totals are never trusted.
// All money is computed in whole paise (integers) so the stored total, the Razorpay amount and the
// later payment check always agree exactly.
async function priceCart(q,items,offerCode,lock){
  const ids=[...new Set(items.map(x=>String(x?.product_id)))];
  if(ids.some(x=>!UUID_RE.test(x))) throw publicError('Invalid product ID.');
  const lk=lock?' FOR UPDATE':'';
  const p=await q.query(`SELECT id,name,base_price,stock FROM products WHERE id=ANY($1::uuid[]) AND (is_active=true OR $2='test')${lk}`,[ids,APP_MODE]);
  if(p.rowCount!==ids.length) throw publicError('One or more products are unavailable.',409);
  const byId=new Map(p.rows.map(x=>[String(x.id),x]));
  const wanted=new Map(); const normalized=[]; let subtotalP=0;
  for(const item of items){
    const product=byId.get(String(item?.product_id)); const qty=Number(item?.quantity);
    if(!product || !Number.isInteger(qty)||typeof item?.quantity==='boolean'||qty<1||qty>100) throw publicError('Invalid cart item.');
    const total=(wanted.get(String(product.id))||0)+qty; wanted.set(String(product.id),total);
    if(APP_MODE!=='test' && Number(product.stock)<total) throw publicError(`Insufficient stock for ${product.name}.`,409);
    const lineP=Math.round(Number(product.base_price)*100)*qty; subtotalP+=lineP;
    normalized.push({product,qty,lineP});
  }
  let discountP=0, offer=null;
  if(offerCode){
    const oq=await q.query(`SELECT * FROM offers WHERE code=$1 AND is_active=true
      AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW())${lk}`,[offerCode]);
    if(!oq.rowCount) throw publicError('Coupon code is invalid or expired.');
    offer=oq.rows[0];
    if(subtotalP<Math.round(Number(offer.min_order_amount||0)*100)) throw publicError('Cart total does not meet this coupon minimum.');
    discountP=offer.discount_type==='percent'
      ? Math.round(subtotalP*Number(offer.discount_value)/100)
      : Math.round(Number(offer.discount_value)*100);
    if(offer.max_discount_amount!=null) discountP=Math.min(discountP,Math.round(Number(offer.max_discount_amount)*100));
    discountP=Math.max(0,Math.min(discountP,subtotalP));
  }
  return {normalized,subtotalP,discountP,totalP:subtotalP-discountP,offer};
}

const orderLimiter=rateLimit({windowMs:60*60*1000,limit:30,keyGenerator:req=>req.user.sub,standardHeaders:'draft-7',legacyHeaders:false,message:{error:'Too many orders. Please try again later.'}});
app.post('/api/orders',requireCustomer,orderLimiter,async(req,res,next)=>{
  let client;
  try {
    const db=requireDb();
    const items=Array.isArray(req.body.items)?req.body.items:[];
    if(!items.length || items.length>100) throw publicError('Cart is empty or too large.');
    const offerCode=cleanText(req.body.offer_code,50).toUpperCase()||null;
    const method=req.body.payment_method||'cod';
    if(!['cod','razorpay'].includes(method)) throw publicError('Invalid payment method.');
    if(method==='razorpay' && (!RAZORPAY_KEY_ID||!RAZORPAY_KEY_SECRET||!RAZORPAY_WEBHOOK_SECRET))
      throw publicError('Online payment is not configured.',503);
    const address = req.body.shipping_address && typeof req.body.shipping_address === 'object' && !Array.isArray(req.body.shipping_address)
      ? req.body.shipping_address : null;
    if (!cleanText(req.body.shipping_name,200) || !address || !cleanText(address.line1,500) || !/^\d{6}$/.test(String(address.pincode||''))) throw publicError('Name, address and PIN code are required.');
    const shippingPhone=normalizePhone(req.body.shipping_phone)||req.user.phone;
    if(!shippingPhone) throw publicError('A valid mobile number is required for delivery.');
    // Keep only the known address fields, with limited length (no arbitrary JSON stored).
    const cleanAddress={};
    for(const k of ['line1','line2','landmark','city','state','pincode','country']) if(address[k]!==undefined) cleanAddress[k]=cleanText(address[k],k.startsWith('line')?500:120);

    const orderId=crypto.randomUUID();
    let gateway=null, quotedTotalP=null;
    if(method==='razorpay'){
      // The slow Razorpay call happens BEFORE any database locks are taken.
      const quote=await priceCart(db,items,offerCode,false);
      if(quote.totalP<100) throw publicError('Online payment needs at least ₹1.');
      quotedTotalP=quote.totalP;
      gateway=await razorpayApi('POST','orders',{amount:quote.totalP,currency:'INR',receipt:orderId});
    }
    client=await db.connect();
    await client.query('BEGIN');
    const priced=await priceCart(client,items,offerCode,true);
    if(gateway && priced.totalP!==quotedTotalP) throw publicError('Prices changed while placing the order. Please review your cart and try again.',409);
    const status=method==='razorpay'?'pending_payment':'placed';
    const order=await client.query(`
      INSERT INTO orders(id,customer_id,status,payment_method,payment_status,razorpay_order_id,subtotal,discount_amount,shipping_amount,total_amount,offer_id,shipping_name,shipping_phone,shipping_address)
      VALUES($1,$2,$3,$4,'pending',$5,$6,$7,0,$8,$9,$10,$11,$12) RETURNING id,status,total_amount`,
      [orderId,req.user.sub,status,method,gateway?.id||null,priced.subtotalP/100,priced.discountP/100,priced.totalP/100,
       priced.offer?.id||null,cleanText(req.body.shipping_name,200),shippingPhone,cleanAddress]);
    for(const x of priced.normalized){
      await client.query(`INSERT INTO order_items(order_id,product_id,product_name,unit_price,quantity,line_total)
        VALUES($1,$2,$3,$4,$5,$6)`,[orderId,x.product.id,x.product.name,x.product.base_price,x.qty,x.lineP/100]);
      if(APP_MODE!=='test'){
        const u=await client.query(`UPDATE products SET stock=stock-$1,updated_at=NOW() WHERE id=$2 AND stock>=$1`,[x.qty,x.product.id]);
        if(!u.rowCount) throw publicError(`Insufficient stock for ${x.product.name}.`,409);
      }
    }
    await client.query(`INSERT INTO order_status_history(order_id,status,note) VALUES($1,$2,$3)`,
      [orderId,status,method==='razorpay'?'Awaiting captured payment':'COD order created']);
    if(gateway) await client.query(`INSERT INTO payments(order_id,provider,provider_order_id,amount,status)
      VALUES($1,'razorpay',$2,$3,'created')`,[orderId,gateway.id,priced.totalP/100]);
    await adminOrderEmail.queue(client,orderId);
    await client.query('COMMIT');
    res.status(201).json({ok:true,order:order.rows[0],
      ...(gateway?{payment:{keyId:RAZORPAY_KEY_ID,providerOrderId:gateway.id,amount:gateway.amount,currency:'INR'}}:{})});
    // Receipt is visible in the customer profile; WhatsApp confirmation is sent only after admin confirmation.
  }catch(e){ if(client) await client.query('ROLLBACK').catch(()=>{}); next(e); }
  finally{ if(client) client.release(); }
});

// Data minimisation: keep only what is needed for reconciliation (no card, email or phone details).
function minimalPayment(p){
  return {id:p.id,order_id:p.order_id,status:p.status,amount:p.amount,currency:p.currency,method:p.method,captured:p.captured,created_at:p.created_at};
}
async function finalizeCapturedPayment(providerOrderId,paymentId,providerResponse){
  const client=await requireDb().connect();
  try{
    await client.query('BEGIN');
    const q=await client.query(`SELECT * FROM orders WHERE razorpay_order_id=$1 FOR UPDATE`,[providerOrderId]);
    if(!q.rowCount)throw publicError('Payment order not found.',404);
    const order=q.rows[0];
    if(order.payment_status==='paid'){
      if(order.razorpay_payment_id!==paymentId)throw publicError('Payment ID mismatch.',409);
      await client.query('COMMIT');return order;
    }
    if(order.status!=='pending_payment')throw publicError('Order is no longer payable. Contact support.',409);
    if(providerResponse.status!=='captured'||providerResponse.order_id!==providerOrderId||
       providerResponse.currency!=='INR'||Number(providerResponse.amount)!==Math.round(Number(order.total_amount)*100))
      throw publicError('Captured payment could not be verified.',409);
    await client.query(`UPDATE orders SET payment_status='paid',status='placed',razorpay_payment_id=$1,updated_at=NOW()
      WHERE id=$2`,[paymentId,order.id]);
    await client.query(`UPDATE payments SET provider_payment_id=$1,status='captured',raw_response=$2,updated_at=NOW()
      WHERE order_id=$3 AND provider='razorpay'`,[paymentId,minimalPayment(providerResponse),order.id]);
    await client.query(`INSERT INTO order_status_history(order_id,status,note)
      VALUES($1,'placed','Razorpay payment captured and verified')`,[order.id]);
    await client.query('COMMIT');return {...order,status:'placed',payment_status:'paid'};
  }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e}finally{client.release()}
}

app.post('/api/payments/razorpay/verify',requireCustomer,async(req,res,next)=>{
  try{
    const orderId=cleanText(req.body.order_id,100),paymentId=cleanText(req.body.payment_id,100);
    const signature=String(req.body.signature||'');
    if(!RAZORPAY_KEY_SECRET||!orderId||!paymentId||!/^[a-f0-9]{64}$/i.test(signature))
      throw publicError('Payment verification is not configured or details are invalid.');
    const ownership=await requireDb().query(`SELECT id FROM orders WHERE razorpay_order_id=$1 AND customer_id=$2`,[orderId,req.user.sub]);
    if(!ownership.rowCount)throw publicError('Order not found.',404);
    const expected=crypto.createHmac('sha256',RAZORPAY_KEY_SECRET).update(orderId+'|'+paymentId).digest('hex');
    if(!secureEqual(expected,signature))throw publicError('Payment signature mismatch.',401);
    const payment=await razorpayApi('GET','payments/'+encodeURIComponent(paymentId));
    const order=await finalizeCapturedPayment(orderId,paymentId,payment);
    res.json({ok:true,order:{id:order.id,status:order.status,total_amount:order.total_amount}});
  }catch(e){next(e)}
});

app.post('/api/payments/razorpay/webhook',async(req,res,next)=>{
  try{
    if(!RAZORPAY_WEBHOOK_SECRET||!req.rawBody)return res.sendStatus(503);
    const expected=crypto.createHmac('sha256',RAZORPAY_WEBHOOK_SECRET).update(req.rawBody).digest('hex');
    if(!secureEqual(expected,String(req.headers['x-razorpay-signature']||'')))return res.sendStatus(401);
    if(req.body.event==='payment.captured'){
      const entity=req.body.payload?.payment?.entity;
      if(entity?.order_id&&entity?.id){
        // Confirm payment status and amount with Razorpay API, then update once.
        const payment=await razorpayApi('GET','payments/'+encodeURIComponent(entity.id));
        await finalizeCapturedPayment(entity.order_id,entity.id,payment);
      }
    }
    res.sendStatus(200);
  }catch(e){next(e)}
});

// Admin order list/status. Every status change is audited.
app.get('/api/admin/orders',requireAdmin,async(req,res,next)=>{
  try { const db=requireDb(); const q=await db.query(`
    SELECT o.*,c.phone,c.name FROM orders o JOIN customers c ON c.id=o.customer_id
    ORDER BY o.created_at DESC LIMIT 500`);
    res.json({ok:true,orders:q.rows});
  }catch(e){next(e);}
});
app.patch('/api/admin/orders/:id/status',requireAdmin,async(req,res,next)=>{
  const allowed=['placed','confirmed','packed','shipped','out_for_delivery','delivered','cancelled'];
  const status=String(req.body.status||'');
  if(!allowed.includes(status)) return res.status(400).json({error:'Invalid order status.'});
  const db=requireDb(); const client=await db.connect();
  try{
    await client.query('BEGIN');
    const before=await client.query(`SELECT id,status FROM orders WHERE id=$1 FOR UPDATE`,[req.params.id]);
    if(!before.rowCount) throw publicError('Order not found.',404);
    const old=before.rows[0].status;
    if(old==='cancelled' || old==='delivered') throw publicError('This order is already finalized.',409);
    if(status===old) throw publicError('Order already has this status.',409);
    const transitions={pending_payment:['cancelled'],placed:['confirmed','cancelled'],confirmed:['packed','cancelled'],packed:['shipped','cancelled'],shipped:['out_for_delivery','cancelled'],out_for_delivery:['delivered','cancelled']};
    if(!transitions[old]?.includes(status)) throw publicError('Invalid status transition.',409);
    if(status==='cancelled') {
      const items=await client.query(`SELECT product_id,quantity FROM order_items WHERE order_id=$1`,[req.params.id]);
      if(APP_MODE!=='test') for(const item of items.rows) if(item.product_id) await client.query(`UPDATE products SET stock=stock+$1,updated_at=NOW() WHERE id=$2`,[item.quantity,item.product_id]);
    }
    const q=await client.query(`UPDATE orders SET status=$1,updated_at=NOW() WHERE id=$2 RETURNING id,customer_id,status,total_amount`,[status,req.params.id]);
    await client.query(`INSERT INTO order_status_history(order_id,status,note,changed_by_admin_id) VALUES($1,$2,$3,$4)`,
      [req.params.id,status,`Status changed to ${status}`,req.admin.sub]);
    if(status!=='cancelled') await client.query(`INSERT INTO notification_outbox(order_id,status,phone) SELECT $1,$2,o.shipping_phone FROM orders o WHERE o.id=$3 ON CONFLICT(order_id,status) DO NOTHING`,[q.rows[0].id,status,q.rows[0].id]);
    await client.query('COMMIT');
    res.json({ok:true,order:q.rows[0]});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

// WhatsApp webhook verification + inbound event receipt. Raw events are stored for debugging/audit.
app.get('/webhook', (req,res)=>{
  const mode=req.query['hub.mode']; const token=req.query['hub.verify_token']; const challenge=req.query['hub.challenge'];
  if(mode==='subscribe' && WHATSAPP_VERIFY_TOKEN && token===WHATSAPP_VERIFY_TOKEN) return res.status(200).send(String(challenge));
  res.sendStatus(403);
});
app.post('/webhook', async(req,res,next)=>{
  try{
    if (!verifyMetaSignature(req)) return res.sendStatus(403);
    const db=requireDb();
    await db.query(`INSERT INTO webhook_events(source,payload) VALUES('whatsapp',$1)`,[req.body]);
    res.sendStatus(200);
  }catch(e){next(e);}
});

// A DB-backed worker confirms received COD and captured online orders after five seconds. Safe across restarts
// and multiple server instances: SKIP LOCKED prevents the same transition racing.
async function confirmDueOrders(){
  if(!pool||AUTO_CONFIRM_SECONDS<=0)return;
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const q=await client.query(`WITH due AS (
      SELECT id FROM orders WHERE status='placed'
        AND (payment_method='cod' OR (payment_method='razorpay' AND payment_status='paid'))
        AND updated_at <= NOW()-($1::integer*INTERVAL '1 second')
      ORDER BY created_at LIMIT 30 FOR UPDATE SKIP LOCKED
    ) UPDATE orders o SET status='confirmed',updated_at=NOW()
      FROM due WHERE o.id=due.id RETURNING o.id,o.customer_id`,[AUTO_CONFIRM_SECONDS]);
    for(const order of q.rows){
      await client.query(`INSERT INTO order_status_history(order_id,status,note) VALUES($1,'confirmed','Automatically confirmed')`,[order.id]);
      await client.query(`INSERT INTO notification_outbox(order_id,status,phone)
        SELECT $1,'confirmed',o.shipping_phone FROM orders o WHERE o.id=$1
        ON CONFLICT(order_id,status) DO NOTHING`,[order.id]);
    }
    await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e}finally{client.release()}
}
async function sendPendingNotifications(){
  if(!pool||!META_ACCESS_TOKEN||!META_PHONE_NUMBER_ID||!WHATSAPP_ORDER_STATUS_TEMPLATE)return;
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const q=await client.query(`SELECT id,order_id,status,phone,attempts FROM notification_outbox
      WHERE state='pending' AND next_attempt_at<=NOW()
      ORDER BY id LIMIT 5 FOR UPDATE SKIP LOCKED`);
    for(const item of q.rows){
      try {
        const message=await sendWhatsAppTemplate(item.phone,WHATSAPP_ORDER_STATUS_TEMPLATE,WHATSAPP_ORDER_TEMPLATE_LANGUAGE,[
          {type:'body',parameters:[{type:'text',text:String(item.order_id)},{type:'text',text:item.status.replace(/_/g,' ')}]}
        ]);
        await client.query(`UPDATE notification_outbox SET state='sent',sent_at=NOW(),attempts=attempts+1,
          provider_message_id=$1,last_error=NULL WHERE id=$2`,[message.messages?.[0]?.id||null,item.id]);
      }catch(e){
        const delay=Math.min(3600,Math.pow(2,Math.min(item.attempts+1,10))*5);
        await client.query(`UPDATE notification_outbox SET attempts=attempts+1,
          next_attempt_at=NOW()+($1::integer*INTERVAL '1 second'),last_error=$2 WHERE id=$3`,[delay,String(e.message).slice(0,500),item.id]);
        console.error('WhatsApp notification pending retry:',item.order_id,e.message);
      }
    }
    await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e}finally{client.release()}
}
let adminEmailBusy=false;
async function adminEmailWorker(){if(adminEmailBusy)return;adminEmailBusy=true;try{await adminOrderEmail.sendPending(pool)}catch(e){console.error('Admin email worker:',e.name)}finally{adminEmailBusy=false}}
setInterval(adminEmailWorker,10000).unref();
let workerBusy=false;
async function orderWorker(){
  if(workerBusy)return;workerBusy=true;
  try{await confirmDueOrders();await sendPendingNotifications()}catch(e){console.error('Order worker:',e.message)}finally{workerBusy=false}
}
setInterval(orderWorker,1000).unref();

// Data retention: drop leftover rows from the old OTP login and old raw WhatsApp webhook payloads (they contain customer phone numbers/messages).
async function cleanupOldData(){
  if(!pool)return;
  await pool.query(`DELETE FROM otp_requests WHERE expires_at < NOW()-INTERVAL '1 hour'`);
  await pool.query(`DELETE FROM webhook_events WHERE created_at < NOW()-INTERVAL '90 days'`);
}
setInterval(()=>cleanupOldData().catch(e=>console.error('Cleanup:',e.message)),60*60*1000).unref();
cleanupOldData().catch(()=>{});

// Lists the size-wise product images placed in assets/product-images/ so the site only requests files that exist.
app.get('/api/product-images', (req,res)=>{
  const dir=path.join(ROOT,'assets','product-images');
  require('fs').readdir(dir,(err,names)=>{
    if(err)return res.json({files:{}});
    const files={};
    let pending=0;
    const ok=names.filter(n=>/^[a-z0-9-]+\.(webp|png|jpe?g|avif)$/.test(n));
    if(!ok.length)return res.json({files});
    pending=ok.length;
    ok.forEach(n=>require('fs').stat(path.join(dir,n),(e,st)=>{
      if(!e)files[n]=Math.floor(st.mtimeMs);
      if(--pending===0)res.json({files});
    }));
  });
});

app.use('/api', (req,res)=>res.status(404).json({error:'API route not found.'}));
app.use('/assets',express.static(path.join(ROOT,'assets'),{etag:true,maxAge:'1y',immutable:true,dotfiles:'deny'}));

// Only these pages are public. server.js, SQL files, scripts and notes are never served.
const PAGES={'/':'index.html','/index.html':'index.html','/admin.html':'admin.html','/privacy.html':'privacy.html','/refund-cancellation.html':'refund-cancellation.html'};
app.get(/.*/, (req,res)=>{
  if(req.path.split('/').some(part=>part.startsWith('.')))return res.status(404).type('text/plain').send('Not found');
  const file=PAGES[req.path];
  if(!file && path.extname(req.path)) return res.status(404).type('text/plain').send('Not found');
  res.setHeader('Cache-Control','no-store');
  if(file==='admin.html') res.setHeader('X-Robots-Tag','noindex, nofollow');
  res.sendFile(path.join(ROOT,file||'index.html'));
});

app.use((err,req,res,next)=>{
  // Log what is needed to debug, never request bodies (they can hold personal data).
  console.error(`[${new Date().toISOString()}] ${req.method} ${req.path} -> ${err.code||''} ${err.type==='entity.parse.failed'?'Invalid JSON body':err.message}`);
  let status=Number(err.status)||0;
  let message=err.message;
  if(!status){
    if(err.code==='23505'){status=409;message='This value already exists.'}
    else if(err.code==='23503'){status=409;message='A related record was not found.'}
    else if(['22P02','22003','22007','22001','23502','23514'].includes(err.code)){status=400;message='Invalid data supplied.'}
    else status=500;
  }
  if (err.type==='entity.parse.failed') message='Invalid JSON body.';
  if (err.type==='entity.too.large') message='Request body is too large.';
  res.status(status).json({error: status>=500 ? 'Server error. Please try again.' : message});
});

if (require.main === module) app.listen(PORT,()=>console.log(`Mithilana server listening on ${PORT}`));
module.exports = { app, pool, secureEqual, verifyMetaSignature, priceCart, finalizeCapturedPayment };
