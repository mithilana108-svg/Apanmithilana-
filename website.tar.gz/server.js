const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const path = require('path');
const adminOrderEmail = require('./admin-order-email');
const catalogV2 = require('./catalog-v2');
const imageLifecycle = require('./image-lifecycle');

const app = express();
const PORT = Number(process.env.PORT || 10000);
const ROOT = __dirname;

const isProd = process.env.NODE_ENV === 'production';
const DATABASE_URL = process.env.DATABASE_URL || '';
const JWT_SECRET = process.env.JWT_SECRET || '';
const ADMIN_JWT_SECRET = process.env.ADMIN_JWT_SECRET || JWT_SECRET;
const PUBLIC_ORIGIN = (process.env.PUBLIC_ORIGIN || (process.env.RENDER_EXTERNAL_HOSTNAME ? 'https://'+process.env.RENDER_EXTERNAL_HOSTNAME : '')).replace(/\/+$/, '');
// Exact trusted origins for the public domain and the service's own Render hostname.
// Do not accept arbitrary subdomains or reflect untrusted origins.
const ALLOWED_ORIGINS = new Set([PUBLIC_ORIGIN, 'https://www.apanmithilana.com', 'https://apanmithilana.com', process.env.RENDER_EXTERNAL_HOSTNAME ? 'https://' + process.env.RENDER_EXTERNAL_HOSTNAME : ''].filter(Boolean));
const APP_MODE = process.env.APP_MODE || 'test';
const META_ACCESS_TOKEN = process.env.META_ACCESS_TOKEN || '';
const META_PHONE_NUMBER_ID = process.env.META_PHONE_NUMBER_ID || '';
const META_GRAPH_VERSION = process.env.META_GRAPH_VERSION || 'v25.0';
const WHATSAPP_VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN || '';
const WHATSAPP_SUPPORT_NUMBER = process.env.WHATSAPP_SUPPORT_NUMBER || '';
const META_APP_SECRET = process.env.META_APP_SECRET || '';
const WHATSAPP_ORDER_STATUS_TEMPLATE = process.env.WHATSAPP_ORDER_STATUS_TEMPLATE || '';
const WHATSAPP_ORDER_TEMPLATE_LANGUAGE = process.env.WHATSAPP_ORDER_TEMPLATE_LANGUAGE || 'en_US';
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || '';
const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || '';
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || '';
const RAZORPAY_WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || '';
// Seconds before a paid/COD order is auto-confirmed. 0 turns auto-confirm off (admin confirms by hand).
const AUTO_CONFIRM_SECONDS = Math.max(0, Math.floor(Number(process.env.AUTO_CONFIRM_SECONDS ?? 5)) || 0);
// Content-Security-Policy mode: enforce (default) | report-only | off.
const CSP_MODE = process.env.CSP_MODE || 'enforce';

if (isProd && (!JWT_SECRET || !ADMIN_JWT_SECRET || JWT_SECRET === ADMIN_JWT_SECRET || !DATABASE_URL)) throw new Error('Production requires DATABASE_URL and distinct customer/admin JWT secrets.');
if (isProd && (Buffer.byteLength(JWT_SECRET)<32 || Buffer.byteLength(ADMIN_JWT_SECRET)<32)) throw new Error('Production JWT secrets must each contain at least 32 bytes.');
if (isProd && CSP_MODE !== 'enforce') throw new Error('Production requires CSP_MODE=enforce.');
if (!['test','live'].includes(APP_MODE)) throw new Error('APP_MODE must be test or live.');
if (APP_MODE==='live' && process.env.LIVE_ORDERS_ENABLED!=='true') throw new Error('Set LIVE_ORDERS_ENABLED=true after completing live checkout tests.');
if (APP_MODE==='live' && (!GOOGLE_CLIENT_ID || !PUBLIC_ORIGIN))
  throw new Error('Live mode requires Google Client ID and public origin.');
if (!GOOGLE_CLIENT_ID) console.warn('WARNING: GOOGLE_CLIENT_ID is not set. Google is the only login, so customers cannot log in or order until it is set.');
if (RAZORPAY_KEY_ID && !RAZORPAY_KEY_ID.startsWith(APP_MODE==='live'?'rzp_live_':'rzp_test_'))
  throw new Error('Razorpay key mode does not match APP_MODE.');


const pool = DATABASE_URL ? new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.DB_SSL === 'false' ? false : { rejectUnauthorized: true },
  max: Number(process.env.DB_POOL_MAX || 10),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
}) : null;

app.set('trust proxy', 1);
app.disable('x-powered-by');

const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'", 'https://accounts.google.com', 'https://checkout.razorpay.com'],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://accounts.google.com'],
  imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
  mediaSrc: ["'self'", 'blob:', 'https://res.cloudinary.com'],
  fontSrc: ["'self'", 'data:'],
  connectSrc: ["'self'", 'https://accounts.google.com', 'https://api.razorpay.com', 'https://lumberjack.razorpay.com', 'https://api.cloudinary.com'],
  frameSrc: ['https://accounts.google.com', 'https://api.razorpay.com', 'https://checkout.razorpay.com'],
  objectSrc: ["'none'"],
  baseUri: ["'self'"],
  formAction: ["'self'"],
  frameAncestors: ["'self'"]
};
app.use(helmet({
  contentSecurityPolicy: CSP_MODE === 'off' ? false : { useDefaults: false, reportOnly: CSP_MODE === 'report-only', directives: cspDirectives },
  // Google Identity Services popup must communicate its result to this page.
  crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' },
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));
app.use(cors({
  origin(origin, cb) {
    if (!origin || ALLOWED_ORIGINS.has(origin)) return cb(null, true);
    return cb(publicError('CORS origin not allowed.', 403));
  },
  credentials: true
}));
app.use(express.json({
  limit: '100kb',
  verify: (req, res, buf) => { if (req.path === '/webhook' || req.path === '/api/payments/razorpay/webhook') req.rawBody = Buffer.from(buf); }
}));
app.use(express.urlencoded({ extended: false, limit: '50kb' }));

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: 'draft-7',
  legacyHeaders: false
});
// Login is Google-only; this limits repeated login attempts per IP.
const googleLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again later.' }
});
app.use('/api/', apiLimiter);
// Personal data must never be cached by browsers or proxies.
app.use('/api', (req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
// Every ":id" route parameter in this app is a UUID. Anything else is a plain 404, not a database error.
app.param('id', (req, res, next, id) => UUID_RE.test(String(id)) ? next() : res.status(404).json({ error: 'Not found.' }));

function normalizePhone(value) {
  const digits = String(value || '').replace(/\D/g, '');
  if (digits.length === 10) return '91' + digits;
  if (digits.length >= 11 && digits.length <= 15) return digits;
  return null;
}
function publicError(message, status=400) {
  const e = new Error(message); e.status = status; e.expose=true; return e;
}
function signToken(payload, admin=false) {
  const secret = admin ? ADMIN_JWT_SECRET : JWT_SECRET;
  if (!secret) throw publicError('Authentication is not configured on the server.', 503);
  return jwt.sign(payload, secret, { algorithm: 'HS256', expiresIn: admin ? '8h' : '30d', issuer: 'mithilana' });
}
function verifyToken(token, admin=false) {
  const secret = admin ? ADMIN_JWT_SECRET : JWT_SECRET;
  if (!secret) throw publicError('Authentication is not configured on the server.', 503);
  return jwt.verify(token, secret, { algorithms: ['HS256'], issuer: 'mithilana' });
}
function getBearer(req) {
  const h = String(req.headers.authorization || '');
  return h.startsWith('Bearer ') ? h.slice(7) : '';
}
async function requireCustomer(req, res, next) {
  try {
    req.user = verifyToken(getBearer(req), false);
    if (req.user.type !== 'customer' || !UUID_RE.test(String(req.user.sub))) throw new Error('Invalid token');
    const revoked=await requireDb().query('SELECT token_hash FROM revoked_sessions WHERE token_hash=$1 AND expires_at>NOW()',[sha256(getBearer(req))]);
    if(revoked.rowCount)throw new Error('Revoked token');
    next();
  } catch { res.status(401).json({ error: 'Authentication required.' }); }
}
async function requireAdmin(req, res, next) {
  let claims;
  try {
    claims = verifyToken(getBearer(req), true);
    if (claims.type !== 'admin' || !UUID_RE.test(String(claims.sub))) throw new Error('Invalid token');
  } catch { return res.status(401).json({ error: 'Admin authentication required.' }); }
  try {
    const q = await requireDb().query('SELECT is_active,password_hash FROM admins WHERE id=$1', [claims.sub]);
    if (!q.rowCount || !q.rows[0].is_active || !secureEqual(claims.passwordVersion, sha256(q.rows[0].password_hash)))
      return res.status(401).json({ error: 'Admin authentication required.' });
    const revoked=await requireDb().query('SELECT token_hash FROM revoked_sessions WHERE token_hash=$1 AND expires_at>NOW()',[sha256(getBearer(req))]);
    if(revoked.rowCount)return res.status(401).json({error:'Admin authentication required.'});
    req.admin = claims;
    next();
  } catch (e) { next(e); }
}
function sha256(s) { return crypto.createHash('sha256').update(String(s)).digest('hex'); }
function randomSecret(bytes=32) { return crypto.randomBytes(bytes).toString('hex'); }
function validMoney(n) {
  if (!['string','number'].includes(typeof n) || n === '') return false;
  const v = Number(n); return Number.isFinite(v) && v >= 0 && v <= 100000000;
}
const money2 = n => Math.round(Number(n) * 100) / 100;
function optMoney(v) { if (v === null || v === undefined || v === '') return null; if (!validMoney(v)) throw publicError('Invalid price.'); return money2(v); }
function boolField(v, label) {
  if (typeof v === 'boolean') return v;
  if (v === 'true') return true;
  if (v === 'false') return false;
  throw publicError(`Invalid ${label}.`);
}
function intField(v, label, min = 0) {
  const n = Number(v);
  if (v === '' || v === null || typeof v === 'boolean' || !Number.isSafeInteger(n) || n < min || n > 1000000000) throw publicError(`Invalid ${label}.`);
  return n;
}
function slugField(v) {
  const s = cleanText(v, 180).toLowerCase();
  if (!/^[a-z0-9][a-z0-9_-]{0,179}$/.test(s)) throw publicError('Slug may only use letters, numbers, - and _.');
  return s;
}
function dateField(v) {
  if (v === null || v === undefined || v === '') return null;
  const d = new Date(v); if (Number.isNaN(d.getTime())) throw publicError('Invalid date.');
  return d.toISOString();
}
const DUMMY_PASSWORD_HASH = bcrypt.hashSync('not-a-real-password', 10);
function cleanText(v, max=500) { return String(v ?? '').trim().slice(0,max); }
function secureEqual(a,b) {
  if(typeof a!=='string'||typeof b!=='string')return false;
  const left=Buffer.from(a),right=Buffer.from(b);
  return left.length===right.length && crypto.timingSafeEqual(left,right);
}
let googleKeys={until:0,keys:[]};
async function verifyGoogleIdToken(credential) {
  if(!GOOGLE_CLIENT_ID)throw publicError('Google login is not configured.',503);
  if(typeof credential!=='string'||credential.length>10000)throw publicError('Invalid Google credential.');
  const parts=credential.split('.');if(parts.length!==3)throw publicError('Invalid Google credential.');
  let header,payload;
  try{header=JSON.parse(Buffer.from(parts[0],'base64url'));payload=JSON.parse(Buffer.from(parts[1],'base64url'))}catch{throw publicError('Invalid Google credential.')}
  if(header.alg!=='RS256'||!header.kid||payload.aud!==GOOGLE_CLIENT_ID||
     !['accounts.google.com','https://accounts.google.com'].includes(payload.iss)||
     !Number.isFinite(payload.exp)||payload.exp*1000<=Date.now()||
     !payload.sub||payload.email_verified!==true||!payload.email)
    throw publicError('Google account verification failed.',401);
  if(googleKeys.until<Date.now()){
    const r=await fetch('https://www.googleapis.com/oauth2/v3/certs',{signal:AbortSignal.timeout(7000)});
    if(!r.ok)throw publicError('Google verification is temporarily unavailable.',503);
    const data=await r.json();googleKeys={keys:data.keys||[],until:Date.now()+30*60*1000};
  }
  const jwk=googleKeys.keys.find(k=>k.kid===header.kid&&k.kty==='RSA');
  if(!jwk)throw publicError('Google signing key not found.',401);
  const ok=crypto.verify('RSA-SHA256',Buffer.from(parts[0]+'.'+parts[1]),
    crypto.createPublicKey({key:jwk,format:'jwk'}),Buffer.from(parts[2],'base64url'));
  if(!ok)throw publicError('Google signature mismatch.',401);
  return payload;
}
async function razorpayApi(method,endpoint,data){
  if(!RAZORPAY_KEY_ID||!RAZORPAY_KEY_SECRET)throw publicError('Razorpay is not configured.',503);
  const r=await fetch('https://api.razorpay.com/v1/'+endpoint,{
    method,signal:AbortSignal.timeout(10000),
    headers:{Authorization:'Basic '+Buffer.from(RAZORPAY_KEY_ID+':'+RAZORPAY_KEY_SECRET).toString('base64'),'Content-Type':'application/json'},
    ...(data?{body:JSON.stringify(data)}:{})
  });
  const body=await r.json().catch(()=>({}));
  if(!r.ok)throw publicError(body.error?.description||'Payment provider is unavailable.',502);
  return body;
}

async function sendWhatsAppTemplate(to, templateName, language, components=[]) {
  if (!META_ACCESS_TOKEN || !META_PHONE_NUMBER_ID) throw publicError('WhatsApp API is not configured.', 503);
  const url = `https://graph.facebook.com/${META_GRAPH_VERSION}/${META_PHONE_NUMBER_ID}/messages`;
  const payload = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to,
    type: 'template',
    template: { name: templateName, language: { code: language || 'en_US' }, components }
  };
  const r = await fetch(url, {
    signal: AbortSignal.timeout(10000),
    method: 'POST',
    headers: { Authorization: `Bearer ${META_ACCESS_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw publicError(data?.error?.message || 'WhatsApp API rejected the message.', 502);
  return data;
}

function verifyMetaSignature(req) {
  if (!META_APP_SECRET) return false; // Explicitly require signature verification in production.
  const signature = String(req.headers['x-hub-signature-256'] || '');
  if (!/^sha256=[a-f0-9]{64}$/i.test(signature) || !req.rawBody) return false;
  const expected = crypto.createHmac('sha256', META_APP_SECRET).update(req.rawBody).digest('hex');
  const a = Buffer.from(signature.slice(7), 'hex');
  const b = Buffer.from(expected, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function requireDb() {
  if (!pool) throw publicError('DATABASE_URL is not configured.', 503);
  return pool;
}

// Health: does not expose secrets.
app.get('/api/health', async (req,res) => {
  let db = false, activeProducts=0;
  if (pool) { try { const q=await pool.query("SELECT COUNT(*)::integer AS count FROM products WHERE is_active=true AND legacy_parent_id IS NULL AND EXISTS(SELECT 1 FROM schema_migrations WHERE version='catalog-v2')");
      const version=await pool.query("SELECT version FROM schema_migrations WHERE version='catalog-v2'");if(!version.rowCount)throw Error('Catalog migration not complete');activeProducts=q.rows[0].count;db=true; } catch {} }
  res.status(db ? 200 : 503).json({
    ok: db,
    service: 'mithilana',
    mode: APP_MODE,
    database: db,
    activeProducts,
    whatsapp: Boolean(META_ACCESS_TOKEN && META_PHONE_NUMBER_ID),
    google: Boolean(GOOGLE_CLIENT_ID),
    razorpay: Boolean(RAZORPAY_KEY_ID && RAZORPAY_KEY_SECRET && RAZORPAY_WEBHOOK_SECRET),
    whatsappWebhookVerified: Boolean(META_APP_SECRET),
    version: process.env.APP_VERSION || 'production'
  });
});

// Festival and company content: database-backed, administrator-only writes.
const DEFAULT_FESTIVAL = {
 enabled:true, title:'शुभ नवरात्रि', subtitle:'नवदुर्गा की आराधना', theme:'#8b211c', background:'#fff5df', font:'Georgia', template:'classic',
 startDate:'2026-10-11', endDate:'2026-10-20', manualDay:0,
 days:[
 ['माँ शैलपुत्री','हिमालय की पुत्री माँ शैलपुत्री नवदुर्गा का प्रथम स्वरूप हैं। वे वृषभ पर विराजमान हैं और उनके हाथों में त्रिशूल तथा कमल है।','ॐ देवी शैलपुत्र्यै नमः॥'],
 ['माँ ब्रह्मचारिणी','माँ ब्रह्मचारिणी तपस्या, संयम और साधना का स्वरूप हैं। वे जपमाला और कमंडल धारण करती हैं।','ॐ देवी ब्रह्मचारिण्यै नमः॥'],
 ['माँ चंद्रघंटा','माँ चंद्रघंटा के मस्तक पर घंटे के आकार का अर्धचंद्र है। उनका स्वरूप साहस और संरक्षण का प्रतीक है।','ॐ देवी चंद्रघण्टायै नमः॥'],
 ['माँ कूष्माण्डा','माँ कूष्माण्डा को सृष्टि की आदिशक्ति के रूप में पूजा जाता है। उनका तेज जीवन और ऊर्जा का प्रतीक माना जाता है।','ॐ देवी कूष्माण्डायै नमः॥'],
 ['माँ स्कंदमाता','माँ स्कंदमाता भगवान स्कंद की माता हैं। उनका स्वरूप मातृस्नेह, संरक्षण और करुणा का प्रतीक है।','ॐ देवी स्कन्दमातायै नमः॥'],
 ['माँ कात्यायनी','माँ कात्यायनी को पराक्रम और धर्म की रक्षा करने वाली शक्ति के रूप में पूजा जाता है।','ॐ देवी कात्यायन्यै नमः॥'],
 ['माँ कालरात्रि','माँ कालरात्रि का उग्र स्वरूप अज्ञान, भय और अधर्म के नाश का प्रतीक है। उनका वाहन गर्दभ माना जाता है।','ॐ देवी कालरात्र्यै नमः॥'],
 ['माँ महागौरी','माँ महागौरी का स्वरूप शांति, पवित्रता और करुणा का प्रतीक है। उन्हें श्वेत वस्त्रों में दर्शाया जाता है।','ॐ देवी महागौर्यै नमः॥'],
 ['माँ सिद्धिदात्री','माँ सिद्धिदात्री नवदुर्गा का नवम स्वरूप हैं। वे सिद्धि, ज्ञान और आध्यात्मिक पूर्णता का प्रतीक हैं।','ॐ देवी सिद्धिदात्र्यै नमः॥'],
 ['विजयादशमी','विजयादशमी धर्म की अधर्म पर विजय का पर्व है। इस दिन श्रीराम की रावण पर विजय और देवी की महिषासुर पर विजय की परंपराएँ स्मरण की जाती हैं।','सत्यमेव जयते॥']
 ].map((d,i)=>({name:d[0],story:d[1],mantra:d[2],image:'/assets/navratri-user-day-'+(i+1)+'.jpg'}))
};
const DEFAULT_COMPANY = {heading:'About Our Company', description:"Mithilana brings Mithila's food traditions and products to your table.",theme:'#245c3b',background:'#fffdf8',font:'Georgia',template:'classic',image:''};
const DEFAULT_BUSINESS={name:'Mithilana',address:'',email:'',phone:WHATSAPP_SUPPORT_NUMBER||'919220866696',fssai:'',grievance:'',website:PUBLIC_ORIGIN};
let contentTableReady=false;
async function ensureContentTable(){if(contentTableReady)return;await requireDb().query('CREATE TABLE IF NOT EXISTS mithilana_content (key TEXT PRIMARY KEY, data JSONB NOT NULL, updated_at TIMESTAMPTZ DEFAULT NOW())');contentTableReady=true}
async function getSiteContent(key){const fallback=key==='festival'?DEFAULT_FESTIVAL:key==='business'?DEFAULT_BUSINESS:DEFAULT_COMPANY;try{await ensureContentTable();const q=await requireDb().query('SELECT data FROM mithilana_content WHERE key=$1',[key]);const saved=q.rows[0]?.data||fallback;
 if(key==='festival' && Array.isArray(saved.days)){
  // Upgrade only the former bundled festival pictures; preserve any later admin-selected URLs.
  return {...saved,days:saved.days.map((day,i)=>({...day,image:(!day.image||/^\/assets\/navratri-day-\d+\.webp$/.test(day.image))?'/assets/navratri-user-day-'+(i+1)+'.jpg':day.image}))};
 }
 return saved}catch(e){console.error('Content read:',e.message);return fallback}}
app.get('/api/site-content/:key',async(req,res)=>{if(!['festival','company','business'].includes(req.params.key))return res.sendStatus(404);res.setHeader('Cache-Control','no-store');res.json(await getSiteContent(req.params.key))});
app.put('/api/admin/site-content/:key',requireAdmin,async(req,res,next)=>{try{
 const key=req.params.key;if(!['festival','company','business'].includes(key))return res.sendStatus(404);
 const data=req.body;if(!data||typeof data!=='object'||Array.isArray(data)||JSON.stringify(data).length>45000)return res.status(400).json({error:'Invalid content'});
 const str=(v,max)=>typeof v==='string'&&v.length<=max;
 // Image fields may only point at this site's /assets, an https link, or a small inline image (never javascript: etc.).
 const okUrl=v=>v===undefined||v===''||(typeof v==='string'&&(/^\/assets\/[A-Za-z0-9._\/-]+$/.test(v)||/^https:\/\/[^\s"'<>]+$/.test(v)||/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+\/=]+$/.test(v)));
 if(!okUrl(data.image))return res.status(400).json({error:'Image must be an https link or an /assets path.'});
 for(const prop of ['title','subtitle','heading','description','theme','background','font','template','image','startDate','endDate','name','address','email','phone','fssai','grievance','website'])if(data[prop]!==undefined&&!str(data[prop],prop==='description'?6000:500))return res.status(400).json({error:'Invalid '+prop});
 if(key==='festival'){
 if(typeof data.enabled!=='boolean'||!Number.isInteger(data.manualDay)||data.manualDay<0||data.manualDay>10||!Array.isArray(data.days)||data.days.length!==10)return res.status(400).json({error:'Festival needs 10 days'});
 if(!/^\d{4}-\d{2}-\d{2}$/.test(data.startDate||'')||!/^\d{4}-\d{2}-\d{2}$/.test(data.endDate||''))return res.status(400).json({error:'Invalid dates'});
 for(const day of data.days)if(!day||!['name','story','mantra','image'].every(k=>str(day[k],k==='story'?6000:700)))return res.status(400).json({error:'Invalid day'});
  if(data.days.some(d=>!okUrl(d.image)))return res.status(400).json({error:'Day image must be an https link or an /assets path.'});
 }
 await ensureContentTable();await requireDb().query('INSERT INTO mithilana_content(key,data) VALUES($1,$2::jsonb) ON CONFLICT(key) DO UPDATE SET data=EXCLUDED.data,updated_at=NOW()',[key,JSON.stringify(data)]);
 res.json({ok:true});
 }catch(e){next(e)}});
app.get('/api/public-config',(req,res)=>res.json({
  build:'mithilana-catalog-v2-20261012',
  appMode:APP_MODE,
  googleClientId:GOOGLE_CLIENT_ID||null,
  whatsappSupportNumber:WHATSAPP_SUPPORT_NUMBER||'919220866696',
  razorpayEnabled:Boolean(RAZORPAY_KEY_ID&&RAZORPAY_KEY_SECRET&&RAZORPAY_WEBHOOK_SECRET)
}));

const pincodeCache=new Map();
app.get('/api/pincode/:pin',async(req,res)=>{
  const pin=String(req.params.pin||'');
  if(!/^[1-9][0-9]{5}$/.test(pin))return res.status(400).json({error:'Enter a valid 6 digit PIN code.'});
  const cached=pincodeCache.get(pin);
  if(cached && cached.until>Date.now())return res.json(cached.value);
  try{
    const response=await fetch('https://api.pincodeapi.in/api/v1/pincode/'+pin,{signal:AbortSignal.timeout(5000)});
    if(!response.ok)throw Error('PIN lookup unavailable');
    const data=await response.json();
    const offices=data?.data?.post_offices;
    if(!data.success||!Array.isArray(offices)||!offices.length)return res.status(404).json({error:'PIN code not found. Enter city and state manually.'});
    const first=offices[0];
    const value={city:cleanText(first.district,100),state:cleanText(first.state,100)};
    if(!value.city||!value.state)throw Error('PIN lookup incomplete');
    if(pincodeCache.size>=5000)pincodeCache.delete(pincodeCache.keys().next().value);
    pincodeCache.set(pin,{value,until:Date.now()+24*60*60*1000});
    res.json(value);
  }catch{res.status(503).json({error:'PIN lookup unavailable. Enter city and state manually.'})}
});

app.post('/api/auth/google',googleLimiter,async(req,res,next)=>{
  try{
    const claims=await verifyGoogleIdToken(req.body.credential);
    const db=requireDb();
    const name=cleanText(claims.name,200);
    const email=cleanText(claims.email,254).toLowerCase();
    // Google subject, not email, is the stable identity.
    const q=await db.query(`INSERT INTO customers(google_sub,email,name)
      VALUES($1,$2,$3) ON CONFLICT(google_sub)
      DO UPDATE SET last_login_at=NOW(),email=EXCLUDED.email
      RETURNING id,phone,email,name`,[claims.sub,email,name]);
    const customer=q.rows[0];
    res.json({ok:true,token:signToken({type:'customer',sub:customer.id,phone:customer.phone||null}),user:customer});
  }catch(e){next(e)}
});

app.post('/api/auth/logout',requireCustomer,async(req,res,next)=>{try{await requireDb().query('INSERT INTO revoked_sessions(token_hash,expires_at) VALUES($1,to_timestamp($2)) ON CONFLICT(token_hash) DO NOTHING',[sha256(getBearer(req)),req.user.exp]);res.json({ok:true})}catch(e){next(e)}});

app.get('/api/me', requireCustomer, async (req,res,next)=>{
  try {
    const db=requireDb();
    const q=await db.query(`SELECT id,phone,name,email,address_line1,address_line2,city,state,pincode,preferred_language FROM customers WHERE id=$1`,[req.user.sub]);
    if(!q.rowCount) throw publicError('Customer not found.',404);
    res.json({ok:true,user:q.rows[0]});
  } catch(e){next(e);}
});

// Profile changes are limited to the authenticated customer; phone is no longer used for login.
app.patch('/api/me', requireCustomer, async(req,res,next)=>{
  try {
    const fields=['name','email','address_line1','address_line2','city','state','pincode','preferred_language'];
    const sets=[], values=[];
    for(const field of fields) if(Object.hasOwn(req.body,field)) {
      const value=cleanText(req.body[field],field.startsWith('address')?500:254);
      if(field==='preferred_language' && !['hi','en'].includes(value)) throw publicError('Choose Hindi or English.');
      if(field==='email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) throw publicError('Invalid email.');
      if(field==='pincode' && value && !/^\d{6}$/.test(value)) throw publicError('Enter a 6 digit PIN code.');
      values.push(value||null); sets.push(`${field}=$${values.length}`);
    }
    if(!sets.length) throw publicError('No profile changes supplied.');
    values.push(req.user.sub);
    const q=await requireDb().query(`UPDATE customers SET ${sets.join(',')} WHERE id=$${values.length} RETURNING id,phone,name,email,address_line1,address_line2,city,state,pincode,preferred_language`,values);
    if(!q.rowCount) throw publicError('Customer not found.',404);
    res.json({ok:true,user:q.rows[0]});
  }catch(e){next(e);}
});

catalogV2.register(app,{requireDb,requireAdmin});
require('./category-covers').register(app,{requireDb,requireAdmin});
require('./home-slider').register(app,{requireDb,requireAdmin});
require('./about-media').register(app,{requireDb,requireAdmin});

app.get('/api/orders', requireCustomer, async(req,res,next)=>{
  try {
    const db=requireDb();
    const q=await db.query(`SELECT id,status,payment_method,payment_status,subtotal,discount_amount,shipping_amount,total_amount,created_at,updated_at,
      COALESCE((SELECT json_agg(json_build_object('status',h.status,'created_at',h.created_at) ORDER BY h.created_at)
      FROM order_status_history h WHERE h.order_id=orders.id),'[]'::json) AS history
      FROM orders WHERE customer_id=$1 ORDER BY created_at DESC LIMIT 100`,[req.user.sub]);
    res.json({ok:true,orders:q.rows});
  } catch(e){next(e);}
});
app.get('/api/orders/:id', requireCustomer, async(req,res,next)=>{
  try {
    const db=requireDb();
    const q=await db.query(`SELECT id,status,payment_method,payment_status,subtotal,discount_amount,shipping_amount,total_amount,shipping_address,created_at,updated_at
      FROM orders WHERE id=$1 AND customer_id=$2`,[req.params.id,req.user.sub]);
    if(!q.rowCount) throw publicError('Order not found.',404);
    const items=await db.query(`SELECT product_id,product_name,unit_price,quantity,line_total FROM order_items WHERE order_id=$1 ORDER BY created_at`,[req.params.id]);
    const history=await db.query(`SELECT status,note,created_at FROM order_status_history WHERE order_id=$1 ORDER BY created_at`,[req.params.id]);
    res.json({ok:true,order:{...q.rows[0],items:items.rows,history:history.rows}});
  }catch(e){next(e);}
});

// Admin login.
app.post('/api/admin/login', rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:'draft-7',legacyHeaders:false,message:{error:'Too many login attempts. Please try again later.'}}), async (req,res,next)=>{
  try {
    const db=requireDb();
    const email=cleanText(req.body.email,254).toLowerCase();
    const password=String(req.body.password||'');
    if(!email || !password) throw publicError('Email and password are required.');
    if(Buffer.byteLength(password)>72) throw publicError('Invalid admin credentials.',401);
    const q=await db.query(`SELECT id,email,password_hash,is_active FROM admins WHERE email=$1`,[email]);
    // Always run bcrypt so response time does not reveal whether the email exists.
    const passwordOk=await bcrypt.compare(password,q.rowCount?q.rows[0].password_hash:DUMMY_PASSWORD_HASH);
    if(!q.rowCount || !q.rows[0].is_active || !passwordOk)
      throw publicError('Invalid admin credentials.',401);
    await db.query(`UPDATE admins SET last_login_at=NOW() WHERE id=$1`,[q.rows[0].id]);
    res.json({ok:true,token:signToken({type:'admin',sub:q.rows[0].id,email,passwordVersion:sha256(q.rows[0].password_hash)},true)});
  } catch(e){next(e);}
});

app.post('/api/admin/logout',requireAdmin,async(req,res,next)=>{try{await requireDb().query('INSERT INTO revoked_sessions(token_hash,expires_at) VALUES($1,to_timestamp($2)) ON CONFLICT DO NOTHING',[sha256(getBearer(req)),req.admin.exp]);res.json({ok:true})}catch(e){next(e)}});

// Offers are isolated from products and can be enabled/disabled without changing catalog records.
app.get('/api/offers',async(req,res,next)=>{
  try { const db=requireDb(); const q=await db.query(`
    SELECT id,code,name,discount_type,discount_value,min_order_amount,max_discount_amount,
           starts_at,ends_at,is_active FROM offers
    WHERE is_active=true AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW())
    ORDER BY created_at DESC`);
    res.json({ok:true,offers:q.rows});
  }catch(e){next(e);}
});

// Admin managed offers and image URLs; images live in durable external storage.
app.get('/api/admin/offers',requireAdmin,async(req,res,next)=>{
  try { const q=await requireDb().query('SELECT * FROM offers ORDER BY created_at DESC LIMIT 500'); res.json({ok:true,offers:q.rows}); }catch(e){next(e);}
});
app.post('/api/admin/offers',requireAdmin,async(req,res,next)=>{
  try {
    const x=req.body||{}, code=cleanText(x.code,50).toUpperCase(), type=x.discount_type;
    if(!/^[A-Z0-9_-]{3,50}$/.test(code)||!cleanText(x.name,200)||!['fixed','percent'].includes(type)||!validMoney(x.discount_value)||Number(x.discount_value)<=0||(type==='percent'&&Number(x.discount_value)>100)) throw publicError('Invalid offer.');
    const minOrder=x.min_order_amount===undefined||x.min_order_amount===null||x.min_order_amount===''?0:x.min_order_amount;
    if(!validMoney(minOrder)) throw publicError('Invalid minimum order amount.');
    if(x.starts_at&&x.ends_at&&new Date(x.starts_at)>new Date(x.ends_at))throw publicError('Offer end must follow its start.');
    const q=await requireDb().query(`INSERT INTO offers(code,name,discount_type,discount_value,min_order_amount,max_discount_amount,starts_at,ends_at,is_active) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [code,cleanText(x.name,200),type,money2(x.discount_value),money2(minOrder),optMoney(x.max_discount_amount),dateField(x.starts_at),dateField(x.ends_at),x.is_active===undefined?true:boolField(x.is_active,'status')]);
    res.status(201).json({ok:true,offer:q.rows[0]});
  }catch(e){next(e);}
});
app.patch('/api/admin/offers/:id',requireAdmin,async(req,res,next)=>{
  try {
    const db=requireDb(), b=req.body||{}, sets=[], values=[];
    const add=(k,v)=>{values.push(v);sets.push(`${k}=$${values.length}`)};
    const has=k=>Object.hasOwn(b,k);
    const cur=await db.query('SELECT discount_type,starts_at,ends_at FROM offers WHERE id=$1',[req.params.id]);
    if(!cur.rowCount) throw publicError('Offer not found.',404);
    if(has('name')){const n=cleanText(b.name,200);if(!n)throw publicError('Offer name is required.');add('name',n)}
    if(has('discount_value')){
      if(!validMoney(b.discount_value)||Number(b.discount_value)<=0||(cur.rows[0].discount_type==='percent'&&Number(b.discount_value)>100)) throw publicError('Invalid discount value.');
      add('discount_value',money2(b.discount_value));
    }
    if(has('min_order_amount')){
      const v=b.min_order_amount===null||b.min_order_amount===''?0:b.min_order_amount;
      if(!validMoney(v)) throw publicError('Invalid minimum order amount.');
      add('min_order_amount',money2(v));
    }
    const start=has('starts_at')?dateField(b.starts_at):cur.rows[0].starts_at,end=has('ends_at')?dateField(b.ends_at):cur.rows[0].ends_at;
    if(start&&end&&new Date(start)>new Date(end))throw publicError('Offer end must follow its start.');
    if(has('max_discount_amount')) add('max_discount_amount',optMoney(b.max_discount_amount));
    if(has('starts_at')) add('starts_at',dateField(b.starts_at));
    if(has('ends_at')) add('ends_at',dateField(b.ends_at));
    if(has('is_active')) add('is_active',boolField(b.is_active,'status'));
    if(!sets.length) throw publicError('No changes supplied.');
    values.push(req.params.id);
    const q=await db.query(`UPDATE offers SET ${sets.join(',')},updated_at=NOW() WHERE id=$${values.length} RETURNING *`,values);
    res.json({ok:true,offer:q.rows[0]});
  }catch(e){next(e);}
});
// Signed Cloudinary upload: credentials remain server-side; the browser uploads directly.
app.post('/api/admin/cloudinary/sign',requireAdmin,(req,res,next)=>{
  try {
    const cloud=process.env.CLOUDINARY_CLOUD_NAME, key=process.env.CLOUDINARY_API_KEY, secret=process.env.CLOUDINARY_API_SECRET;
    if(!cloud||!key||!secret) throw publicError('Cloudinary is not configured.',503);
    if(!/^[a-zA-Z0-9_-]+$/.test(cloud)) throw publicError('Invalid Cloudinary configuration.',503);
    const timestamp=Math.floor(Date.now()/1000), folder='mithilana/products';
    const allowed_formats='jpg,jpeg,png,webp,avif',backup='false';
    const signature=crypto.createHash('sha1').update(`allowed_formats=${allowed_formats}&backup=${backup}&folder=${folder}&timestamp=${timestamp}${secret}`).digest('hex');
    res.json({cloud_name:cloud,api_key:key,timestamp,folder,signature,allowed_formats,backup});
  }catch(e){next(e)}
});
// Verify Cloudinary actually owns the image before accepting the URL into the catalog.
app.post('/api/admin/products/:id/cloudinary-image',requireAdmin,async(req,res,next)=>{
  try {
    const cloud=process.env.CLOUDINARY_CLOUD_NAME,key=process.env.CLOUDINARY_API_KEY,secret=process.env.CLOUDINARY_API_SECRET;
    if(!cloud||!key||!secret) throw publicError('Cloudinary is not configured.',503);
    const publicId=String(req.body.public_id||'');
    if(!/^mithilana\/products\/[a-zA-Z0-9_\/-]{1,180}$/.test(publicId)) throw publicError('Invalid image ID.');
    const auth=Buffer.from(`${key}:${secret}`).toString('base64');
    const response=await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/resources/image/upload/${publicId.split('/').map(encodeURIComponent).join('/')}`,{headers:{Authorization:`Basic ${auth}`},signal:AbortSignal.timeout(10000)});
    if(!response.ok) throw publicError('Could not verify uploaded image.',400);
    const asset=await response.json();
    if(asset.resource_type!=='image'||asset.type!=='upload'||!asset.secure_url||!asset.public_id.startsWith('mithilana/products/')) throw publicError('Invalid image asset.');
    const db=requireDb(), product=await db.query('SELECT id,name FROM products WHERE id=$1',[req.params.id]);
    if(!product.rowCount) throw publicError('Product not found.',404);
    const order=intField(req.body.sort_order??0,'image slot');
    if(order>3)throw publicError('Choose image slot 0 to 3.');
    imageLifecycle.validateAsset(asset);
    const image=await imageLifecycle.replaceImage(db,{productId:req.params.id,variantId:req.body.variant_id,slot:order,url:asset.secure_url,publicId:asset.public_id,alt:cleanText(req.body.alt_text||product.rows[0].name,250)});
    res.status(201).json({ok:true,image});
  }catch(e){next(e)}
});
app.get('/api/admin/image-cleanup',requireAdmin,async(req,res,next)=>{try{const q=await requireDb().query('SELECT id,state,attempts,last_error FROM image_cleanup_jobs ORDER BY id DESC LIMIT 100');res.json({ok:true,jobs:q.rows,cloudinaryConfigured:Boolean(process.env.CLOUDINARY_CLOUD_NAME&&process.env.CLOUDINARY_API_KEY&&process.env.CLOUDINARY_API_SECRET)})}catch(e){next(e)}});
app.get('/api/admin/products/:id/images',requireAdmin,async(req,res,next)=>{
  try{const r=await requireDb().query('SELECT id,image_url,alt_text,sort_order,is_active,variant_id FROM product_images WHERE product_id=$1 AND ($2::uuid IS NULL OR variant_id=$2) ORDER BY sort_order,created_at DESC',[req.params.id,req.query.variant_id||null]);res.json({ok:true,images:r.rows})}catch(e){next(e)}
});
app.post('/api/admin/products/:id/images',requireAdmin,async(req,res,next)=>{try{const url=String(req.body.image_url||'');let parsed;try{parsed=new URL(url)}catch{throw publicError('Enter a valid image URL.')}if(parsed.protocol!=='https:'||url.length>2000||parsed.username||parsed.password)throw publicError('Image URL must be HTTPS.');const slot=intField(req.body.sort_order??0,'image slot');if(slot>3)throw publicError('Choose image slot 0 to 3.');const image=await imageLifecycle.replaceImage(requireDb(),{productId:req.params.id,variantId:req.body.variant_id,slot,url,publicId:null,alt:cleanText(req.body.alt_text,250)});res.status(201).json({ok:true,image})}catch(e){next(e)}});
app.delete('/api/admin/images/:id',requireAdmin,async(req,res,next)=>{try{await imageLifecycle.deleteImage(requireDb(),req.params.id);res.json({ok:true,deleted:true})}catch(e){next(e)}});

// Orders: server calculates price from DB; client-submitted totals are never trusted.
// All money is computed in whole paise (integers) so the stored total, the Razorpay amount and the
// later payment check always agree exactly.
async function priceCart(q,items,offerCode,lock){return catalogV2.priceCart(q,items,offerCode,lock,APP_MODE)}

const orderLimiter=rateLimit({windowMs:60*60*1000,limit:30,keyGenerator:req=>req.user.sub,standardHeaders:'draft-7',legacyHeaders:false,message:{error:'Too many orders. Please try again later.'}});
app.post('/api/orders',requireCustomer,orderLimiter,async(req,res,next)=>{
  let client;
  try {
    const db=requireDb();
    const items=Array.isArray(req.body.items)?req.body.items:[];
    if(!items.length || items.length>100) throw publicError('Cart is empty or too large.');
    const offerCode=cleanText(req.body.offer_code,50).toUpperCase()||null;
    const method=req.body.payment_method||'cod';
    if(!['cod','razorpay'].includes(method)) throw publicError('Invalid payment method.');
    if(method==='razorpay' && (!RAZORPAY_KEY_ID||!RAZORPAY_KEY_SECRET||!RAZORPAY_WEBHOOK_SECRET))
      throw publicError('Online payment is not configured.',503);
    const address = req.body.shipping_address && typeof req.body.shipping_address === 'object' && !Array.isArray(req.body.shipping_address)
      ? req.body.shipping_address : null;
    if (!cleanText(req.body.shipping_name,200) || !address || !cleanText(address.line1,500) || !/^[1-9][0-9]{5}$/.test(String(address.pincode||'')) || !cleanText(address.city,120) || !cleanText(address.state,120)) throw publicError('Name, address and PIN code are required.');
    const shippingPhone=normalizePhone(req.body.shipping_phone)||req.user.phone;
    if(!shippingPhone) throw publicError('A valid mobile number is required for delivery.');
    // Keep only the known address fields, with limited length (no arbitrary JSON stored).
    const cleanAddress={};
    for(const k of ['line1','line2','landmark','city','state','pincode','country']) if(address[k]!==undefined) cleanAddress[k]=cleanText(address[k],k.startsWith('line')?500:120);

    const requestKey=String(req.headers['idempotency-key']||'');
    if(!/^[a-zA-Z0-9_-]{16,100}$/.test(requestKey))throw publicError('An idempotency key is required.');
    const requestHash=sha256(JSON.stringify({items,offerCode,method,name:cleanText(req.body.shipping_name,200),phone:shippingPhone,address:cleanAddress}));
    const orderId=crypto.randomUUID();
    let gateway=null, quotedTotalP=null;
    if(method==='razorpay'){
      // The slow Razorpay call happens BEFORE any database locks are taken.
      const quote=await priceCart(db,items,offerCode,false);
      if(quote.totalP<100) throw publicError('Online payment needs at least ₹1.');
      quotedTotalP=quote.totalP;
      gateway=await razorpayApi('POST','orders',{amount:quote.totalP,currency:'INR',receipt:orderId});
    }
    client=await db.connect();
    await client.query('BEGIN');
    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',[req.user.sub+':'+requestKey]);
    const existing=await client.query('SELECT id,status,total_amount,request_hash FROM orders WHERE customer_id=$1 AND idempotency_key=$2',[req.user.sub,requestKey]);
    if(existing.rowCount){if(existing.rows[0].request_hash!==requestHash)throw publicError('This request key was used for a different order.',409);await client.query('COMMIT');const {request_hash,...order}=existing.rows[0];return res.json({ok:true,order,replayed:true})}
    const priced=await priceCart(client,items,offerCode,true);
    if(gateway && priced.totalP!==quotedTotalP) throw publicError('Prices changed while placing the order. Please review your cart and try again.',409);
    const status=method==='razorpay'?'pending_payment':'placed';
    const order=await client.query(`
      INSERT INTO orders(id,customer_id,status,payment_method,payment_status,razorpay_order_id,subtotal,discount_amount,shipping_amount,total_amount,offer_id,shipping_name,shipping_phone,shipping_address,idempotency_key,request_hash)
      VALUES($1,$2,$3,$4,'pending',$5,$6,$7,0,$8,$9,$10,$11,$12,$13,$14) RETURNING id,status,total_amount`,
      [orderId,req.user.sub,status,method,gateway?.id||null,priced.subtotalP/100,priced.discountP/100,priced.totalP/100,
       priced.offer?.id||null,cleanText(req.body.shipping_name,200),shippingPhone,cleanAddress,requestKey,requestHash]);
    for(const x of priced.normalized){
      const label=x.variant.name+(x.variant.quality?' · '+x.variant.quality:'');
      await client.query(`INSERT INTO order_items(order_id,product_id,variant_id,variant_name,product_name,unit_price,quantity,line_total)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,[orderId,x.product.id,x.variant.id,label,x.product.name+' · '+label,x.variant.price,x.qty,x.lineP/100]);
      if(APP_MODE!=='test'){
        const u=await client.query('UPDATE product_variants SET stock=stock-$1,updated_at=clock_timestamp(),version=version+1 WHERE id=$2 AND stock>=$1 RETURNING stock',[x.qty,x.variant.id]);
        if(!u.rowCount)throw publicError('Insufficient pack stock.',409);
        await client.query('INSERT INTO inventory_history(variant_id,delta,stock_after,reason,order_id) VALUES($1,$2,$3,$4,$5)',[x.variant.id,-x.qty,u.rows[0].stock,'Order placed',orderId]);
      }
    }
    await client.query(`INSERT INTO order_status_history(order_id,status,note) VALUES($1,$2,$3)`,
      [orderId,status,method==='razorpay'?'Awaiting captured payment':'COD order created']);
    if(gateway) await client.query(`INSERT INTO payments(order_id,provider,provider_order_id,amount,status)
      VALUES($1,'razorpay',$2,$3,'created')`,[orderId,gateway.id,priced.totalP/100]);
    await adminOrderEmail.queue(client,orderId);
    await client.query('COMMIT');
    res.status(201).json({ok:true,order:order.rows[0],
      ...(gateway?{payment:{keyId:RAZORPAY_KEY_ID,providerOrderId:gateway.id,amount:gateway.amount,currency:'INR'}}:{})});
    // Receipt is visible in the customer profile; WhatsApp confirmation is sent only after admin confirmation.
  }catch(e){ if(client) await client.query('ROLLBACK').catch(()=>{}); next(e); }
  finally{ if(client) client.release(); }
});

// Data minimisation: keep only what is needed for reconciliation (no card, email or phone details).
function minimalPayment(p){
  return {id:p.id,order_id:p.order_id,status:p.status,amount:p.amount,currency:p.currency,method:p.method,captured:p.captured,created_at:p.created_at};
}
async function finalizeCapturedPayment(providerOrderId,paymentId,providerResponse){
  const client=await requireDb().connect();
  try{
    await client.query('BEGIN');
    const q=await client.query(`SELECT * FROM orders WHERE razorpay_order_id=$1 FOR UPDATE`,[providerOrderId]);
    if(!q.rowCount)throw publicError('Payment order not found.',404);
    const order=q.rows[0];
    if(order.payment_status==='paid'){
      if(order.razorpay_payment_id!==paymentId)throw publicError('Payment ID mismatch.',409);
      await client.query('COMMIT');return order;
    }
    if(order.status!=='pending_payment')throw publicError('Order is no longer payable. Contact support.',409);
    if(providerResponse.status!=='captured'||providerResponse.order_id!==providerOrderId||
       providerResponse.currency!=='INR'||Number(providerResponse.amount)!==Math.round(Number(order.total_amount)*100))
      throw publicError('Captured payment could not be verified.',409);
    await client.query(`UPDATE orders SET payment_status='paid',status='placed',razorpay_payment_id=$1,updated_at=NOW()
      WHERE id=$2`,[paymentId,order.id]);
    await client.query(`UPDATE payments SET provider_payment_id=$1,status='captured',raw_response=$2,updated_at=NOW()
      WHERE order_id=$3 AND provider='razorpay'`,[paymentId,minimalPayment(providerResponse),order.id]);
    await client.query(`INSERT INTO order_status_history(order_id,status,note)
      VALUES($1,'placed','Razorpay payment captured and verified')`,[order.id]);
    await client.query('COMMIT');return {...order,status:'placed',payment_status:'paid'};
  }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e}finally{client.release()}
}

app.post('/api/payments/razorpay/verify',requireCustomer,async(req,res,next)=>{
  try{
    const orderId=cleanText(req.body.order_id,100),paymentId=cleanText(req.body.payment_id,100);
    const signature=String(req.body.signature||'');
    if(!RAZORPAY_KEY_SECRET||!orderId||!paymentId||!/^[a-f0-9]{64}$/i.test(signature))
      throw publicError('Payment verification is not configured or details are invalid.');
    const ownership=await requireDb().query(`SELECT id FROM orders WHERE razorpay_order_id=$1 AND customer_id=$2`,[orderId,req.user.sub]);
    if(!ownership.rowCount)throw publicError('Order not found.',404);
    const expected=crypto.createHmac('sha256',RAZORPAY_KEY_SECRET).update(orderId+'|'+paymentId).digest('hex');
    if(!secureEqual(expected,signature))throw publicError('Payment signature mismatch.',401);
    const payment=await razorpayApi('GET','payments/'+encodeURIComponent(paymentId));
    const order=await finalizeCapturedPayment(orderId,paymentId,payment);
    res.json({ok:true,order:{id:order.id,status:order.status,total_amount:order.total_amount}});
  }catch(e){next(e)}
});

app.post('/api/payments/razorpay/webhook',async(req,res,next)=>{
  try{
    if(!RAZORPAY_WEBHOOK_SECRET||!req.rawBody)return res.sendStatus(503);
    const expected=crypto.createHmac('sha256',RAZORPAY_WEBHOOK_SECRET).update(req.rawBody).digest('hex');
    if(!secureEqual(expected,String(req.headers['x-razorpay-signature']||'')))return res.sendStatus(401);
    if(req.body.event==='payment.captured'){
      const entity=req.body.payload?.payment?.entity;
      if(entity?.order_id&&entity?.id){
        // Confirm payment status and amount with Razorpay API, then update once.
        const payment=await razorpayApi('GET','payments/'+encodeURIComponent(entity.id));
        await finalizeCapturedPayment(entity.order_id,entity.id,payment);
      }
    }
    res.sendStatus(200);
  }catch(e){next(e)}
});

// Admin order list/status. Every status change is audited.
app.get('/api/admin/orders',requireAdmin,async(req,res,next)=>{
  try { const db=requireDb(); const q=await db.query(`
    SELECT o.*,c.phone,c.name FROM orders o JOIN customers c ON c.id=o.customer_id
    ORDER BY o.created_at DESC LIMIT 500`);
    res.json({ok:true,orders:q.rows});
  }catch(e){next(e);}
});
app.patch('/api/admin/orders/:id/status',requireAdmin,async(req,res,next)=>{
  const allowed=['placed','confirmed','packed','shipped','out_for_delivery','delivered','cancelled'];
  const status=String(req.body.status||'');
  if(!allowed.includes(status)) return res.status(400).json({error:'Invalid order status.'});
  const db=requireDb(); const client=await db.connect();
  try{
    await client.query('BEGIN');
    const before=await client.query(`SELECT id,status FROM orders WHERE id=$1 FOR UPDATE`,[req.params.id]);
    if(!before.rowCount) throw publicError('Order not found.',404);
    const old=before.rows[0].status;
    if(old==='cancelled' || old==='delivered') throw publicError('This order is already finalized.',409);
    if(status===old) throw publicError('Order already has this status.',409);
    const transitions={pending_payment:['cancelled'],placed:['confirmed','cancelled'],confirmed:['packed','cancelled'],packed:['shipped','cancelled'],shipped:['out_for_delivery','cancelled'],out_for_delivery:['delivered','cancelled']};
    if(!transitions[old]?.includes(status)) throw publicError('Invalid status transition.',409);
    if(status==='cancelled')await catalogV2.restoreStock(client,req.params.id,APP_MODE);
    const q=await client.query(`UPDATE orders SET status=$1,updated_at=NOW() WHERE id=$2 RETURNING id,customer_id,status,total_amount`,[status,req.params.id]);
    await client.query(`INSERT INTO order_status_history(order_id,status,note,changed_by_admin_id) VALUES($1,$2,$3,$4)`,
      [req.params.id,status,`Status changed to ${status}`,req.admin.sub]);
    if(status!=='cancelled') await client.query(`INSERT INTO notification_outbox(order_id,status,phone) SELECT $1,$2,o.shipping_phone FROM orders o WHERE o.id=$3 ON CONFLICT(order_id,status) DO NOTHING`,[q.rows[0].id,status,q.rows[0].id]);
    await client.query('COMMIT');
    res.json({ok:true,order:q.rows[0]});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e);}finally{client.release();}
});

// WhatsApp webhook verification + inbound event receipt. Raw events are stored for debugging/audit.
app.get('/webhook', (req,res)=>{
  const mode=req.query['hub.mode']; const token=req.query['hub.verify_token']; const challenge=req.query['hub.challenge'];
  if(mode==='subscribe' && WHATSAPP_VERIFY_TOKEN && token===WHATSAPP_VERIFY_TOKEN) return res.status(200).send(String(challenge));
  res.sendStatus(403);
});
app.post('/webhook', async(req,res,next)=>{
  try{
    if (!verifyMetaSignature(req)) return res.sendStatus(403);
    const db=requireDb();
    await db.query(`INSERT INTO webhook_events(source,payload) VALUES('whatsapp',$1)`,[req.body]);
    res.sendStatus(200);
  }catch(e){next(e);}
});

// A DB-backed worker confirms received COD and captured online orders after five seconds. Safe across restarts
// and multiple server instances: SKIP LOCKED prevents the same transition racing.
async function confirmDueOrders(){
  if(!pool||AUTO_CONFIRM_SECONDS<=0)return;
  const client=await pool.connect();
  try {
    await client.query('BEGIN');
    const q=await client.query(`WITH due AS (
      SELECT id FROM orders WHERE status='placed'
        AND (payment_method='cod' OR (payment_method='razorpay' AND payment_status='paid'))
        AND updated_at <= NOW()-($1::integer*INTERVAL '1 second')
      ORDER BY created_at LIMIT 30 FOR UPDATE SKIP LOCKED
    ) UPDATE orders o SET status='confirmed',updated_at=NOW()
      FROM due WHERE o.id=due.id RETURNING o.id,o.customer_id`,[AUTO_CONFIRM_SECONDS]);
    for(const order of q.rows){
      await client.query(`INSERT INTO order_status_history(order_id,status,note) VALUES($1,'confirmed','Automatically confirmed')`,[order.id]);
      await client.query(`INSERT INTO notification_outbox(order_id,status,phone)
        SELECT $1,'confirmed',o.shipping_phone FROM orders o WHERE o.id=$1
        ON CONFLICT(order_id,status) DO NOTHING`,[order.id]);
    }
    await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e}finally{client.release()}
}
async function sendPendingNotifications(){
  if(!pool||!META_ACCESS_TOKEN||!META_PHONE_NUMBER_ID||!WHATSAPP_ORDER_STATUS_TEMPLATE)return;
  const q=await pool.query(`UPDATE notification_outbox SET next_attempt_at=NOW()+INTERVAL '5 minutes' WHERE id IN
    (SELECT id FROM notification_outbox WHERE state='pending' AND next_attempt_at<=NOW() ORDER BY id LIMIT 5 FOR UPDATE SKIP LOCKED)
    RETURNING id,order_id,status,phone,attempts`);
  for(const item of q.rows){try{const message=await sendWhatsAppTemplate(item.phone,WHATSAPP_ORDER_STATUS_TEMPLATE,WHATSAPP_ORDER_TEMPLATE_LANGUAGE,[{type:'body',parameters:[{type:'text',text:String(item.order_id)},{type:'text',text:item.status.replace(/_/g,' ')}]}]);await pool.query("UPDATE notification_outbox SET state='sent',sent_at=NOW(),attempts=attempts+1,provider_message_id=$1,last_error=NULL WHERE id=$2",[message.messages?.[0]?.id||null,item.id])}catch(e){const delay=Math.min(3600,Math.pow(2,Math.min(item.attempts+1,10))*5);await pool.query(`UPDATE notification_outbox SET attempts=attempts+1,next_attempt_at=NOW()+($1::integer*INTERVAL '1 second'),last_error=$2 WHERE id=$3`,[delay,String(e.message).slice(0,500),item.id])}}
}
let adminEmailBusy=false;
async function adminEmailWorker(){if(adminEmailBusy)return;adminEmailBusy=true;try{await adminOrderEmail.sendPending(pool)}catch(e){console.error('Admin email worker:',e.name)}finally{adminEmailBusy=false}}
setInterval(adminEmailWorker,10000).unref();
let imageCleanupBusy=false;
setInterval(async()=>{if(imageCleanupBusy||!pool)return;imageCleanupBusy=true;try{await imageLifecycle.cleanup(pool,ROOT)}catch(e){console.error('Image cleanup:',e.name)}finally{imageCleanupBusy=false}},10000).unref();
let workerBusy=false;
async function orderWorker(){
  if(workerBusy)return;workerBusy=true;
  try{await confirmDueOrders();await sendPendingNotifications()}catch(e){console.error('Order worker:',e.message)}finally{workerBusy=false}
}
setInterval(orderWorker,1000).unref();

// Data retention: drop leftover rows from the old OTP login and old raw WhatsApp webhook payloads (they contain customer phone numbers/messages).
async function cleanupOldData(){
  if(!pool)return;
  await pool.query('DELETE FROM revoked_sessions WHERE expires_at<NOW()');
  await pool.query(`DELETE FROM otp_requests WHERE expires_at < NOW()-INTERVAL '1 hour'`);
  await pool.query(`DELETE FROM webhook_events WHERE created_at < NOW()-INTERVAL '90 days'`);
}
setInterval(()=>cleanupOldData().catch(e=>console.error('Cleanup:',e.message)),60*60*1000).unref();
cleanupOldData().catch(()=>{});

// Unpaid online orders reserve stock the moment they are created. If the customer never pays, cancel the
// order after 60 minutes and give the stock back, so abandoned checkouts cannot lock products out of sale.
async function expireUnpaidOrders(){
  if(!pool)return;
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const due=await client.query(`SELECT id FROM orders WHERE status='pending_payment' AND payment_status='pending'
      AND created_at < NOW()-INTERVAL '60 minutes' ORDER BY created_at LIMIT 20 FOR UPDATE SKIP LOCKED`);
    for(const o of due.rows){
      await catalogV2.restoreStock(client,o.id,APP_MODE);
      await client.query(`UPDATE orders SET status='cancelled',updated_at=NOW() WHERE id=$1`,[o.id]);
      await client.query(`INSERT INTO order_status_history(order_id,status,note) VALUES($1,'cancelled','Unpaid online order expired automatically')`,[o.id]);
    }
    await client.query('COMMIT');
  }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e}finally{client.release()}
}
setInterval(()=>expireUnpaidOrders().catch(e=>console.error('Expire unpaid:',e.message)),5*60*1000).unref();

// Lists the size-wise product images placed in assets/product-images/ so the site only requests files that exist.
app.get('/api/product-images', (req,res)=>{
  const dir=path.join(ROOT,'assets','product-images');
  require('fs').readdir(dir,(err,names)=>{
    if(err)return res.json({files:{}});
    const files={};
    let pending=0;
    const ok=names.filter(n=>/^[a-z0-9-]+\.(webp|png|jpe?g|avif)$/.test(n));
    if(!ok.length)return res.json({files});
    pending=ok.length;
    ok.forEach(n=>require('fs').stat(path.join(dir,n),(e,st)=>{
      if(!e)files[n]=Math.floor(st.mtimeMs);
      if(--pending===0)res.json({files});
    }));
  });
});

app.use('/api', (req,res)=>res.status(404).json({error:'API route not found.'}));
// Only content-hashed files (image-<hash>, font-<hash>) are cached for a year. Scripts and other
// assets are revalidated, so an updated script reaches visitors immediately instead of staying stale.
app.use('/assets',async(req,res,next)=>{if(!/\.(?:jpe?g|png|webp|avif|svg|gif)$/i.test(req.path))return next();try{const q=await requireDb().query('SELECT image_url FROM retired_asset_urls WHERE image_url=$1',['/assets'+req.path]);if(q.rowCount)return res.sendStatus(404);next()}catch(e){next(e)}});
app.use('/assets',express.static(path.join(ROOT,'assets'),{etag:true,dotfiles:'deny',setHeaders:(res,filePath)=>{
  res.setHeader('Cache-Control',/[\\/](image|font)-[0-9a-f]{20}\./.test(filePath)?'public, max-age=31536000, immutable':'no-cache');
}}));

// Only these pages are public. server.js, SQL files, scripts and notes are never served.
const PAGES={'/admin':'admin.html','/admin/':'admin.html','/':'index.html','/index.html':'index.html','/admin.html':'admin.html','/privacy.html':'privacy.html','/refund-cancellation.html':'refund-cancellation.html','/terms.html':'terms.html'};
app.get(/.*/, (req,res)=>{
  if(req.path.split('/').some(part=>part.startsWith('.')))return res.status(404).type('text/plain').send('Not found');
  const file=PAGES[req.path];
  if(!file && path.extname(req.path)) return res.status(404).type('text/plain').send('Not found');
  res.setHeader('Cache-Control','no-store');
  if(file==='admin.html') res.setHeader('X-Robots-Tag','noindex, nofollow');
  res.sendFile(path.join(ROOT,file||'index.html'));
});

app.use((err,req,res,next)=>{
  // Log what is needed to debug, never request bodies (they can hold personal data).
  console.error(`[${new Date().toISOString()}] ${req.method} ${req.path} -> ${err.code||''} ${err.type==='entity.parse.failed'?'Invalid JSON body':err.message}`);
  let status=Number(err.status)||0;
  let message=err.message;
  if(!status){
    if(err.code==='23505'){status=409;message='This value already exists.'}
    else if(err.code==='23503'){status=409;message='A related record was not found.'}
    else if(['22P02','22003','22007','22001','23502','23514'].includes(err.code)){status=400;message='Invalid data supplied.'}
    else status=500;
  }
  if (err.type==='entity.parse.failed') message='Invalid JSON body.';
  if (err.type==='entity.too.large') message='Request body is too large.';
  res.status(status).json({error: status>=500 && !err.expose ? 'Server error. Please try again.' : message});
});

if(require.main===module)imageLifecycle.purgeRetiredAssets(requireDb(),ROOT).then(()=>app.listen(PORT,()=>console.log(`Mithilana server listening on ${PORT}`))).catch(e=>{console.error('Photo cleanup startup failed:',e.message);process.exitCode=1});
module.exports = { app, pool, secureEqual, verifyMetaSignature, priceCart, finalizeCapturedPayment };
