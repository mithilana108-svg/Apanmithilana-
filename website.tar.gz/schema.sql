CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone varchar(20) UNIQUE,
  google_sub varchar(255) UNIQUE,
  name varchar(200),
  email varchar(254),
  address_line1 text,
  address_line2 text,
  city varchar(120),
  state varchar(120),
  pincode varchar(20),
  preferred_language varchar(2) NOT NULL DEFAULT 'en' CHECK (preferred_language IN ('hi','en')),
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz,
  CONSTRAINT customer_identity_required CHECK (phone IS NOT NULL OR google_sub IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email varchar(254) UNIQUE NOT NULL,
  password_hash text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz
);

CREATE TABLE IF NOT EXISTS otp_requests (
  phone varchar(20) PRIMARY KEY,
  otp_hash char(64) NOT NULL,
  expires_at timestamptz NOT NULL,
  attempts integer NOT NULL DEFAULT 0 CHECK (attempts>=0),
  sent_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug varchar(180) UNIQUE NOT NULL,
  name varchar(200) NOT NULL,
  description text,
  base_price numeric(12,2) NOT NULL CHECK(base_price>=0),
  compare_at_price numeric(12,2) CHECK(compare_at_price IS NULL OR compare_at_price>=0),
  stock integer NOT NULL DEFAULT 0 CHECK(stock>=0),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS product_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  name varchar(200) NOT NULL,
  price numeric(12,2) NOT NULL CHECK(price>=0),
  stock integer NOT NULL DEFAULT 0 CHECK(stock>=0),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  image_url text NOT NULL,
  alt_text varchar(250),
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code varchar(50) UNIQUE NOT NULL,
  name varchar(200) NOT NULL,
  discount_type varchar(20) NOT NULL CHECK(discount_type IN ('percent','fixed')),
  discount_value numeric(12,2) NOT NULL CHECK(discount_value>=0),
  min_order_amount numeric(12,2) NOT NULL DEFAULT 0 CHECK(min_order_amount>=0),
  max_discount_amount numeric(12,2),
  starts_at timestamptz,
  ends_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
  status varchar(30) NOT NULL DEFAULT 'placed',
  payment_method varchar(20) NOT NULL DEFAULT 'cod',
  razorpay_order_id varchar(100) UNIQUE,
  razorpay_payment_id varchar(100) UNIQUE,
  payment_status varchar(20) NOT NULL DEFAULT 'pending',
  subtotal numeric(12,2) NOT NULL CHECK(subtotal>=0),
  discount_amount numeric(12,2) NOT NULL DEFAULT 0 CHECK(discount_amount>=0),
  shipping_amount numeric(12,2) NOT NULL DEFAULT 0 CHECK(shipping_amount>=0),
  total_amount numeric(12,2) NOT NULL CHECK(total_amount>=0),
  offer_id uuid REFERENCES offers(id) ON DELETE SET NULL,
  shipping_name varchar(200),
  shipping_phone varchar(20),
  shipping_address jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name varchar(200) NOT NULL,
  unit_price numeric(12,2) NOT NULL CHECK(unit_price>=0),
  quantity integer NOT NULL CHECK(quantity>0),
  line_total numeric(12,2) NOT NULL CHECK(line_total>=0),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS order_status_history (
  id bigserial PRIMARY KEY,
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  status varchar(30) NOT NULL,
  note text,
  changed_by_admin_id uuid REFERENCES admins(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  provider varchar(30) NOT NULL,
  provider_payment_id varchar(200),
  provider_order_id varchar(200),
  amount numeric(12,2) NOT NULL CHECK(amount>=0),
  status varchar(30) NOT NULL DEFAULT 'created',
  raw_response jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS webhook_events (
  id bigserial PRIMARY KEY,
  source varchar(50) NOT NULL,
  payload jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_products_active_sort ON products(is_active,sort_order);
CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(product_id,is_active);
CREATE INDEX IF NOT EXISTS idx_orders_customer_created ON orders(customer_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status_created ON orders(status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_status_history_order ON order_status_history(order_id,created_at);
CREATE INDEX IF NOT EXISTS idx_webhook_events_created ON webhook_events(created_at DESC);

-- Create the first admin yourself with the helper below, never store a plain password.
-- node scripts/create-admin.js admin@example.com "A-STRONG-PASSWORD"

-- Safe for databases created with older versions of schema.sql.
ALTER TABLE customers ADD COLUMN IF NOT EXISTS preferred_language varchar(2) NOT NULL DEFAULT 'en';

-- Durable confirmation notification queue. Applying schema.sql again is safe.
CREATE TABLE IF NOT EXISTS notification_outbox (
  id bigserial PRIMARY KEY,
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  status varchar(30) NOT NULL,
  phone varchar(20) NOT NULL,
  state varchar(20) NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','sent')),
  attempts integer NOT NULL DEFAULT 0,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  provider_message_id text,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  UNIQUE(order_id,status)
);
CREATE INDEX IF NOT EXISTS idx_notification_pending ON notification_outbox(next_attempt_at,id) WHERE state='pending';

CREATE TABLE IF NOT EXISTS admin_email_outbox (
 order_id UUID PRIMARY KEY REFERENCES orders(id) ON DELETE CASCADE,
 state TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','sent')),
 attempts INTEGER NOT NULL DEFAULT 0,
 next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 sent_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_admin_email_pending ON admin_email_outbox(next_attempt_at) WHERE state='pending';
