'use strict';
const lifecycle=require('./image-lifecycle');
const {transaction}=require('./catalog-v2');
const fail=(message,status=400)=>Object.assign(new Error(message),{status});
const listing=`SELECT category,display_name,image_url,sort_order,version FROM category_covers UNION ALL SELECT DISTINCT p.category,p.category,NULL,1000,0 FROM products p WHERE p.legacy_parent_id IS NULL AND NOT EXISTS(SELECT 1 FROM category_covers c WHERE c.category=p.category) ORDER BY sort_order,category`;
function register(app,{requireDb,requireAdmin}){
 app.get('/api/categories',async(req,res,next)=>{try{res.setHeader('Cache-Control','no-store');res.json({categories:(await requireDb().query(listing)).rows})}catch(e){next(e)}});
 app.put('/api/admin/category-cover',requireAdmin,async(req,res,next)=>{try{
  const category=require('./category-names').canonicalCategory(String(req.body.category||'')),name=String(req.body.display_name||'').trim(),order=Number(req.body.sort_order),version=Number(req.body.expected_version);
  if(!category||category.length>120||!name||name.length>120||!Number.isSafeInteger(order)||order<0||order>10000||!Number.isSafeInteger(version)||version<0)throw fail('Enter a category name, display name, order (0–10000) and current version.');
  const remove=req.body.remove_image===true;if(remove&&req.body.public_id)throw fail('Choose delete or upload, not both.');
  let asset=null;
  if(req.body.public_id){const cloud=process.env.CLOUDINARY_CLOUD_NAME,key=process.env.CLOUDINARY_API_KEY,secret=process.env.CLOUDINARY_API_SECRET,id=String(req.body.public_id);
   if(!cloud||!key||!secret)throw fail('Cloudinary is not configured.',503);
   if(!/^mithilana\/products\/[a-zA-Z0-9_\/-]{1,180}$/.test(id))throw fail('Invalid image ID.');
   const response=await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/resources/image/upload/${id.split('/').map(encodeURIComponent).join('/')}`,{headers:{Authorization:'Basic '+Buffer.from(key+':'+secret).toString('base64')},signal:AbortSignal.timeout(10000)});
   if(!response.ok)throw fail('Could not verify uploaded cover.');asset=await response.json();
   if(asset.public_id!==id||asset.resource_type!=='image'||asset.type!=='upload'||!asset.secure_url?.startsWith('https://res.cloudinary.com/'))throw fail('Invalid cover asset.');lifecycle.validateAsset(asset);
  }
  const result=await transaction(requireDb(),async c=>{
   await c.query('SELECT pg_advisory_xact_lock(hashtext($1))',['category:'+category]);
   let old=(await c.query('SELECT * FROM category_covers WHERE category=$1 FOR UPDATE',[category])).rows[0];
   if(!old){if(!(await c.query('SELECT id FROM products WHERE category=$1 AND legacy_parent_id IS NULL LIMIT 1',[category])).rowCount)throw fail('Category not found.',404);await c.query('INSERT INTO category_covers(category,display_name,sort_order) VALUES($1,$1,1000)',[category]);old=(await c.query('SELECT * FROM category_covers WHERE category=$1',[category])).rows[0]}
   if(old.version!==version)throw fail('Category changed. Load categories again before saving.',409);
   if(asset){await c.query('SELECT pg_advisory_xact_lock(hashtext($1))',[asset.secure_url]);if((await c.query('SELECT image_url FROM retired_asset_urls WHERE image_url=$1',[asset.secure_url])).rowCount)throw fail('This photo was deleted. Upload a fresh photo.')}
   const r=await c.query('UPDATE category_covers SET display_name=$2,sort_order=$3,image_url=$4,cloud_public_id=$5,version=version+1 WHERE category=$1 RETURNING *',[category,name,order,remove?null:asset?asset.secure_url:old.image_url,remove?null:asset?asset.public_id:old.cloud_public_id]);
   if(old.image_url&&(remove||(asset&&old.image_url!==asset.secure_url)))await lifecycle.retire(c,[old]);return r.rows[0];
  });require('./media-events').broadcast();res.json({ok:true,category:result});
 }catch(e){next(e)}});
}
module.exports={register};
