# Validation — Mithilana corrected package

12 October 2026. Isolated tests; production was not modified.

- 28 PostgreSQL-compatible integration checks passed (PGlite, single connection adapter).
- 7 browser UI checks passed (desktop/mobile, provider calls simulated).
- 18 offline catalog assertions passed.
- 38 offline non-Razorpay security assertions passed.
- Original dependency tree retained (no new production dependencies); prior dependency audit reported zero known vulnerabilities.

## Database and API checks

- Maximum validated product and pack names fit order snapshots.

- Migration preserves legacy pack price, stock, active state
- Migration rerun does not reset pack stock
- Unauthenticated admin access blocked
- Public catalog v2 hides numbered legacy products
- Public catalog includes exact active variant IDs
- Custom category/weight/quality product created transactionally
- Arbitrary second pack added
- Pack rate and custom weight saved
- Stale pack update rejected
- Atomic stock reduction changes only chosen pack
- Negative stock rejected
- Custom product checkout uses selected pack price
- Retry returns same order and deducts stock once
- Reused request key with changed payload rejected
- Cross-product pack ID rejected
- Cancellation restores exact selected pack
- Double cancellation cannot duplicate stock
- Replacement removes old photo record instead of hiding it
- Replacement leaves other weight photo intact
- Unreferenced old Cloudinary photo is destroyed and cleanup job removed
- Provider asset format validated on server
- Archived product disappears from API
- Archived product cannot be purchased
- Archived product retains historic order
- Logout revokes copied token
- Reversed coupon dates rejected
- Admin seller settings can be published safely
- Admin logout invalidates copied admin token

## Browser checks

- Admin catalog renders without runtime error
- Admin creates custom product/category/75g price and stock
- Admin adds second custom 150g quality pack
- Admin uploads and replaces exact pack photo without retaining old image row (provider mocked)
- Mobile 150g button adds exact 150g UUID and ₹240
- Mobile admin fits viewport
- No page JavaScript errors in admin/storefront

## Limits

No live Google sign-in, real Cloudinary upload/deletion, Razorpay payments or production database migration was performed. Stock transactions were exercised against an isolated PostgreSQL-compatible engine; independent PostgreSQL sessions under production load remain to be checked after deployment. Provider mocks do not prove that real credentials, permissions or CDN invalidation succeed. Previous provider backups and externally saved copies cannot be certified erased.

## Landscape admin and batch photos regression

- Desktop landscape cards render side by side
- Technical slug field removed; backend generates ID
- Card opens product editor with category/rate/stock controls
- Editor stays open after save and shows fresh custom pack
- One selection uploads front/back/ingredients to three separate slots
- Replacing front removes old record and keeps back/ingredients
- Category filter and search return matching cards
- Mobile cards scroll horizontally without body overflow
- Mobile card opens responsive editor
- No admin JavaScript errors

62 JavaScript files passed syntax checks. The provider was simulated for uploads; real Cloudinary/Google login still needs a secure authenticated session.
