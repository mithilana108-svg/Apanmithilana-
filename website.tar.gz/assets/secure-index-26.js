
(function(){
  function normalizeProducts(){
    if(typeof products==='undefined') return;
    // Exactly one of each Dry Fruit: Kishmish, Badam, Kaju.
    const wanted=['raisins','almonds','cashews'];
    const seen=new Set();
    for(let i=products.length-1;i>=0;i--){
      const p=products[i];
      if(wanted.includes(p.id)){
        if(seen.has(p.id)) products.splice(i,1); else seen.add(p.id);
      }
    }
    const r=products.find(p=>p.id==='raisins'); if(r){r.cat='Dry Fruits';r.name='Golden Raisins (Kishmish)';}
    const a=products.find(p=>p.id==='almonds'); if(a){a.cat='Dry Fruits';a.name='Golden Almonds (Badam)';}
    const k=products.find(p=>p.id==='cashews'); if(k){k.cat='Dry Fruits';k.name='Golden Cashews (Kaju)';}
  }
  function renderRange(){
    const grid=document.getElementById('productGrid');
    if(!grid || typeof products==='undefined' || typeof productCard!=='function') return;
    const list=products.filter(p=>p.cat!=='Combo');
    grid.innerHTML=list.map(productCard).join('');
    list.forEach(p=>{
      const s=document.getElementById('v-'+p.id);
      if(s)s.addEventListener('change',()=>{const el=document.getElementById('price-'+p.id);if(el)el.textContent=money(p.variants[s.value].price)});
    });
  }
  function bindImageOpening(){
    const grid=document.getElementById('productGrid');
    if(!grid || grid.dataset.imageOpenBound==='1') return;
    grid.dataset.imageOpenBound='1';
    grid.addEventListener('click',function(e){
      const img=e.target.closest('.product-img img');
      if(!img) return;
      const card=img.closest('.product');
      if(!card) return;
      const id=((card.dataset.mithId ? "openProductDetail('"+card.dataset.mithId+"')" : '')).match(/openProductDetail\('([^']+)'\)/)?.[1];
      if(id && typeof window.openProductDetail==='function'){
        e.preventDefault();e.stopPropagation();window.openProductDetail(id);
      }
    },true);
  }
  function run(){normalizeProducts();renderRange();bindImageOpening();}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',run,{once:true}); else run();
})();
