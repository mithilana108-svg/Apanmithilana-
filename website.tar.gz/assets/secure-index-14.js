
(function(){
  'use strict';
  var COMPANY='mithCompanySection';
  var PRODUCT_HASH='#categories';
  function goProducts(){
    var el=document.getElementById('categories');
    if(el){el.scrollIntoView({behavior:'smooth',block:'start'});}
    try{history.replaceState({mithBasePage:true,mithSection:'products'},'',location.pathname+location.search+PRODUCT_HASH);}catch(e){location.hash='categories';}
  }
  // About My Company: make Android/browser Back return to the product-range section.
  document.addEventListener('click',function(e){
    var a=e.target.closest && e.target.closest('a[href="#about-my-company"]');
    if(!a)return;
    e.preventDefault();
    try{
      // Keep a real intermediate Product Range history step so Back from Company
      // returns exactly one section backward instead of leaving/minimizing the site.
      history.pushState({mithSection:'products',mithBasePage:true},'',location.pathname+location.search+'#categories');
      history.pushState({mithSection:'company',mithBasePage:true},'',location.pathname+location.search+'#about-my-company');
    }catch(err){location.hash='about-my-company';}
    var el=document.getElementById('about-my-company');
    if(el)el.scrollIntoView({behavior:'smooth',block:'start'});
  },true);
  window.addEventListener('popstate',function(e){
    if(e.state && e.state.mithSection==='products'){
      goProducts();
      return;
    }
  },true);
  // If the section is opened directly, the first Back should still land on products.
  if(location.hash==='#about-my-company'){
    setTimeout(function(){
      try{history.replaceState({mithSection:'company',mithBasePage:true},'',location.href);}catch(e){}
    },0);
  }
  // Force the cart X to close reliably, even if another delegated handler intercepts clicks.
  function closeCartHard(){
    var c=document.getElementById('cart'),o=document.getElementById('overlay');
    if(c)c.classList.remove('open');
    if(o)o.classList.remove('open');
    document.body.style.overflow='';
    document.documentElement.style.overflow='';
  }
  document.addEventListener('click',function(e){
    var b=e.target.closest && e.target.closest('#closeCart');
    if(!b)return;
    e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
    closeCartHard();
  },true);
  document.addEventListener('touchend',function(e){
    var b=e.target.closest && e.target.closest('#closeCart');
    if(!b)return;
    e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
    closeCartHard();
  },true);
})();
