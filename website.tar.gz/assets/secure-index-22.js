
(function(){
 const money2=n=>'₹'+Number(n||0).toLocaleString('en-IN');
 // Replace checkout form node to remove older submit handlers that forced login/PIN gating.
 const old=document.getElementById('checkoutForm');
 if(old){
   const form=old.cloneNode(true); old.replaceWith(form);
   const pay=form.querySelector('[name="payment"]');
   if(pay){pay.innerHTML='<option value="cod">Cash on Delivery</option><option value="upi" disabled>UPI / Online Payment — gateway setup pending</option>'}
   form.addEventListener('submit',function(e){
     e.preventDefault();
     if(!window.cart||!window.cart.length){alert('Your cart is empty.');return}
     const fd=new FormData(form), phone=String(fd.get('phone')||'').replace(/\D/g,'');
     if(phone.length!==10){alert('Please enter a valid 10 digit mobile number.');return}
     const total=window.cart.reduce((a,x)=>a+Number(x.price||0)*Number(x.qty||0),0);
     const order={id:'MIT-'+Date.now().toString().slice(-7),name:String(fd.get('name')||''),phone,address:String(fd.get('address')||''),payment:'cod',items:JSON.parse(JSON.stringify(window.cart.map(({img,...rest})=>rest))),total,created:new Date().toISOString(),status:'Order received'};
     const orders=JSON.parse(localStorage.getItem('mithilana_orders')||'[]'); orders.push(order); localStorage.setItem('mithilana_orders',JSON.stringify(orders));
     try{ if(typeof sendWhatsApp==='function') sendWhatsApp(`Mithilana New Order ${htmlEscape(order.id)}\nName: ${htmlEscape(order.name)}\nPhone: ${order.phone}\nAddress: ${order.address}\nPayment: COD\nTotal: ${money2(total)}\n\n`+order.items.map(x=>`${htmlEscape(x.name)} | ${htmlEscape(x.label)} | Qty ${x.qty}`).join('\n')); }catch(_){ }
     window.cart.length=0; if(typeof save==='function')save(); form.reset(); document.getElementById('checkoutModal')?.classList.remove('open');
     document.getElementById('mithOrderSuccessText').innerHTML=`Thank you, <b>${htmlEscape(order.name)}</b>.<br>Order ID: <b>${htmlEscape(order.id)}</b><br>Total: <b>${money2(total)}</b><br><br>Save this ID for tracking and one-tap reorder.`;
     document.getElementById('mithOrderSuccess').classList.add('open');
   });
 }
 document.getElementById('mithOrderClose')?.addEventListener('click',()=>document.getElementById('mithOrderSuccess').classList.remove('open'));
 document.getElementById('mithTrackBtn')?.addEventListener('click',()=>{
   const id=document.getElementById('mithTrackId').value.trim().toUpperCase(), out=document.getElementById('mithTrackResult');
   const orders=JSON.parse(localStorage.getItem('mithilana_orders')||'[]'); const o=orders.find(x=>String(x.id).toUpperCase()===id);
   if(!o){out.textContent='Order not found on this device. Live courier tracking will activate when the delivery partner/API is connected.';return}
   out.innerHTML=`<b>${htmlEscape(o.id)}</b><br>Status: ${htmlEscape(o.status||'Order received')}<br>${new Date(o.created).toLocaleString()}<br>Total: ${money2(o.total)}<br><button id="mithReorderBtn" style="margin-top:8px">Reorder</button>`;
   document.getElementById('mithReorderBtn').onclick=()=>{ if(!Array.isArray(window.cart))return; o.items.forEach(it=>{const ex=window.cart.find(x=>x.key===it.key);if(ex)ex.qty+=it.qty;else window.cart.push({...it})});if(typeof save==='function')save();if(typeof openCart==='function')openCart();};
 });
 let rating=5; document.querySelectorAll('#mithStars button').forEach(b=>b.onclick=()=>{rating=Number(b.dataset.r);document.querySelectorAll('#mithStars button').forEach(x=>x.style.opacity=Number(x.dataset.r)<=rating?'1':'.3')});
 function drawReviews(){const a=JSON.parse(localStorage.getItem('mithilana_reviews')||'[]');document.getElementById('mithReviews').innerHTML=a.slice().reverse().map(r=>`<div class="mith-review"><b>${'★'.repeat(Math.max(1,Math.min(5,Number(r.rating)||5)))}${'☆'.repeat(5-Math.max(1,Math.min(5,Number(r.rating)||5)))} · ${htmlEscape(r.name)}</b><br>${htmlEscape(r.text)}</div>`).join('')||'<small>No reviews yet.</small>'}
 document.getElementById('mithReviewAdd')?.addEventListener('click',()=>{const n=document.getElementById('mithReviewName').value.trim(),t=document.getElementById('mithReviewText').value.trim();if(!n||!t){alert('Please add your name and review.');return}const a=JSON.parse(localStorage.getItem('mithilana_reviews')||'[]');a.push({name:n,text:t,rating,created:new Date().toISOString()});localStorage.setItem('mithilana_reviews',JSON.stringify(a));document.getElementById('mithReviewText').value='';drawReviews()}); drawReviews();
 const phase=document.getElementById('mithPhase2'), footer=document.querySelector('footer'); if(phase&&footer?.parentNode)footer.parentNode.insertBefore(phase,footer);
})();
