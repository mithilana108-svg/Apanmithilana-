
(function(){
  // Never lock the scroll container itself; only the page underneath is locked while a foreground page is open.
  function sync(){
    var cat=document.getElementById('categoryPage');
    if(cat && cat.classList.contains('open')){
      cat.style.overflowY='auto';
      cat.style.touchAction='pan-y';
    }
    var detail=document.querySelector('#productDetailModal .product-detail-card');
    if(detail && document.getElementById('productDetailModal')?.classList.contains('open')){
      detail.style.overflowY='auto';
      detail.style.touchAction='pan-y';
    }
  }
  document.addEventListener('DOMContentLoaded',sync,{once:true});
  new MutationObserver(sync).observe(document.documentElement,{subtree:true,attributes:true,attributeFilter:['class']});
})();
