
(async function(){
 if(location.protocol==='file:'||location.protocol==='content:')return;
 try{
  const response=await fetch('/api/products');
  if(!response.ok)return;
  const data=await response.json();
  const bySlug=new Map((data.products||[]).map(x=>[x.slug,x]));
  const imageBySlug=new Map((data.catalog_images||[]).map(x=>[x.slug,x.image_url]));
  for(const p of window.products||[]){
   for(let i=0;i<p.variants.length;i++){
    const live=bySlug.get(p.id+'-'+i);
    if(live){
      p.variants[i].price=Number(live.base_price);
      p.variants[i].available=Number(live.stock)>0;
    }
    const image=imageBySlug.get(p.id+'-'+i)||live?.image_url;
    if(image){
      p.variants[i].liveImage=image;
      if(i===0)p.img=image;
    }
   }
  }
  if(typeof renderProducts==='function')renderProducts('All');
  if(Array.isArray(window.cart)){
   for(const item of window.cart){const p=window.products.find(x=>x.id===item.id);const v=p?.variants[item.vi];if(v)item.price=v.price;}
   if(typeof save==='function')save();
  }
 }catch(error){console.warn('Catalog API unavailable:',error.message)}
})();
