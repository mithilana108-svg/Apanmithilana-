
(function(){
  'use strict';
  var GUARD='mithV36BackGuard';
  var BASE='mithV36Base';
  var PRODUCT='mithProductPage';
  var CATEGORY='mithCategoryPage';
  var seeded=false;

  function state(){return (history.state && typeof history.state==='object') ? history.state : {}; }
  function isProduct(){var m=document.getElementById('productDetailModal');return !!(m&&m.classList.contains('open'));}
  function isCategory(){var m=document.getElementById('categoryPage');return !!(m&&m.classList.contains('open'));}

  function seed(){
    var st=Object.assign({},state());
    if(!st[BASE] && !st[GUARD] && !st[PRODUCT] && !st[CATEGORY] && !st.mithilanaOverlay){
      st[BASE]=true;
      history.replaceState(st,'',location.href);
    }
    if(!(history.state&&history.state[GUARD]) && !history.state?.[PRODUCT] && !history.state?.[CATEGORY] && !history.state?.mithilanaOverlay){
      var g=Object.assign({},history.state||{});
      g[GUARD]=true;
      history.pushState(g,'',location.href);
    }
    seeded=true;
  }

  function restoreGuard(){
    if(!seeded)return;
    var st=state();
    if(st[BASE] && !st[GUARD] && !isProduct() && !isCategory() && !st.mithilanaOverlay){
      var g=Object.assign({},st); g[GUARD]=true; history.pushState(g,'',location.href);
    }
  }

  // Do not interfere with product/category one-step Back. Those states are consumed first.
  window.addEventListener('popstate',function(e){
    var st=e.state||{};
    if(st[PRODUCT] || st[CATEGORY] || st.mithilanaOverlay) return;
    // If the foreground page has just closed, the earlier history controller already handled it.
    // At the site root, restore a guard entry so Back never minimizes/quits the page.
    setTimeout(restoreGuard,0);
  },false);

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',seed,{once:true});
  else seed();
})();
