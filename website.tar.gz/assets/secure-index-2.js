
(function(){
  document.addEventListener('click', function(e){
    var t=e.target && e.target.closest ? e.target.closest('#detailClose') : null;
    if(!t) return;
    var m=document.getElementById('productDetailModal');
    if(!m || !m.classList.contains('open')) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    try{
      if(history.state && history.state.mithProductPage){ history.back(); return; }
    }catch(err){}
    try{
      if(typeof closeProductDetail==='function') closeProductDetail();
      else m.classList.remove('open');
    }catch(err2){ m.classList.remove('open'); }
  }, true);
})();
 