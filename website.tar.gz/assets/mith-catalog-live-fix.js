(async()=>{
try{
 const response=await fetch('/api/products',{cache:'no-store'});if(!response.ok)return;
 const data=await response.json(),records=data.products||[],products=window.products||[];
 const managed=JSON.parse(sessionStorage.getItem('mithManagedSlugs')||'[]'),active=new Set(records.map(x=>x.slug));
 for(let i=products.length-1;i>=0;i--)if(managed.includes(products[i].id)&&!active.has(products[i].id))products.splice(i,1);
 const tracked=new Set(managed);
 for(const x of records){
  const images=(x.images||[]).map(i=>i.url).filter(Boolean),found=products.find(p=>p.id===x.slug);
  if(found){found.livePhotos=images;if(images.length){found.img=images[0];if(found.variants?.[0])found.variants[0].liveImage=images[0];}continue;}
  if(/-[0-9]+$/.test(x.slug)&&products.some(p=>x.slug.startsWith(p.id+'-')))continue;
  const variants=x.variants?.length?x.variants.map(v=>({label:v.name||'Standard',price:Number(v.price),available:Number(v.stock)>0})):[{label:'Standard',price:Number(x.base_price),available:Number(x.stock)>0}];
  products.push({id:x.slug,name:x.name,desc:x.description||'',cat:'New Products',img:images[0]||'',livePhotos:images,variants,dbProductId:x.id});tracked.add(x.slug);
 }
 sessionStorage.setItem('mithManagedSlugs',JSON.stringify([...tracked]));
 if(products.some(p=>p.cat==='New Products')&&!document.querySelector('[data-filter="New Products"]')){
  const btn=document.createElement('button');btn.type='button';btn.className='mith-range-card';btn.dataset.filter='New Products';btn.textContent='New Products';
  btn.addEventListener('click',()=>{renderProducts('New Products');document.getElementById('products').scrollIntoView({behavior:'smooth'})});document.querySelector('.cat-grid')?.append(btn);
 }
 if(typeof renderProducts==='function')renderProducts('All');
 const grid=document.getElementById('productGrid');
 function galleries(){
  grid?.querySelectorAll('.pm-img,.product-img').forEach(box=>{
   if(box.dataset.galleryReady)return;
   const card=box.closest('.pm-card,.product'),id=card?.dataset.pmId||card?.dataset.mithId,p=products.find(x=>x.id===id),photos=p?.livePhotos||[];
   if(photos.length<2)return;const img=box.querySelector('img');if(!img)return;
   box.dataset.galleryReady='1';box.style.position='relative';let index=0,start=0;img.src=photos[0];
   const count=document.createElement('span');count.textContent='1 / '+photos.length;count.style.cssText='position:absolute;bottom:8px;left:50%;transform:translateX(-50%);background:#ffffffe8;border-radius:12px;padding:2px 8px;z-index:3;font-size:12px';box.append(count);
   const move=d=>{index=(index+d+photos.length)%photos.length;img.src=photos[index];count.textContent=(index+1)+' / '+photos.length};
   box.addEventListener('touchstart',e=>{start=e.touches[0].clientX},{passive:true});box.addEventListener('touchend',e=>{const d=e.changedTouches[0].clientX-start;if(Math.abs(d)>40)move(d<0?1:-1)},{passive:true});
   for(const [label,d,side] of [['‹',-1,'left'],['›',1,'right']]){const b=document.createElement('button');b.type='button';b.textContent=label;b.setAttribute('aria-label',d<0?'Previous photo':'Next photo');b.style.cssText='position:absolute;top:45%;'+side+':4px;z-index:3;background:#ffffffe8;border:0;border-radius:20px;padding:2px 10px;font-size:23px';b.onclick=e=>{e.preventDefault();e.stopPropagation();move(d)};box.append(b)}
  });
 }
 if(grid){new MutationObserver(galleries).observe(grid,{childList:true});galleries()}
}catch(e){console.warn('Live catalog sync',e)}
})();
