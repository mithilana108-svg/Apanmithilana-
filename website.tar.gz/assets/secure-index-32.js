
(function(){
 const page=document.getElementById('mithFeaturePage'), body=document.getElementById('mithFeatureBody'), title=document.getElementById('mithFeatureTitle');
 if(!page||!body)return;
 const originals={};

 function lang(){return localStorage.getItem('mithilana_language')==='hi'?'hi':'en'}
 const titles={
   builder:{en:'Build Your Own Box',hi:'अपना बॉक्स बनाएं'},
   tracking:{en:'Track Your Order',hi:'अपना ऑर्डर ट्रैक करें'},
   reviews:{en:'Customer Reviews',hi:'ग्राहक रिव्यू'},
   productinfo:{en:'Ingredients & Nutrition',hi:'सामग्री और पोषण'}
 };

 function moveInto(el,key){
   if(!el)return false;
   if(!originals[key]) originals[key]={el,parent:el.parentNode,next:el.nextSibling};
   body.appendChild(el); return true;
 }
 function restore(){
   Object.values(originals).forEach(o=>{
     if(o.el && o.parent){
       if(o.next && o.next.parentNode===o.parent)o.parent.insertBefore(o.el,o.next);
       else o.parent.appendChild(o.el);
     }
   });
   for(const k of Object.keys(originals)) delete originals[k];
   body.innerHTML='';
 }
 function makeInfo(){
   const hi=lang()==='hi';
   body.innerHTML=`<div class="mith-info-note">${hi?'हर प्रोडक्ट की verified सामग्री और Nutrition values मिलने पर यहाँ वही प्रकाशित होंगी। कोई अनुमानित food data नहीं दिखाया जाएगा।':'Only verified product ingredients and nutrition values will be published here. No estimated food data will be shown.'}</div>
   <div class="mith-info-grid">
    <div class="mith-info-card"><h3>${hi?'सामग्री':'Ingredients'}</h3><p>${hi?'हर flavour/product की वास्तविक ingredient list यहाँ product-wise दिखाई जाएगी।':'The actual ingredient list will appear here product-by-product and flavour-by-flavour.'}</p></div>
    <div class="mith-info-card"><h3>${hi?'पोषण जानकारी':'Nutrition Information'}</h3><p>${hi?'Verified nutrition panel मिलने के बाद energy, protein, carbohydrate, fat आदि values जोड़ी जाएँगी।':'Energy, protein, carbohydrate, fat and other values will be added after the verified nutrition panel is available.'}</p></div>
    <div class="mith-info-card"><h3>${hi?'एलर्जन / जरूरी जानकारी':'Allergen / Important Information'}</h3><p>${hi?'Applicable allergen और statutory product information verified packaging data के अनुसार दिखाई जाएगी।':'Applicable allergen and statutory product information will follow the verified packaging data.'}</p></div>
   </div>`;
 }
 function show(kind,push=true){
   restore();
   let ok=false;
   if(kind==='builder') ok=moveInto(document.getElementById('mithBuildBox'),'builder');
   if(kind==='tracking'){
      const cards=[...document.querySelectorAll('.mith-p2-card')];
      const c=cards.find(x=>/Track Your Order/i.test(x.textContent||'')); ok=moveInto(c,'tracking');
   }
   if(kind==='reviews'){
      const cards=[...document.querySelectorAll('.mith-p2-card')];
      const c=cards.find(x=>/^Reviews/i.test((x.textContent||'').trim())); ok=moveInto(c,'reviews');
   }
   if(kind==='productinfo'){makeInfo();ok=true}
   if(!ok){body.innerHTML='<p>This feature is being prepared.</p>'}
   title.textContent=(titles[kind]||titles.builder)[lang()];
   page.classList.add('open'); page.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden';
   if(push) history.pushState({mithFeature:kind},'',location.href.split('#')[0]+'#'+kind);
 }
 function close(push=false){
   restore(); page.classList.remove('open');page.setAttribute('aria-hidden','true');document.body.style.overflow='';
   if(push) history.pushState({mithNav:'mithilanaNavV1',kind:'home'},'',location.href.split('#')[0]);
 }
 document.addEventListener('click',e=>{
   const a=e.target.closest('[data-mith-page]');
   if(a){e.preventDefault();show(a.dataset.mithPage,true)}
 });
 document.getElementById('mithFeatureBack')?.addEventListener('click',()=>history.back());
 window.addEventListener('popstate',e=>{
   if(e.state&&e.state.mithFeature)show(e.state.mithFeature,false); else close(false);
 });
 // Language selector remains visible at all times in the main navigation.
 document.getElementById('mithLangNavBtn')?.addEventListener('click',()=>{
   const choice=document.getElementById('languageChoice');
   if(choice){choice.classList.add('open'); choice.style.display='flex';}
 });
 // Keep the chooser usable even after it has been used once.
 document.querySelectorAll('#languageChoice [data-lang]').forEach(b=>b.addEventListener('click',()=>{
   setTimeout(()=>{
     const choice=document.getElementById('languageChoice'); if(choice) choice.style.display='';
     const s=history.state;if(s&&s.mithFeature) title.textContent=(titles[s.mithFeature]||titles.builder)[lang()];
     const navText=lang()==='hi'
       ? ['होम','श्रेणियाँ','हमारी संस्कृति','अपना बॉक्स बनाएं','ऑर्डर ट्रैक करें','रिव्यू','सामग्री और पोषण']
       : ['HOME','CATEGORIES','ABOUT OUR CULTURE','BUILD YOUR BOX','TRACK ORDER','REVIEWS','INGREDIENTS & NUTRITION'];
     document.querySelectorAll('#mithMainNav a').forEach((x,i)=>{if(navText[i])x.textContent=navText[i]});
   },0);
 }));
 // Hide the old in-page builder from the homepage; it is now opened as its own page.
 const builder=document.getElementById('mithBuildBox');
 if(builder) builder.style.display='none';
 document.addEventListener('click',e=>{
   const a=e.target.closest('[data-mith-page="builder"]');
   if(a&&builder) builder.style.display='';
 },true);
})();
