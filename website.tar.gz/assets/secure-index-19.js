
(()=>{
 const modal=document.getElementById('loginModal');
 if(!modal)return;
 const heading=modal.querySelector('.login-box h2');
 if(heading)heading.textContent='Login with Google';
 const help=modal.querySelector('.login-box .muted');
 if(help)help.textContent='Sign in with your Google account to continue.';
 const googleSection=document.getElementById('mithGoogleLogin');
 const status=document.getElementById('mithGoogleStatus');
 // Put both choices together in the foreground login panel, with Google first.
 const phoneStep=document.getElementById('otpStepPhone');
 if(googleSection&&phoneStep)phoneStep.parentNode.insertBefore(googleSection,phoneStep);
 if(googleSection){
  googleSection.style.margin='10px 0 20px';
  googleSection.style.borderBottom='1px solid #e5d7bd';
  googleSection.style.paddingBottom='16px';
 }
 // Show an honest setup status until the Render GOOGLE_CLIENT_ID is active.
 if(googleSection && location.protocol!=='file:' && location.protocol!=='content:'){
  fetch('/api/public-config').then(r=>r.ok?r.json():null).then(config=>{
   if(config?.googleClientId)return; // Existing Google Identity script renders the real button.
   googleSection.hidden=false;
   if(status)status.textContent='Login is temporarily unavailable. Please contact support on WhatsApp.';
  }).catch(()=>{});
 }
})();
