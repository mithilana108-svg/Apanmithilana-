
(function(){
  'use strict';

  function ensurePage(){
    let page=document.getElementById('categoryPage');
    if(page)return page;
    page=document.createElement('div');
    page.id='categoryPage';
    page.setAttribute('aria-hidden','true');
    page.innerHTML='<div class="category-page-head"><button class="category-back" type="button" aria-label="Back">←</button><h1 class="category-title"></h1></div><div class="category-page-body"><div class="category-page-grid"></div></div>';
    document.body.appendChild(page);
    page.querySelector('.category-back').addEventListener('click',function(e){
      e.preventDefault();
      window.mithilanaNavBack();
    });
    return page;
  }

  function buildCategory(filter, resetScroll){
    const page=ensurePage();
    const grid=page.querySelector('.category-page-grid');
    const allProducts=(typeof products!=='undefined'?products:[]);
    const list=filter==='Flavoured Makhana'
      ? allProducts.filter(p=>['classic','plain','peri','tandoori','flav-combo'].includes(p.id))
      : allProducts.filter(p=>filter==='All'?p.cat!=='Combo':p.cat===filter);

    page.dataset.filter=filter;
    page.querySelector('.category-title').textContent=filter==='All'?'All Products':filter;
    grid.innerHTML=list.length?list.map(productCard).join(''):'<div class="empty">No products found.</div>';

    list.forEach(p=>{
      const s=document.getElementById('v-'+p.id);
      if(s)s.addEventListener('change',()=>{
        const price=document.getElementById('price-'+p.id);
        if(price)price.textContent=money(p.variants[s.value].price);
      });
    });

    page.classList.add('open');
    page.setAttribute('aria-hidden','false');
    if(resetScroll) page.scrollTop=0;
  }

  function closeCategory(){
    const page=document.getElementById('categoryPage');
    if(!page)return;
    page.classList.remove('open');
    page.setAttribute('aria-hidden','true');
  }

  function currentCategory(){
    const page=document.getElementById('categoryPage');
    return page && page.classList.contains('open') ? (page.dataset.filter||'All') : null;
  }

  function openPage(filter, fromHistory){
    const f=filter||'All';
    buildCategory(f,true);
    if(!fromHistory){
      const current=history.state;
      if(!(current && current.mithNav==='category' && current.filter===f)){
        history.pushState({mithNav:'category',filter:f},'',location.href);
      }
    }
  }

  window.mithilanaBuildCategory=buildCategory;
  window.mithilanaCloseCategory=closeCategory;
  window.mithilanaCurrentCategory=currentCategory;
  window.showCategory=function(filter){openPage(filter,false);};
  window.showCompleteMithilanaRange=function(){openPage('All',false);};

  // Keep category clicks isolated from the home page. The category page itself owns scrolling.
  document.addEventListener('click',function(e){
    const card=e.target.closest && e.target.closest('.cat-card');
    if(!card)return;
    e.preventDefault();
    e.stopImmediatePropagation();
    openPage(card.dataset.filter||'All',false);
  },true);

  document.addEventListener('keydown',function(e){
    if(e.key!=='Escape')return;
    const page=document.getElementById('categoryPage');
    if(page && page.classList.contains('open')){
      e.preventDefault();
      window.mithilanaNavBack();
    }
  });
})();
