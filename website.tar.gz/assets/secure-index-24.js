
(async function(){
 if(location.protocol==='file:'||location.protocol==='content:')return;
 let config;
 try{const r=await fetch('/api/public-config');if(!r.ok)return;config=await r.json()}catch{return}
 if(config.appMode==='test'){const banner=document.createElement('div');banner.setAttribute('role','status');banner.textContent='TEST MODE — यह परीक्षण साइट है; वास्तविक ऑर्डर न दें।';banner.style.cssText='position:sticky;top:0;z-index:99999;background:#783228;color:white;text-align:center;padding:9px;font:700 15px system-ui';document.body.prepend(banner)}
 if(config.razorpayEnabled){
   const option=document.querySelector('#checkoutForm [name="payment"] option[value="upi"]');
   if(option){option.disabled=false;option.textContent='Online payment — Razorpay'}
   const script=document.createElement('script');script.src='https://checkout.razorpay.com/v1/checkout.js';script.async=true;document.head.append(script);
 }
 if(!config.googleClientId)return;
 const section=document.getElementById('mithGoogleLogin');section.hidden=false;
 const status=document.getElementById('mithGoogleStatus');
 const script=document.createElement('script');script.src='https://accounts.google.com/gsi/client';script.async=true;
 script.onload=()=>{
   google.accounts.id.initialize({client_id:config.googleClientId,callback:async response=>{
     try{
       status.textContent='Verifying Google account…';
       const r=await fetch('/api/auth/google',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({credential:response.credential})});
       const result=await r.json();if(!r.ok)throw Error(result.error||'Google login failed');
       localStorage.setItem('mithilana_token',result.token);
       localStorage.setItem('mithilana_user',JSON.stringify({phone:result.user.phone||'',email:result.user.email,name:result.user.name,method:'google'}));
       const button=document.getElementById('loginBtn');if(button){button.textContent='MY ACCOUNT';button.classList.add('logged')}
       const text=document.getElementById('loginStatus');if(text)text.textContent='Logged in as '+result.user.email;
       const logout=document.getElementById('logoutBtn');if(logout)logout.hidden=false;
       status.textContent='Google login successful';
       window.closeLogin?.();window.dispatchEvent(new Event('mithilana:login'));
     }catch(error){status.textContent=error.message||'Google login failed'}
   }});
   google.accounts.id.renderButton(document.getElementById('mithGoogleButton'),{theme:'outline',size:'large',text:'continue_with',shape:'pill'});
 };
 script.onerror=()=>{status.textContent='Google login could not load.'};
 document.head.append(script);
})();
