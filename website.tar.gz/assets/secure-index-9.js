
(function(){
  var img=document.querySelector('.collection-image');
  if(img){
    img.addEventListener('error',function(){this.classList.add('is-broken');});
    // Force browser to decode the embedded collection image before displaying it.
    if(img.complete && img.naturalWidth===0){img.classList.add('is-broken');}
  }
  var pop=document.getElementById('waSupportPop'), btn=document.getElementById('waFloat'), close=document.getElementById('waSupportClose'), open=document.getElementById('waSupportOpen');
  function waNumber(){
    var n=(window.MITHILANA_CONFIG&&window.MITHILANA_CONFIG.WHATSAPP_NUMBER)||'91XXXXXXXXXX';
    return String(n).replace(/\D/g,'');
  }
  function setLink(){
    var n=waNumber();
    open.href='https://wa.me/'+n+'?text='+encodeURIComponent('Hello Mithilana, I need help with my order/product.');
  }
  if(btn&&pop){btn.addEventListener('click',function(){setLink();pop.classList.toggle('open');});}
  if(close){close.addEventListener('click',function(){pop.classList.remove('open');});}
  document.addEventListener('click',function(e){if(pop&&pop.classList.contains('open')&&!pop.contains(e.target)&&e.target!==btn){pop.classList.remove('open');}});
})();
