
(function(){
 let chosen={};
 function list(){return (window.products||[]).filter(p=>p.cat!=='Combo'&&p.variants&&p.variants.length)}
 function count(){return Object.values(chosen).reduce((a,n)=>a+n,0)}
 function total(){return list().reduce((sum,p)=>{let q=chosen[p.id]||0;return sum+q*Number(p.variants[0].price||0)},0)}
 function draw(){
  const g=document.getElementById('mithBoxGrid'); if(!g)return;
  g.innerHTML=list().map(p=>`<div class="mith-box-item"><img src="${htmlEscape(safeImageUrl(typeof assetUrl==='function'?assetUrl(p):p.img||''))}" loading="lazy" alt=""><div><b>${p.name}</b><small>${p.variants[0].label} · ${typeof money==='function'?money(p.variants[0].price):'₹'+p.variants[0].price}</small></div><div class="mith-box-step"><button data-id="${p.id}" data-d="-1">−</button><strong>${chosen[p.id]||0}</strong><button data-id="${p.id}" data-d="1">+</button></div></div>`).join('');
  document.getElementById('mithBoxCount').textContent=`${count()} items selected`;
  document.getElementById('mithBoxTotal').textContent=typeof money==='function'?money(total()):'₹'+total();
  document.getElementById('mithBoxAdd').disabled=count()===0;
 }
 document.addEventListener('click',e=>{
  const step=e.target.closest('.mith-box-step button'); if(step){const id=step.dataset.id,d=Number(step.dataset.d),now=chosen[id]||0;chosen[id]=Math.max(0,now+d);draw();return}
 });
 document.getElementById('mithBoxAdd')?.addEventListener('click',()=>{
  list().forEach(p=>{const q=chosen[p.id]||0;if(q&&typeof window.addProduct==='function')window.addProduct(p.id,q,0)});
  if(typeof toast==='function')toast('Your custom Mithilana box was added ✓');chosen={};draw();if(typeof openCart==='function')openCart();
 });
 // Guest checkout: buying never requires login. Login remains optional for account convenience.
 const checkout=document.getElementById('checkoutBtn');if(checkout)checkout.onclick=function(){if(!window.cart?.length){if(typeof toast==='function')toast('Add a product to the cart first');return;}if(typeof openCheckout==='function')openCheckout();};
 // Put builder immediately before the existing product range when possible.
 const box=document.getElementById('mithBuildBox'), productsSec=document.getElementById('products');if(box&&productsSec?.parentNode)productsSec.parentNode.insertBefore(box,productsSec);
 const trust=document.querySelector('.mith-trust-strip');if(trust&&box?.parentNode)box.insertAdjacentElement('afterend',trust);
 setTimeout(draw,0);
})();
