
(function(){
  let savedScroll=0;
  function lockProductPage(){
    savedScroll=window.scrollY||document.documentElement.scrollTop||0;
    document.documentElement.classList.add('mith-product-open');
    document.body.classList.add('mith-product-open');
    document.body.dataset.mithSavedScroll=String(savedScroll);
  }
  function unlockProductPage(){
    document.documentElement.classList.remove('mith-product-open');
    document.body.classList.remove('mith-product-open');
    const y=Number(document.body.dataset.mithSavedScroll||savedScroll||0);
    document.body.style.top='';
    window.scrollTo(0,y);
  }
  const baseOpen=window.openProductDetail;
  if(baseOpen){
    window.openProductDetail=function(id){
      lockProductPage();
      baseOpen(id);
      const m=document.getElementById('productDetailModal');
      if(m){m.classList.add('open');m.scrollTop=0;}
      const c=document.querySelector('#productDetailModal .product-detail-card');
      if(c)c.scrollTop=0;
    };
  }
  const baseClose=window.closeProductDetail;
  window.closeProductDetail=function(){
    if(baseClose)baseClose();
    const m=document.getElementById('productDetailModal');
    if(m)m.classList.remove('open');
    unlockProductPage();
  };

  /* Capture every product-card click before older onclick/anchor handlers can scroll. */
  document.addEventListener('click',function(e){
    const card=e.target.closest('.product');
    if(!card)return;
    if(e.target.closest('button,.add,.variant,input,select,label'))return;
    const attr=(card.dataset.mithId ? "openProductDetail('"+card.dataset.mithId+"')" : '');
    const match=attr.match(/openProductDetail\(['"]([^'"]+)['"]\)/);
    if(!match)return;
    e.preventDefault();
    e.stopPropagation();
    if(e.stopImmediatePropagation)e.stopImmediatePropagation();
    window.openProductDetail(match[1]);
  },true);

  /* X/back/escape closes the foreground page instead of moving the home page. */
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape' && document.getElementById('productDetailModal')?.classList.contains('open')){
      e.preventDefault();window.closeProductDetail();
    }
  });
  const close=document.getElementById('detailClose');
  if(close)close.onclick=function(e){e.preventDefault();e.stopPropagation();window.closeProductDetail();};
})();
