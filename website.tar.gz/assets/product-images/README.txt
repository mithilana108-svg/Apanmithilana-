Is folder mein size-wise images rakhein. Naam IMAGE-NAMES.txt mein dekhein.
