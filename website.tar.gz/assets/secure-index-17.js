
(function(){
  function hasOpen(id){
    var el=document.getElementById(id);
    return !!(el && el.classList.contains('open'));
  }
  function backOne(){
    try{
      if(typeof goBack==='function'){ goBack(); return; }
    }catch(e){}
    try{
      if(history.length>1){ history.back(); return; }
    }catch(e){}
  }
  function closeId(id){
    var el=document.getElementById(id);
    if(!el) return;
    el.classList.remove('open');
    el.setAttribute('aria-hidden','true');
  }

  document.addEventListener('click', function(e){
    var t=e.target && e.target.closest ? e.target.closest('button,a') : null;
    if(!t) return;

    /* Product-detail X: return exactly one navigation step. */
    if(t.id==='detailClose'){
      e.preventDefault(); e.stopImmediatePropagation();
      backOne(); return;
    }

    /* Category-page Back/X controls: return exactly one navigation step. */
    if(t.id==='categoryClose' ||
       (t.closest('#categoryPage') && t.classList.contains('category-back'))){
      e.preventDefault(); e.stopImmediatePropagation();
      backOne(); return;
    }

    /* Cart X always closes the cart. */
    if(t.id==='closeCart'){
      e.preventDefault(); e.stopImmediatePropagation();
      if(typeof closeCart==='function') closeCart();
      else closeId('cart');
      return;
    }

    /* Checkout X always closes checkout. */
    if(t.id==='closeModal'){
      e.preventDefault(); e.stopImmediatePropagation();
      closeId('checkoutModal');
      return;
    }

    /* Login X always closes login. */
    if(t.id==='loginClose'){
      e.preventDefault(); e.stopImmediatePropagation();
      if(typeof closeLogin==='function') closeLogin();
      else closeId('loginModal');
      return;
    }

    /* WhatsApp/support X buttons. */
    if(t.id==='supportClose' || t.id==='supportCancel'){
      e.preventDefault(); e.stopImmediatePropagation();
      try{
        if(typeof closeSupport==='function') closeSupport(false);
        else closeId('whatsappSupportModal');
      }catch(err){ closeId('whatsappSupportModal'); }
      return;
    }

    if(t.id==='waSupportClose'){
      e.preventDefault(); e.stopImmediatePropagation();
      closeId('waSupportPop');
      return;
    }
  }, true);

  /* Make sure the floating support popup can also be closed by its X/CLOSE. */
  var wac=document.getElementById('waSupportClose');
  if(wac) wac.setAttribute('aria-label','Close WhatsApp support');

  /* The Explore button was intentionally removed; prevent stale code from
     recreating or depending on it. */
  var ex=document.getElementById('exploreProductsBtn');
  if(ex) ex.remove();
})();
