
(function(){
  // 1) Dry Fruits = exactly 3 products: Kishmish, Badam, Kaju.
  // Kaju price is set to ₹250/100 g for now; it can be changed easily later.
  if (typeof products !== 'undefined') {
    const raisins = products.find(p=>p.id==='raisins');
    const almonds = products.find(p=>p.id==='almonds');
    if (raisins) { raisins.cat='Dry Fruits'; raisins.name='Golden Raisins (Kishmish)'; }
    if (almonds) { almonds.cat='Dry Fruits'; almonds.name='Golden Almonds (Badam)'; }
    let kaju = products.find(p=>p.id==='cashews');
    if (!kaju) {
      kaju = {
        id:'cashews', cat:'Dry Fruits', name:'Golden Cashews (Kaju)',
        desc:'Premium golden cashews — selected for a rich, crisp dry-fruit bite.',
        variants:[{label:'100 g',price:250}],
        img: almonds ? almonds.img : (raisins ? raisins.img : '')
      };
      const idx=products.findIndex(p=>p.id==='almonds');
      products.splice(idx+1,0,kaju);
    }
  }

  // Make the Dry Fruits range card explicitly show all 3 dry fruits.
  const dryCard=[...document.querySelectorAll('.cat-card')].find(c=>c.dataset.filter==='Dry Fruits');
  if(dryCard){
    dryCard.dataset.filter='Dry Fruits';
    dryCard.onclick=()=>showCategory('Dry Fruits');
    const title=dryCard.querySelector('span'); if(title) title.textContent='Dry Fruits';
  }

  // 2) WhatsApp Support opens a foreground popup first. No OTP here.
  if(!document.getElementById('whatsappSupportModal')){
    const wrap=document.createElement('div');
    wrap.innerHTML=`<div class="support-modal" id="whatsappSupportModal" aria-hidden="true">
      <div class="support-box" role="dialog" aria-modal="true" aria-labelledby="supportTitle">
        <button class="support-close" id="supportClose" type="button" aria-label="Close">×</button>
        <div class="support-icon">💬</div>
        <span class="kicker">CUSTOMER SUPPORT</span>
        <h2 id="supportTitle">WhatsApp Support</h2>
        <p>Need help with a product, order, delivery or anything else? Chat with Mithilana directly on WhatsApp.</p>
        <button class="primary full" id="supportOpenWhatsApp" type="button">OPEN WHATSAPP</button>
        <button class="support-cancel" id="supportCancel" type="button">CLOSE</button>
      </div>
    </div>`;
    document.body.appendChild(wrap.firstElementChild);
  }
  const sm=document.getElementById('whatsappSupportModal');
  const openSupport=()=>{sm.classList.add('open');sm.setAttribute('aria-hidden','false');history.pushState({mithilanaOverlay:'support'},'',location.href);};
  const closeSupport=(fromPop)=>{sm.classList.remove('open');sm.setAttribute('aria-hidden','true');if(!fromPop && history.state && history.state.mithilanaOverlay==='support')history.back();};
  const openWa=()=>{
    const n=(typeof CONFIG!=='undefined'&&CONFIG.WHATSAPP_NUMBER?CONFIG.WHATSAPP_NUMBER:'').replace(/\D/g,'');
    if(n.length>=10) window.open('https://wa.me/'+n+'?text='+encodeURIComponent('Hello Mithilana, I need customer support.'),'_blank');
    else toast('WhatsApp support number is not configured yet.');
  };
  document.getElementById('supportClose').onclick=()=>closeSupport(false);
  document.getElementById('supportCancel').onclick=()=>closeSupport(false);
  document.getElementById('supportOpenWhatsApp').onclick=openWa;
  sm.addEventListener('click',e=>{if(e.target===sm)closeSupport(false)});
  const bindSupport=e=>{e.preventDefault();e.stopPropagation();openSupport();};
  document.getElementById('supportLink')?.addEventListener('click',bindSupport,true);
  document.getElementById('loginSupportBtn')?.addEventListener('click',bindSupport,true);
  document.getElementById('waCartBtn')?.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openSupport();},true);
  window.addEventListener('popstate',e=>{if(!(e.state&&e.state.mithilanaOverlay==='support')) closeSupport(true);});

  // 3) Combo section comes before the complete product list.
  const combo=document.getElementById('combo'), productsSec=document.getElementById('products');
  if(combo && productsSec && combo.nextElementSibling!==productsSec) productsSec.parentNode.insertBefore(combo,productsSec);

  // 4) Complete Product Range contains all regular products; combo products live only in Combo section.
  const originalRender=window.renderProducts;
  if(typeof originalRender==='function'){
    window.renderProducts=function(filter='All'){
      if(filter==='All'){
        const grid=document.getElementById('productGrid');
        if(!grid)return;
        const list=products.filter(p=>p.cat!=='Combo');
        grid.innerHTML=list.map(productCard).join('')||'<div class="empty">No products found.</div>';
        list.forEach(p=>{const s=document.getElementById('v-'+p.id);if(s)s.addEventListener('change',()=>document.getElementById('price-'+p.id).textContent=money(p.variants[s.value].price));});
      } else originalRender(filter);
    };
  }
  // Refresh current product list so Kaju appears immediately when HTML is opened.
  if(typeof renderProducts==='function') renderProducts('All');
})();
