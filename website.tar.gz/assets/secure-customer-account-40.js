
(()=>{
 const token=()=>localStorage.getItem('mithilana_token');
 const api=async(url,options={})=>{const r=await fetch(url,{...options,headers:{'Content-Type':'application/json',...(token()?{Authorization:'Bearer '+token()}:{}),...options.headers}});const d=await r.json();if(!r.ok)throw Error(d.error||'Request failed');return d;};
 // Older builds stored a plain PIN. Remove it on upgrade.
 try{const u=JSON.parse(localStorage.getItem('mithilana_user')||'null');if(u?.password){localStorage.removeItem('mithilana_user');localStorage.removeItem('mithilana_token');}}catch(e){}
 const account=document.querySelector('#mithilanaAccount');
 async function showAccount(){if(!token()){openLogin();return}account.classList.add('open');try{const [me,orders]=await Promise.all([api('/api/me'),api('/api/orders')]);for(const [key,value] of Object.entries(me.user))if(account.querySelector(`[name="${key}"]`))account.querySelector(`[name="${key}"]`).value=value||'';const box=document.querySelector('#accountOrders');box.replaceChildren();for(const o of orders.orders){const el=window.mithOrderTimeline(o);box.append(el)}if(!orders.orders.length)box.textContent='No orders yet.';}catch(e){document.querySelector('#accountMessage').textContent=e.message;}}
 window.mithShowAccount=showAccount;
 document.querySelector('#accountClose').onclick=()=>account.classList.remove('open');account.onclick=e=>{if(e.target===account)account.classList.remove('open')};
 document.querySelector('#accountForm').onsubmit=async e=>{e.preventDefault();const f=Object.fromEntries(new FormData(e.target));try{await api('/api/me',{method:'PATCH',body:JSON.stringify(f)});document.querySelector('#accountMessage').textContent='Profile saved.'}catch(err){document.querySelector('#accountMessage').textContent=err.message}};
 document.querySelector('#loginBtn').addEventListener('click',e=>{if(token()){e.stopImmediatePropagation();showAccount()}},true);
 document.querySelector('#mithProfileShortcut')?.addEventListener('click',()=>{document.querySelector('#loginModal').classList.remove('open');showAccount()});
 document.querySelector('#checkoutBtn').addEventListener('click',e=>{if(!token()){e.preventDefault();e.stopImmediatePropagation();openLogin();return}},true);
 // Checkout submission is owned by the verified handler below. Multiple
 // capture handlers previously swallowed its result and hid order errors.
})();
