
(function(){
  function syncHeaderHeight(){
    var h=document.querySelector('.header');
    if(h) document.documentElement.style.setProperty('--mithilana-header-height', h.getBoundingClientRect().height+'px');
  }
  syncHeaderHeight();
  window.addEventListener('load',syncHeaderHeight);
  window.addEventListener('resize',syncHeaderHeight);
  if(window.ResizeObserver){var h=document.querySelector('.header'); if(h)new ResizeObserver(syncHeaderHeight).observe(h);}
})();
