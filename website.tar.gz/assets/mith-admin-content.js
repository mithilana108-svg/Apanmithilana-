(()=>{
const $=id=>document.getElementById(id);let festival=null,company=null,selectedDay=0;
async function api(key,method='GET',body){const token=sessionStorage.getItem('admin_token');if(!token)throw Error('Sign in to Admin first');const r=await fetch(method==='GET'?'/api/site-content/'+key:'/api/admin/site-content/'+key,{method,headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:body?JSON.stringify(body):undefined});const d=await r.json();if(!r.ok)throw Error(d.error||'Request failed');return d}
const field=(obj,id)=>{const e=$(id);if(e)obj[id.replace(/^fest|^comp/,'').replace(/^./,c=>c.toLowerCase())]=e.type==='checkbox'?e.checked:e.value};
async function load(){try{[festival,company]=await Promise.all([api('festival'),api('company')]);for(const k of ['title','subtitle','startDate','endDate','theme','background','font','template','manualDay'])if($('fest'+k))$('fest'+k).value=festival[k]??'';$('festEnabled').checked=festival.enabled;for(const k of ['heading','description','theme','background','font','template','image'])if($('comp'+k))$('comp'+k).value=company[k]??'';showDay();msg('Loaded current content')}catch(e){msg(e.message)}}
function msg(t){$('contentStatus').textContent=t}
function showDay(){if(!festival)return;const i=Number($('festDaySelect').value);selectedDay=i;const d=festival.days[i];$('festDayName').value=d.name;$('festDayStory').value=d.story;$('festDayMantra').value=d.mantra;$('festDayImage').value=d.image}
function saveDay(){if(!festival)return;const i=selectedDay;festival.days[i]={name:$('festDayName').value,story:$('festDayStory').value,mantra:$('festDayMantra').value,image:$('festDayImage').value}}
$('festDaySelect').addEventListener('change',()=>{saveDay();showDay()});
$('saveFestival').addEventListener('click',async()=>{try{saveDay();for(const k of ['title','subtitle','startDate','endDate','theme','background','font','template'])festival[k]=$('fest'+k).value;festival.manualDay=Number($('festmanualDay').value);festival.enabled=$('festEnabled').checked;await api('festival','PUT',festival);msg('Festival published successfully')}catch(e){msg(e.message)}});
$('saveCompany').addEventListener('click',async()=>{try{for(const k of ['heading','description','theme','background','font','template','image'])company[k]=$('comp'+k).value;await api('company','PUT',company);msg('Company content published successfully')}catch(e){msg(e.message)}});
$('reloadContent').addEventListener('click',load);$('contentNav').addEventListener('click',()=>setTimeout(load,50));
})();
