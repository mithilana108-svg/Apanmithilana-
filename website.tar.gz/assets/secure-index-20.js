
(()=>{
 const langKey='mithilana_language', choice=document.querySelector('#languageChoice');
 const labels={en:{login:'LOGIN',account:'ACCOUNT',cart:'Your Cart',checkout:'Checkout',name:'Name',mobile:'Mobile',address:'Full Address',payment:'Payment',place:'PLACE ORDER',search:'Search',profile:'My profile',orders:'My orders',close:'Close ×',receipt:'Order received',review:'Thank you. We have received your order. It will be confirmed automatically in about five seconds. Track its status in your profile.',note:'Cash on Delivery: no payment has been collected. Check your profile for updates.',view:'View my orders',support:'WHATSAPP CUSTOMER SUPPORT'},hi:{login:'लॉगिन',account:'मेरा खाता',cart:'आपकी टोकरी',checkout:'ऑर्डर करें',name:'नाम',mobile:'मोबाइल नंबर',address:'पूरा पता',payment:'भुगतान',place:'ऑर्डर भेजें',search:'खोजें',profile:'मेरा प्रोफ़ाइल',orders:'मेरे ऑर्डर',close:'बंद करें ×',receipt:'आपका ऑर्डर मिल गया है',review:'धन्यवाद। आपका ऑर्डर लगभग पाँच सेकंड में अपने आप कन्फर्म होगा। स्थिति अपने प्रोफ़ाइल में देखें।',note:'कैश ऑन डिलीवरी: अभी कोई भुगतान नहीं लिया गया है। स्थिति अपने प्रोफ़ाइल में देखें।',view:'मेरे ऑर्डर देखें',support:'व्हाट्सऐप ग्राहक सहायता'}};
 const names={flower:'फूल मखाना',classic:'क्लासिक बटर मखाना',plain:'प्लेन सॉल्टेड मखाना',peri:'पेरी पेरी मखाना',tandoori:'तंदूरी मखाना',raisins:'किशमिश',almonds:'बादाम',cashews:'काजू',kumrauri:'कुमरौरी',adhori:'अधौरी','flav-combo':'फ्लेवर्ड मखाना कॉम्बो','adho-kum':'अधौरी + कुमरौरी कॉम्बो'};
 const baseNames=new Map((window.products||[]).map(p=>[p.id,p.name]));
 const current=()=>localStorage.getItem(langKey)==='hi'?'hi':'en';
 window.mithilanaStatus=status=>({hi:{placed:'ऑर्डर प्राप्त; जाँच जारी',confirmed:'ऑर्डर की पुष्टि',packed:'पैक हो गया',shipped:'भेज दिया गया',out_for_delivery:'डिलीवरी के लिए निकला',delivered:'डिलीवर हो गया',cancelled:'रद्द'},en:{placed:'Received · awaiting confirmation',confirmed:'Confirmed',packed:'Packed',shipped:'Shipped',out_for_delivery:'Out for delivery',delivered:'Delivered',cancelled:'Cancelled'}}[current()][status]||status);
 function apply(lang){const t=labels[lang];document.documentElement.lang=lang;
  const set=(selector,value)=>{const el=document.querySelector(selector);if(el)el.textContent=value};
  const accountButton=document.querySelector('#loginBtn');if(accountButton)accountButton.textContent=localStorage.getItem('mithilana_token')?(lang==='hi'?'मेरा अकाउंट':'MY ACCOUNT'):t.login;
  set('#cart .cart-head h3',t.cart);set('#checkoutBtn',t.checkout);set('#checkoutForm button[type="submit"]',t.place);
  const headings={en:['Shop by Product Range','About Our Company','Complete Your Order','Login with Google'],hi:['उत्पाद देखें','हमारी कंपनी','ऑर्डर की जानकारी','Google से लॉगिन करें']};
  ['#categories h2','#about-my-company h2','#checkoutModal h2','#loginModal h2'].forEach((selector,i)=>set(selector,headings[lang][i]));
  const nav={en:['HOME','CATEGORIES','BUILD YOUR OWN BOX','ABOUT OUR COMPANY'],hi:['होम','श्रेणियाँ','अपना बॉक्स बनाएं','हमारी कंपनी']};document.querySelectorAll('nav.nav a').forEach((el,i)=>{if(nav[lang][i])el.textContent=nav[lang][i]});
  const foot={en:['HOME','ABOUT OUR COMPANY','CATEGORIES'],hi:['होम','हमारी कंपनी','श्रेणियाँ']};document.querySelectorAll('footer .footer-links a').forEach((el,i)=>{if(foot[lang][i])el.textContent=foot[lang][i]});
  set('#logoutBtn',lang==='hi'?'लॉग आउट':'LOG OUT');
  set('#categories .range-note',lang==='hi'?'मिथिलाना के सभी उत्पाद, पैक आकार और स्वाद देखें।':'Explore the complete Mithilana range — every product, size and flavour opens separately.');
  const companyTexts=lang==='hi'?['सामग्री','हर उत्पाद की सत्यापित सामग्री अंतिम पैक की जानकारी मिलने पर जोड़ी जाएगी।','पोषण मूल्य','सत्यापित पोषण मूल्य प्रत्येक उत्पाद और स्वाद के लिए अंतिम लेबल से जोड़े जाएँगे।']:['Ingredients','Product-wise verified ingredients will be added when the final pack information is available.','Nutrition Value','Verified nutrition values for each product and flavour will be added from the final nutrition labels.'];
  document.querySelectorAll('#mithCompanyInformation .mith-info-card').forEach((card,i)=>{card.querySelector('h3').textContent=companyTexts[i*2];card.querySelector('p').textContent=companyTexts[i*2+1]});
  set('#mithilanaAccount h2',t.profile);set('#mithProfileShortcut',lang==='hi'?'मेरा अकाउंट':'MY ACCOUNT');set('#mithilanaAccount h3',t.orders);set('#accountClose',t.close);set('#supportLink',t.support);set('#receiptDone',t.view);
  const fields=[['name',t.name],['phone',t.mobile],['address',t.address],['payment',t.payment]];for(const [key,value] of fields){const el=document.querySelector(`#checkoutForm [name="${key}"]`);if(el?.closest('label'))el.closest('label').firstChild.textContent=value}
  for(const p of window.products||[]){if(!baseNames.has(p.id))baseNames.set(p.id,p.name);p.name=lang==='hi'?(names[p.id]||baseNames.get(p.id)||p.name):(baseNames.get(p.id)||p.name);}
  try{if(typeof renderProducts==='function')renderProducts('All')}catch(e){}
  document.querySelectorAll('#cartItems .cart-item').forEach(()=>{});
 }
 async function choose(lang){localStorage.setItem(langKey,lang);apply(lang);choice.classList.remove('open');if(localStorage.getItem('mithilana_token')){try{await fetch('/api/me',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+localStorage.getItem('mithilana_token')},body:JSON.stringify({preferred_language:lang})})}catch(e){}}}
 choice.querySelectorAll('[data-lang]').forEach(b=>b.onclick=()=>choose(b.dataset.lang));
 window.addEventListener('mithilana:login',()=>{if(!localStorage.getItem(langKey))choice.classList.add('open');});
 window.addEventListener('mithilana:logout',()=>{apply(current());});
 const languageButton=document.querySelector('#changeLanguage');if(languageButton)languageButton.onclick=()=>choice.classList.add('open');
 window.mithilanaReceipt=order=>{const t=labels[current()];document.querySelector('#receiptTitle').textContent=t.receipt;document.querySelector('#receiptBody').textContent=t.review;document.querySelector('#receiptReference').textContent=`#${order.id.slice(0,8)} · ₹${order.total_amount}`;document.querySelector('#receiptNote').textContent=t.note;document.querySelector('#receiptDone').textContent=t.view;document.querySelector('#orderReceipt').classList.add('open')};
 document.querySelector('#receiptDone').onclick=()=>{document.querySelector('#orderReceipt').classList.remove('open');document.querySelector('#loginBtn').click()};
 apply(current());
 if(!localStorage.getItem(langKey))choice.classList.add('open');
})();
