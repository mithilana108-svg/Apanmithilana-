
(function(){
  'use strict';

  function detailOpen(){
    var m=document.getElementById('productDetailModal');
    return !!(m && m.classList.contains('open'));
  }

  function productFromDetail(){
    var name=((document.getElementById('detailName')||{}).textContent||'').trim();
    return (window.products||[]).find(function(p){return p.name===name;})||null;
  }

  function selectedDetailVariant(){
    var vi=0;
    document.querySelectorAll('#detailVariants button').forEach(function(b,i){
      if(b.classList.contains('active')) vi=i;
    });
    return vi;
  }

  function showLocalNotice(message, host){
    if(!host) return;
    var n=host.querySelector('.mith-local-cart-notice');
    if(!n){
      n=document.createElement('div');
      n.className='mith-local-cart-notice';
      n.setAttribute('role','status');
      n.setAttribute('aria-live','polite');
      var row=host.querySelector('#detailAdd') && host.querySelector('#detailAdd').parentElement;
      if(row && row.parentElement===host) row.insertAdjacentElement('afterend',n);
      else host.appendChild(n);
    }
    n.innerHTML='<span class="check">✓</span>'+htmlEscape(message);
    n.classList.add('show');
    clearTimeout(n.__timer);
    n.__timer=setTimeout(function(){n.classList.remove('show');},2600);
  }

  function addToCart(id, qty, vi){
    var p=(window.products||[]).find(function(x){return x.id===id;});
    if(!p) return false;
    var index=(vi==null?0:Number(vi));
    if(!p.variants[index]) index=0;
    var amount=Math.max(1,Number(qty)||1);
    window.cart=Array.isArray(window.cart)?window.cart:[];
    var key=id+'-'+index;
    var old=window.cart.find(function(x){return x.key===key;});
    if(old) old.qty=Number(old.qty||0)+amount;
    else window.cart.push({key:key,id:id,vi:index,qty:amount,name:p.name,cat:p.cat,label:p.variants[index].label,price:Number(p.variants[index].price),img:p.img});
    localStorage.setItem('mithilana_cart',JSON.stringify(window.cart.map(({img,...rest})=>rest)));
    if(typeof renderCart==='function') renderCart();
    if(typeof updateCount==='function') updateCount();
    window.mithAnimateCart?.(p,document.activeElement);
    return true;
  }

  // This is the only Add handler for the foreground product page.
  document.addEventListener('click',function(e){
    var b=e.target && e.target.closest ? e.target.closest('#detailAdd') : null;
    if(!b || !detailOpen()) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    var p=productFromDetail();
    if(!p) return;
    var vi=selectedDetailVariant();
    var qty=Math.max(1,Number((document.getElementById('detailQty')||{}).textContent)||1);
    if(addToCart(p.id,qty,vi)){
      var card=document.querySelector('#productDetailModal .product-detail-card');
      showLocalNotice(p.name+' added to cart',card);
      b.classList.add('mith-added-btn');
      var oldText=b.textContent;
      b.textContent='Added ✓';
      clearTimeout(b.__timer);
      b.__timer=setTimeout(function(){b.classList.remove('mith-added-btn');b.textContent=oldText||'Add +';},1000);
    }
  },true);

  // Add buttons on a category/product-range page get a notice inside that page/card,
  // never on the underlying main page.
  document.addEventListener('click',function(e){
    var b=e.target && e.target.closest ? e.target.closest('.product button.add') : null;
    if(!b || detailOpen()) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    var card=b.closest('.product');
    var s=card && card.querySelector('select.variant');
    var id=s && s.id ? s.id.replace(/^v-/,'') : null;
    if(!id) return;
    var vi=s?Number(s.value):0;
    if(addToCart(id,1,vi)){
      var p=(window.products||[]).find(function(x){return x.id===id;});
      showLocalNotice((p?p.name:'Product')+' added to cart',card);
      b.classList.add('mith-added-btn');
      var oldText=b.textContent;
      b.textContent='Added ✓';
      clearTimeout(b.__timer);
      b.__timer=setTimeout(function(){b.classList.remove('mith-added-btn');b.textContent=oldText||'Add +';},1000);
    }
  },true);

  // Prevent the old inline detailAdd assignment in openProductDetail from closing the page.
  // We do not modify the existing page navigation/back behavior.
  window.addProduct=function(id,qty,vi){
    var ok=addToCart(id,qty,vi);
    if(ok && !detailOpen()){
      var card=document.querySelector('.category-page.open .product, .product');
      if(card){
        var p=(window.products||[]).find(function(x){return x.id===id;});
        showLocalNotice((p?p.name:'Product')+' added to cart',card);
      }
    }
    return ok;
  };
})();
