
(function(){
  'use strict';

  function detailOpen(){
    var m=document.getElementById('productDetailModal');
    return !!(m && m.classList.contains('open'));
  }

  function productFromDetail(){
    var name=((document.getElementById('detailName')||{}).textContent||'').trim();
    var id=document.getElementById('productDetailModal')?.dataset.productId;return (window.products||[]).find(function(p){return p.id===id;})||null;
  }

  function selectedDetailVariant(){
    var vi=0;
    document.querySelectorAll('#detailVariants button').forEach(function(b,i){
      if(b.classList.contains('active')) vi=i;
    });
    return vi;
  }

  function showLocalNotice(message, host){
    if(!host) return;
    var n=host.querySelector('.mith-local-cart-notice');
    if(!n){
      n=document.createElement('div');
      n.className='mith-local-cart-notice';
      n.setAttribute('role','status');
      n.setAttribute('aria-live','polite');
      var row=host.querySelector('#detailAdd') && host.querySelector('#detailAdd').parentElement;
      if(row && row.parentElement===host) row.insertAdjacentElement('afterend',n);
      else host.appendChild(n);
    }
    n.innerHTML='<span class="check">✓</span>'+htmlEscape(message);
    n.classList.add('show');
    clearTimeout(n.__timer);
    n.__timer=setTimeout(function(){n.classList.remove('show');},2600);
  }

  function addToCart(id,qty,vi){return window.mithCanonicalAdd?window.mithCanonicalAdd(id,qty,vi):false;}

  // This is the only Add handler for the foreground product page.
  document.addEventListener('click',function(e){
    var b=e.target && e.target.closest ? e.target.closest('#detailAdd') : null;
    if(!b || !detailOpen()) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    var p=productFromDetail();
    if(!p) return;
    var vi=selectedDetailVariant();
    var qty=Math.max(1,Number((document.getElementById('detailQty')||{}).textContent)||1);
    if(addToCart(p.id,qty,vi)){
      var card=document.querySelector('#productDetailModal .product-detail-card');
      showLocalNotice(p.name+' added to cart',card);
      b.classList.add('mith-added-btn');
      var oldText=b.textContent;
      b.textContent='Added ✓';
      clearTimeout(b.__timer);
      b.__timer=setTimeout(function(){b.classList.remove('mith-added-btn');b.textContent=oldText||'Add +';},1000);
    }
  },true);

  // Add buttons on a category/product-range page get a notice inside that page/card,
  // never on the underlying main page.
  document.addEventListener('click',function(e){
    var b=e.target && e.target.closest ? e.target.closest('.product button.add') : null;
    if(!b || detailOpen()) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    var card=b.closest('.product');
    var s=card && card.querySelector('select.variant');
    var id=s && s.id ? s.id.replace(/^v-/,'') : null;
    if(!id) return;
    var vi=s?Number(s.value):0;
    if(addToCart(id,1,vi)){
      var p=(window.products||[]).find(function(x){return x.id===id;});
      showLocalNotice((p?p.name:'Product')+' added to cart',card);
      b.classList.add('mith-added-btn');
      var oldText=b.textContent;
      b.textContent='Added ✓';
      clearTimeout(b.__timer);
      b.__timer=setTimeout(function(){b.classList.remove('mith-added-btn');b.textContent=oldText||'Add +';},1000);
    }
  },true);

})();
