
(function(){
  const searchPage=document.getElementById('mithSearchPage');
  const input=document.getElementById('mithSearchInput');
  const grid=document.getElementById('mithSearchGrid');
  const searchBtn=document.getElementById('searchBtn');
  const back=document.getElementById('siteBackBtn');

  // Android browser Back handles navigation; no extra Home back button.

  function sameOriginReferrer(){
    try{return document.referrer && new URL(document.referrer).origin===location.origin}catch(e){return false}
  }
  function currentOverlay(){
    return history.state && history.state.mithilanaOverlay;
  }
  function goBack(){
    const s=currentOverlay();
    if(s){history.back();return}
    if(sameOriginReferrer()){history.back();return}
    // Stay on Mithilana if there is no in-site history.
    window.scrollTo({top:0,behavior:'smooth'});
  }
  const backBtn=document.getElementById('siteBackBtn');
  if(backBtn)backBtn.onclick=goBack;

  function searchProducts(q){
    q=String(q||'').trim().toLowerCase();
    const list=(!q ? products : products.filter(p=>{
      const text=[p.name,p.cat,p.desc,...p.variants.map(v=>v.label)].join(' ').toLowerCase();
      return text.includes(q);
    }));
    grid.innerHTML=list.length
      ? list.map(productCard).join('')
      : '<div class="empty" style="grid-column:1/-1">No product found for “'+q.replace(/</g,'&lt;')+'”.</div>';
    // Use a dedicated grid so results never scroll the home page.
    grid.querySelectorAll('.product').forEach(card=>card.classList.add('search-result-card'));
  }

  function openSearch(){
    if(!searchPage)return;
    if(!(history.state&&history.state.mithilanaOverlay==='search')){
      history.pushState({mithilanaOverlay:'search'},'',location.href);
    }
    searchPage.classList.add('open');
    searchPage.setAttribute('aria-hidden','false');
    searchProducts(input.value);
    setTimeout(()=>input.focus(),30);
  }
  function closeSearch(){
    searchPage.classList.remove('open');
    searchPage.setAttribute('aria-hidden','true');
  }

  if(searchBtn)searchBtn.onclick=function(e){e.preventDefault();openSearch()};
  const close=document.getElementById('mithSearchClose');
  if(close)close.onclick=function(){if(currentOverlay()==='search')history.back();else closeSearch()};
  if(input)input.addEventListener('input',()=>searchProducts(input.value));

  // Search page must use product clicks without returning to the home product section.
  document.addEventListener('click',function(e){
    const card=e.target.closest('#mithSearchGrid .product');
    if(!card || e.target.closest('.add,.variant'))return;
    const m=(card.dataset.mithId ? "openProductDetail('"+card.dataset.mithId+"')" : '');
    const match=m.match(/openProductDetail\('([^']+)'\)/);
    if(match){
      e.preventDefault();e.stopPropagation();
      closeSearch();
      if(currentOverlay()==='search')history.back();
      setTimeout(()=>window.openProductDetail(match[1]),20);
    }
  },true);

  // Replace the old prompt-based search completely.
  if(searchBtn)searchBtn.removeAttribute('onclick');

  // Product detail is a full-page view. Browser back closes it.
  const oldDetail=window.openProductDetail;
  if(oldDetail){
    window.openProductDetail=function(id){
      // The existing function already fills all variants, quantity and add-to-cart.
      oldDetail(id);
      const modal=document.getElementById('productDetailModal');
      if(modal)modal.scrollTop=0;
      const card=document.querySelector('#productDetailModal .product-detail-card');
      if(card)card.scrollTop=0;
    };
  }

  window.addEventListener('popstate',function(e){
    const state=e.state&&e.state.mithilanaOverlay;
    if(state==='search'){
      searchPage.classList.add('open');
      searchPage.setAttribute('aria-hidden','false');
      searchProducts(input.value);
      return;
    }
    // No overlay state: close search/detail if they are open.
    closeSearch();
    const detail=document.getElementById('productDetailModal');
    if(detail)detail.classList.remove('open');
  });

  // On initial load, make sure the search results are available without showing the page.
  if(typeof products!=='undefined')searchProducts('');
})();
