
(function(){
  'use strict';

  var NAV='mithNav';
  var busy=false;

  function state(){
    return history.state || {};
  }

  function pageOpen(){
    var p=document.getElementById('categoryPage');
    return !!(p && p.classList.contains('open'));
  }

  function productOpen(){
    var m=document.getElementById('productDetailModal');
    return !!(m && m.classList.contains('open'));
  }

  function categoryFilter(){
    var p=document.getElementById('categoryPage');
    return p && p.classList.contains('open') ? (p.dataset.filter || 'All') : null;
  }

  function clearLegacyLocks(){
    document.documentElement.classList.remove('mith-product-open');
    document.body.classList.remove('mith-product-open');
    document.documentElement.style.overflow='';
    document.body.style.overflow='';
    document.body.style.position='';
    document.body.style.top='';
    document.body.style.width='';
    document.body.style.left='';
    document.body.style.right='';
    document.body.style.height='';
  }

  function renderCategoryWithoutHistory(filter){
    if(typeof window.mithilanaBuildCategory==='function'){
      window.mithilanaBuildCategory(filter || 'All', false);
      return;
    }
    if(typeof window.showCategory==='function'){
      window.showCategory(filter || 'All');
    }
  }

  function closeCategoryVisual(){
    if(typeof window.mithilanaCloseCategory==='function'){
      window.mithilanaCloseCategory();
    }else{
      var p=document.getElementById('categoryPage');
      if(p){
        p.classList.remove('open');
        p.setAttribute('aria-hidden','true');
      }
    }
  }

  function renderProductVisual(id){
    var p=(window.products||[]).find(function(x){return x.id===id;});
    var m=document.getElementById('productDetailModal');
    if(!p || !m)return false;

    var image=document.getElementById('detailImage');
    var cat=document.getElementById('detailCat');
    var name=document.getElementById('detailName');
    var desc=document.getElementById('detailDesc');
    var variants=document.getElementById('detailVariants');
    var price=document.getElementById('detailPrice');
    var qty=document.getElementById('detailQty');
    var minus=document.getElementById('detailQtyMinus');
    var plus=document.getElementById('detailQtyPlus');
    var add=document.getElementById('detailAdd');

    if(image){image.src=p.img;image.alt=p.name;}
    if(cat)cat.textContent=p.cat||'';
    if(name)name.textContent=p.name||'';
    if(desc)desc.textContent=p.desc||'';

    var vi=0;
    var q=1;

    if(variants){
      variants.innerHTML=(p.variants||[]).map(function(v,i){
        return '<button type="button" class="'+(i===0?'active':'')+'" data-i="'+i+'">'+v.label+' — '+money(v.price)+'</button>';
      }).join('');

      variants.querySelectorAll('button').forEach(function(b){
        b.addEventListener('click',function(e){
          e.preventDefault();
          e.stopPropagation();
          vi=Number(b.dataset.i)||0;
          variants.querySelectorAll('button').forEach(function(x){x.classList.remove('active');});
          b.classList.add('active');
          if(price)price.textContent=money((p.variants[vi]||p.variants[0]).price*q);
        });
      });
    }

    if(qty)qty.textContent='1';
    if(price && p.variants && p.variants[0])price.textContent=money(p.variants[0].price);

    if(minus){
      minus.onclick=function(e){
        e.preventDefault();e.stopPropagation();
        q=Math.max(1,q-1);
        if(qty)qty.textContent=String(q);
        if(price)price.textContent=money((p.variants[vi]||p.variants[0]).price*q);
      };
    }
    if(plus){
      plus.onclick=function(e){
        e.preventDefault();e.stopPropagation();
        q=Math.min(99,q+1);
        if(qty)qty.textContent=String(q);
        if(price)price.textContent=money((p.variants[vi]||p.variants[0]).price*q);
      };
    }

    /* The existing V31 cart handler catches #detailAdd in capture phase.
       This fallback keeps Add functional even if that handler is unavailable. */
    if(add){
      add.onclick=function(e){
        if(e.__mithHandled)return;
        e.preventDefault();
        e.stopPropagation();
        if(typeof window.addProduct==='function'){
          window.addProduct(p.id,q,vi);
        }
      };
    }

    m.classList.add('open');
    m.setAttribute('aria-hidden','false');
    var card=m.querySelector('.product-detail-card');
    if(card)card.scrollTop=0;
    return true;
  }

  function closeProductVisual(){
    var m=document.getElementById('productDetailModal');
    if(m){
      m.classList.remove('open');
      m.setAttribute('aria-hidden','true');
    }
    clearLegacyLocks();
  }

  function pushCategory(filter){
    history.pushState({mithNav:NAV,kind:'category',filter:filter},'',location.href);
    renderCategoryWithoutHistory(filter);
  }

  function pushProduct(id){
    var parent=pageOpen()
      ? {kind:'category',filter:categoryFilter()||'All'}
      : {kind:'home'};

    history.pushState({
      mithNav:NAV,
      kind:'product',
      productId:id,
      parent:parent
    },'',location.href);

    renderProductVisual(id);
  }

  function openCategory(filter, fromHistory){
    clearLegacyLocks();
    if(!fromHistory){
      var s=state();
      if(s.mithNav===NAV && s.kind==='category' && s.filter===filter){
        renderCategoryWithoutHistory(filter);
      }else{
        pushCategory(filter);
      }
    }else{
      renderCategoryWithoutHistory(filter);
    }
  }

  function openProduct(id, fromHistory){
    clearLegacyLocks();
    if(!fromHistory){
      var s=state();
      if(s.mithNav===NAV && s.kind==='product' && s.productId===id){
        renderProductVisual(id);
      }else{
        pushProduct(id);
      }
    }else{
      renderProductVisual(id);
    }
  }

  function goBack(){
    var s=state();
    if(s.mithNav===NAV && (s.kind==='product'||s.kind==='category')){
      history.back();
      return;
    }

    /* Safety fallback for an old/non-managed state. */
    if(productOpen())closeProductVisual();
    else if(pageOpen())closeCategoryVisual();
    clearLegacyLocks();
  }

  window.mithilanaNavBack=goBack;

  /*
   * Replace the old product opener. This is deliberately NOT a wrapper around
   * the old lock/fixed-position implementation, so it cannot reintroduce the freeze.
   */
  window.openProductDetail=function(id){
    if(!id)return;
    openProduct(String(id),false);
  };

  window.closeProductDetail=function(){
    var s=state();
    if(s.mithNav===NAV && s.kind==='product'){
      history.back();
    }else{
      closeProductVisual();
    }
  };

  /*
   * Replace showCategory after all older patches. The v18 category click
   * capture also uses its history-aware openPage, while all other callers use this.
   */
  var oldShowCategory=window.showCategory;
  window.showCategory=function(filter){
    var f=filter||'All';
    var s=state();
    if(s.mithNav===NAV && s.kind==='category' && s.filter===f){
      renderCategoryWithoutHistory(f);
    }else{
      pushCategory(f);
    }
  };

  window.showCompleteMithilanaRange=function(){
    window.showCategory('All');
  };

  /*
   * Product detail X / outside click / Escape all go ONE history step back.
   */
  var closeBtn=document.getElementById('detailClose');
  if(closeBtn){
    closeBtn.onclick=function(e){
      e.preventDefault();
      e.stopPropagation();
      goBack();
    };
  }

  var modal=document.getElementById('productDetailModal');
  if(modal){
    modal.onclick=function(e){
      if(e.target===modal)goBack();
    };
  }

  document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){
      if(productOpen() || pageOpen()){
        e.preventDefault();
        e.stopPropagation();
        goBack();
      }
    }
  },true);

  /*
   * Browser/Android back:
   *   product -> category (or home)
   *   category -> home
   * Forward re-opens the exact page.
   */
  function applyHistory(){
    if(busy)return;
    busy=true;
    try{
      var s=state();

      if(s.mithNav===NAV && s.kind==='product'){
        if(s.parent && s.parent.kind==='category'){
          renderCategoryWithoutHistory(s.parent.filter||'All');
        }else{
          closeCategoryVisual();
        }
        renderProductVisual(s.productId);
        return;
      }

      if(s.mithNav===NAV && s.kind==='category'){
        closeProductVisual();
        renderCategoryWithoutHistory(s.filter||'All');
        return;
      }

      /* Home/unknown state: close all foreground pages. */
      closeProductVisual();
      closeCategoryVisual();
      clearLegacyLocks();
    }finally{
      busy=false;
    }
  }

  window.addEventListener('popstate',applyHistory);

  /*
   * Establish a stable home state once. No hash is changed, so normal page
   * anchors and the existing website layout continue to work.
   */
  function init(){
    clearLegacyLocks();
    var s=state();
    if(s.mithNav!==NAV){
      history.replaceState({mithNav:NAV,kind:'home'},'',location.href);
    }
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded',init,{once:true});
  }else{
    init();
  }
})();
