
(()=>{
 // Add files under media/products and media/company, then list their paths here when supplied.
 // Leave these empty to keep every current image as it is.
 const mediaOptions=window.MITHILANA_MEDIA={
  slideshowImages:[], // optional paths; current product images are used until these are provided
  companyPhotos:[], // add any number of photo paths, including expo and customer feedback
  companyVideos:Array(3).fill('')
 };
 let slides=[]; // Saved admin slides are the only source; never resurrect bundled product images.
 const img=document.getElementById('mithSlideImage'),caption=document.getElementById('mithSlideCaption'),dots=document.getElementById('mithSlideDots');
 let index=0,timer;
 const show=n=>{if(!slides.length)return;index=(n+slides.length)%slides.length;img.src=slides[index].src;img.alt=slides[index].name;caption.textContent=slides[index].name;[...dots.children].forEach((b,i)=>b.classList.toggle('active',i===index))};
 const start=()=>{clearInterval(timer);if(slides.length>1&&!matchMedia('(prefers-reduced-motion: reduce)').matches)timer=setInterval(()=>{if(!document.hidden)show(index+1)},2000)};
 function rebuild(){dots.replaceChildren();slides.forEach((slide,i)=>{const b=document.createElement('button');b.type='button';b.setAttribute('aria-label',`Show ${slide.name}`);b.onclick=()=>{show(i);start()};dots.append(b)});document.querySelector('.mith-product-carousel').hidden=!slides.length;if(slides.length)show(Math.min(index,slides.length-1));else{img.removeAttribute('src');caption.textContent=''}start()}
 let signature='',busy=false;let pendingRefresh=false;async function refresh(){if(busy){pendingRefresh=true;return}busy=true;try{const r=await fetch('/api/home-slides',{cache:'no-store'});if(!r.ok)throw Error('Slides unavailable');const d=await r.json();if(!Array.isArray(d.slides))throw Error('Invalid slide response');const next=JSON.stringify(d.slides);if(next===signature)return;signature=next;slides=d.slides.map(s=>({src:s.image_url,name:s.name}));rebuild()}catch{slides=[];signature='';rebuild()}finally{busy=false;if(pendingRefresh){pendingRefresh=false;queueMicrotask(refresh)}}}
 rebuild();refresh();setInterval(()=>{if(!document.hidden)refresh()},5000);window.addEventListener('mith:media-sync',refresh);window.addEventListener('focus',refresh);window.addEventListener('pageshow',refresh);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});window.addEventListener('storage',e=>{if(e.key==='mith_public_media_changed')refresh()});
 // Swipe left/right to change slide (replaces the old arrow buttons)
 const frame=document.querySelector('.mith-slide-frame');
 if(frame){let sx=0,sy=0,tracking=false;
  frame.addEventListener('pointerdown',e=>{sx=e.clientX;sy=e.clientY;tracking=true});
  frame.addEventListener('pointerup',e=>{if(!tracking)return;tracking=false;const dx=e.clientX-sx,dy=e.clientY-sy;if(Math.abs(dx)>40&&Math.abs(dx)>Math.abs(dy)){show(dx<0?index+1:index-1);start()}});
  frame.addEventListener('pointercancel',()=>{tracking=false});
  frame.addEventListener('pointerleave',()=>{tracking=false});
 }
 const gallery=document.getElementById('companyMedia');
 mediaOptions.companyPhotos.filter(Boolean).forEach((src,i)=>{const el=document.createElement('img');el.src=src;el.alt=`Mithilana company photo ${i+1}`;el.loading='lazy';gallery.append(el)});
 mediaOptions.companyVideos.filter(Boolean).slice(0,3).forEach(src=>{const el=document.createElement('video');el.src=src;el.controls=true;el.preload='metadata';gallery.append(el)});
})();
