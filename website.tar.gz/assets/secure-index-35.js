
(()=>{
 const $=s=>document.querySelector(s), token=()=>localStorage.getItem('mithilana_token');
 const checkoutForm=$('#checkoutForm');
 const pinInput=$('#checkoutPin'),cityInput=$('#checkoutCity'),stateInput=$('#checkoutState'),lookup=$('#checkoutPinStatus');
 if(pinInput&&cityInput&&stateInput&&lookup){
  let requestNumber=0;
  pinInput.addEventListener('input',async()=>{
   const pin=pinInput.value.replace(/\D/g,'').slice(0,6);pinInput.value=pin;
   const current=++requestNumber;
   cityInput.value='';stateInput.value='';lookup.textContent='';
   if(pin.length!==6)return;
   lookup.textContent='Looking up city and state…';
   try{
    const r=await fetch('/api/pincode/'+pin);const data=await r.json();
    if(current!==requestNumber)return;
    if(!r.ok)throw Error(data.error||'Lookup unavailable');
    cityInput.value=data.city||'';stateInput.value=data.state||'';
    lookup.textContent='City and state added from PIN. Check and edit if needed.';
   }catch(error){if(current===requestNumber)lookup.textContent='PIN lookup unavailable. Enter city and state manually.'}
  });
 }
 const account=$('#mithilanaAccount');
 const section=account?.querySelector('section');
 const menu=document.createElement('div');menu.className='mith-profile-menu';
 const panels=document.createElement('div');
 const options=[['profile','My Profile'],['orders','My Orders'],['track','Track Orders'],['nutrition','Ingredients & Nutrition'],['licenses','Licenses'],['policies','Policies / नीतियाँ']];
 for(const [key,label] of options){
  const button=document.createElement('button');button.type='button';button.textContent=label;button.dataset.profileTab=key;menu.append(button);
  const panel=document.createElement('div');panel.className='mith-profile-content';panel.dataset.profilePanel=key;panel.hidden=true;panels.append(panel);
 }
 const profileHeading=section?.querySelector('h2');
 if(section){profileHeading?.after(menu,panels);}
 const profilePanel=panels.querySelector('[data-profile-panel="profile"]');
 const profileForm=$('#accountForm'),profileMessage=$('#accountMessage');
 if(profileForm)profilePanel?.append(profileForm);
 if(profileMessage)profilePanel?.append(profileMessage);
 const dashboardControls=document.createElement('div');dashboardControls.id='mithDashboardControls';
 menu.after(dashboardControls);
 const orderList=$('#accountOrders');panels.querySelector('[data-profile-panel="orders"]')?.append(orderList);
 const track=panels.querySelector('[data-profile-panel="track"]');
 if(track){const caption=document.createElement('p');caption.textContent='अपने ऑर्डर की वर्तमान स्थिति नीचे देखें।';track.append(caption);const duplicate=document.createElement('div');duplicate.id='mithTrackOrders';track.append(duplicate);}
 panels.querySelector('[data-profile-panel="nutrition"]').textContent='हर उत्पाद की सामग्री और पोषण जानकारी उसके अंतिम सत्यापित लेबल से यहाँ जोड़ी जाएगी।';
 panels.querySelector('[data-profile-panel="licenses"]').textContent='सत्यापित लाइसेंस नंबर और दस्तावेज़ उपलब्ध होने पर यहाँ दिखेंगे।';
 panels.querySelector('[data-profile-panel="policies"]').innerHTML='<p><a href="/privacy.html">Privacy Policy / गोपनीयता नीति ↗</a></p><p><a href="/refund-cancellation.html">Refund & Cancellation / रिफंड और कैंसलेशन ↗</a></p>';
 const policyLinks=document.createElement('p');policyLinks.className='mith-policy-links';policyLinks.innerHTML='<a href="/privacy.html">Privacy Policy / गोपनीयता नीति</a> · <a href="/refund-cancellation.html">Refund & Cancellation / रिफंड और कैंसलेशन</a>';dashboardControls.prepend(policyLinks);
 function showDashboard(){
  menu.hidden=false;
  dashboardControls.hidden=false;
  if(profileHeading)profileHeading.textContent='My Account';
  panels.querySelectorAll('[data-profile-panel]').forEach(p=>p.hidden=true);
  menu.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
  section?.scrollTo(0,0);
 }
 function showTab(key){
  menu.hidden=true;
  dashboardControls.hidden=true;
  if(profileHeading)profileHeading.textContent=options.find(x=>x[0]===key)?.[1]||'My Account';
  menu.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b.dataset.profileTab===key));
  panels.querySelectorAll('[data-profile-panel]').forEach(p=>p.hidden=p.dataset.profilePanel!==key);
  section?.scrollTo(0,0);
  if(key==='track'){
   const box=$('#mithTrackOrders');box.replaceChildren();
   const orders=Array.from(orderList?.querySelectorAll('article')||[]);
   if(orders.length)orders.forEach(row=>box.append(row.cloneNode(true)));
   else box.textContent='No orders yet.';
  }
  if(key==='profile'){
   const p=panels.querySelector('[data-profile-panel="profile"]');
   const msg=$('#accountMessage');if(msg)msg.textContent='Loading profile…';
   fetch('/api/me',{headers:{Authorization:'Bearer '+token()}}).then(r=>r.ok?r.json():null).then(data=>{
    if(!data?.user){if(msg)msg.textContent='Profile unavailable. Please log in again.';return}
    if(msg)msg.textContent='';
    for(const [field,value] of Object.entries(data.user)){
     const input=p?.querySelector('[name="'+field+'"]');if(input)input.value=value||'';
    }
   }).catch(()=>{if(msg)msg.textContent='Profile unavailable right now.'});
  }
 }
 menu.addEventListener('click',e=>{const key=e.target.closest('[data-profile-tab]')?.dataset.profileTab;if(key){history.pushState({mithAccount:key},'',location.href);showTab(key)}});
 if(orderList)new MutationObserver(()=>{
  if(!panels.querySelector('[data-profile-panel="track"]')?.hidden){
   const box=$('#mithTrackOrders');box.replaceChildren();
   const orders=Array.from(orderList.querySelectorAll('article'));
   if(orders.length)orders.forEach(row=>box.append(row.cloneNode(true)));
   else box.textContent='No orders yet.';
  }
 }).observe(orderList,{childList:true});
 let accountWasOpen=false;
 const openAccount=window.mithShowAccount;
 if(typeof openAccount==='function')window.mithShowAccount=function(...args){
  const result=openAccount.apply(this,args);
  if(account.classList.contains('open')){showDashboard();if(!history.state?.mithAccount)history.pushState({mithAccount:'dashboard'},'',location.href);accountWasOpen=true}
  return result;
 };
 const accountObserver=new MutationObserver(()=>{
  const isOpen=account.classList.contains('open');
  if(isOpen&&!accountWasOpen){showDashboard();if(!history.state?.mithAccount)history.pushState({mithAccount:'dashboard'},'',location.href)}
  accountWasOpen=isOpen;
 });
 accountObserver.observe(account,{attributes:true,attributeFilter:['class']});
 window.addEventListener('popstate',event=>{
  if(!account.classList.contains('open'))return;
  if(event.state?.mithAccount && event.state.mithAccount!=='dashboard')showTab(event.state.mithAccount);
  else if(event.state?.mithAccount==='dashboard')showDashboard();
  else{account.classList.remove('open');showDashboard()}
 });
 showDashboard();
 const logout=document.createElement('button');logout.type='button';logout.id='profileLogout';
 logout.textContent='Log out / लॉग आउट';logout.style.cssText='display:block;margin:16px 0;padding:11px 18px;border-radius:10px;border:1px solid #a74631;background:#fff3e9;color:#822e24;font-weight:700';
 dashboardControls.append(logout);
 const waiting=document.createElement('div');waiting.id='mithLogoutWait';waiting.setAttribute('role','status');waiting.innerHTML='<span class="spinner" aria-hidden="true"></span><span>Logging out…</span>';document.body.append(waiting);
 logout.addEventListener('click',async()=>{
  if(logout.disabled)return;
  logout.disabled=true;waiting.classList.add('open');
  try{const r=await fetch('/api/auth/logout',{method:'POST',headers:{Authorization:'Bearer '+token()}});if(!r.ok&&r.status!==401)throw Error('Logout could not be completed. Please retry.');await new Promise(r=>setTimeout(r,1200));}catch(e){logout.disabled=false;waiting.classList.remove('open');toast(e.message);return}
  {
   localStorage.removeItem('mithilana_token');localStorage.removeItem('mithilana_user');localStorage.removeItem('mithilana_otp_sent');
   account.classList.remove('open');$('#loginModal')?.classList.remove('open');
   const btn=$('#loginBtn');if(btn){btn.textContent='LOGIN';btn.classList.remove('logged')}
   window.dispatchEvent(new Event('mithilana:logout'));
   waiting.classList.remove('open');logout.disabled=false;showDashboard();
  }
 });
 // One foreground handler owns these entry points, independently of the old
 // product and navigation scripts. A signed-out visitor can always log in.
 window.addEventListener('click',e=>{
  if(e.target.closest('#loginBtn')){
   e.preventDefault();e.stopImmediatePropagation();
   if(token()){showDashboard();window.mithShowAccount?.()}else window.openLogin?.();
   return;
  }
  if(e.target.closest('#checkoutBtn')){
   e.preventDefault();e.stopImmediatePropagation();
   if(!window.cart?.length){window.toast?.('Add a product to the cart first');return}
   if(!token()){window.openLogin?.();return}
   $('#cart')?.classList.remove('open');$('#overlay')?.classList.remove('open');
   $('#checkoutTotal').textContent=typeof money==='function'?money(window.cart.reduce((sum,item)=>sum+Number(item.price)*Number(item.qty),0)):'';
   $('#checkoutModal')?.classList.add('open');
   fetch('/api/me',{headers:{Authorization:'Bearer '+token()}}).then(r=>r.ok?r.json():null).then(data=>{
    if(!data?.user)return;
    const form=$('#checkoutForm');if(!form||!$('#checkoutModal')?.classList.contains('open'))return;
    const u=data.user;
    if(!form.elements.name.value)form.elements.name.value=u.name||'';
    if(!form.elements.phone.value)form.elements.phone.value=u.phone||'';
    if(!form.elements.address.value)form.elements.address.value=u.address_line1||'';
    if(!form.elements.pincode.value && u.pincode){form.elements.pincode.value=u.pincode;form.elements.pincode.dispatchEvent(new Event('input'))}
    if(!form.elements.city.value)form.elements.city.value=u.city||'';
    if(!form.elements.state.value)form.elements.state.value=u.state||'';
   }).catch(()=>{});
   return;
  }
  if(e.target.closest('#waCartBtn,#loginSupportBtn,#supportLink,#waFloat')){
   e.preventDefault();e.stopImmediatePropagation();
   $('#cart')?.classList.remove('open');$('#overlay')?.classList.remove('open');
   $('#loginModal')?.classList.remove('open');$('#waSupportPop')?.classList.remove('open');
   const dialog=$('#whatsappSupportModal');dialog?.classList.add('open');dialog?.setAttribute('aria-hidden','false');
  }
 },true);
})();
