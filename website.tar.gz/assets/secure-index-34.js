
(()=>{
 const $=s=>document.querySelector(s), overlay=$('#mithRouteOverlay'), body=$('#mithRouteBody');
 const originals=[];let current='home';
 const title={categories:['Categories','श्रेणियाँ'],builder:['Build Your Own Box','अपना बॉक्स बनाएं'],company:['About Our Company','हमारी कंपनी']};
 function restore(){
  for(const item of originals.splice(0)){
   if(item.marker.parentNode)item.marker.replaceWith(item.element);
  }
  body.replaceChildren();
 }
 function move(id){const el=document.getElementById(id);if(!el||!el.parentNode)return;const marker=document.createComment('Mithilana '+id);el.parentNode.insertBefore(marker,el);originals.push({element:el,marker});body.appendChild(el)}
 function closeOld(){
  $('#mithFeaturePage')?.classList.remove('open');$('#categoryPage')?.classList.remove('open');$('#productDetailModal')?.classList.remove('open');
  $('#mithSearchPage')?.classList.remove('open');document.body.style.overflow='';
 }
 function home(){
  restore();current='home';overlay.classList.remove('open');overlay.setAttribute('aria-hidden','true');
  closeOld();$('#cart')?.classList.remove('open');$('#overlay')?.classList.remove('open');
  $('#checkoutModal')?.classList.remove('open');window.scrollTo(0,0);
 }
 function page(name,filter,historyAction='push'){
  if(!title[name])return;
  restore();closeOld();current=filter&&name==='categories'?'categoryItems':name;
  const hi=localStorage.getItem('mithilana_language')==='hi';
  if(name==='categories'&&filter){
   // A selected range is its own full-screen product page, without category cards above it.
   move('products');
   if(typeof renderProducts==='function')renderProducts(filter);
   const heading=$('#products h2');if(heading)heading.textContent=filter==='Accessories'?(hi?'मिथिलाना एक्सेसरीज़':'Mithilana Accessories'):filter;
   $('#mithRouteTitle').textContent=heading?.textContent||filter;
  }else if(name==='categories'){
   move('categories');$('#mithRouteTitle').textContent=title.categories[hi?1:0];
  }else if(name==='builder'){
   move('mithBuildBox');$('#mithRouteTitle').textContent=title.builder[hi?1:0];
  }else{
   move('about-my-company');$('#mithRouteTitle').textContent=title.company[hi?1:0];
   const company=$('#about-my-company');if(company&&!company.querySelector('.mith-company-policies')){const links=document.createElement('p');links.className='mith-company-policies';links.innerHTML='<a href="/privacy.html">Privacy Policy / गोपनीयता नीति</a> · <a href="/refund-cancellation.html">Refund & Cancellation / रिफंड और कैंसलेशन</a>';company.append(links)}
  }
  overlay.classList.add('open');overlay.setAttribute('aria-hidden','false');body.scrollTop=0;
  if(historyAction!=='none'){
   try{history[historyAction==='replace'?'replaceState':'pushState']({mithRoute:current,filter:filter||null},'',location.href)}catch(e){}
  }
 }
 function goHome(){
  home();
  if(history.state?.mithRoute||history.state?.mithCart){history.back()}
 }

 // Window capture runs before the older document handlers and inline onclick.
 window.addEventListener('click',e=>{
  const routeBack=e.target.closest('#mithRouteBack,#siteBackBtn');
  if(routeBack){e.preventDefault();e.stopImmediatePropagation();goHome();return}
  const cartClose=e.target.closest('#closeCart,#overlay');
  if(cartClose&&$('#cart')?.classList.contains('open')){e.preventDefault();e.stopImmediatePropagation();goHome();return}
  const nav=e.target.closest('#mithMainNav a,footer .footer-links a');
  if(nav){
   const target=nav.dataset.mithPage==='builder'?'builder':nav.dataset.mithPage==='company'||nav.getAttribute('href')==='#about-my-company'?'company':nav.dataset.mithRoute==='categories'||nav.getAttribute('href')==='#categories'?'categories':nav.getAttribute('href')==='#home'?'home':null;
   if(target){e.preventDefault();e.stopImmediatePropagation();target==='home'?goHome():page(target,null,current==='home'?'push':'replace');return}
  }
  if(e.target.closest('#categories .section-head')){e.preventDefault();e.stopImmediatePropagation();page('categories');return}
  const category=e.target.closest('#categories .mith-range-card');
  if(category){e.preventDefault();e.stopImmediatePropagation();
   const filter=category.dataset.filter||'All';
   page('categories',filter,current==='categories'?'replace':'push');
   return;
  }
  if(current==='home'&&e.target.closest('#exploreProductsBtn,.single-collection')){e.preventDefault();e.stopImmediatePropagation();page('categories');return}
  if(e.target.closest('#cartItems .empty a')){e.preventDefault();e.stopImmediatePropagation();window.closeCart?.();page('categories');return}
 },true);

 // Every foreground route and cart returns to the top of Home with one Back.
 window.addEventListener('popstate',()=>{if(!$('#mithilanaAccount')?.classList.contains('open'))home()});
 const originalOpenCart=window.openCart;
 if(typeof originalOpenCart==='function')window.openCart=function(...args){
  if(current!=='home'){restore();current='home';overlay.classList.remove('open');overlay.setAttribute('aria-hidden','true')}
  if(!history.state?.mithCart){try{history[history.state?.mithRoute?'replaceState':'pushState']({mithCart:true},'',location.href)}catch(e){}}
  return originalOpenCart.apply(this,args);
 };

 // Re-show the first-run language choice on the corrected build once.
 const choice=$('#languageChoice');
 try{if(!localStorage.getItem('mithilana_language_choice_v8')){choice?.classList.add('open','mith-first-language');if(choice)choice.style.display='flex'}}catch(e){}
 choice?.querySelectorAll('[data-lang]').forEach(button=>button.addEventListener('click',()=>{
  try{localStorage.setItem('mithilana_language_choice_v8','1')}catch(e){}
  choice.classList.remove('mith-first-language');choice.style.display='';
  if(current!=='home'&&title[current])$('#mithRouteTitle').textContent=title[current][button.dataset.lang==='hi'?1:0];
 },true));
 // The old guest checkout can save a fake order in localStorage. Require a
 // verified account and a real order response from the website server.
 let placing=false;
 document.addEventListener('submit',async e=>{
  if(e.target?.id!=='checkoutForm')return;
  e.preventDefault();e.stopImmediatePropagation();
  if(placing)return;
  const form=e.target, token=localStorage.getItem('mithilana_token');
  const box=form.closest('.modal-box');
  let notice=$('#mithVerifiedCheckoutStatus');
  if(!notice){notice=document.createElement('p');notice.id='mithVerifiedCheckoutStatus';notice.setAttribute('role','status');box?.append(notice)}
  if(!token){notice.textContent='Please login with Google before ordering.';window.openLogin?.();return}
  if(location.protocol==='file:'||location.protocol==='content:'){notice.textContent='Live checkout needs the Mithilana server and API connection. No order was placed.';return}
  const cart=window.cart||[];
  if(!cart.length){notice.textContent='Your cart is empty.';return}
  const data=new FormData(form), address=String(data.get('address')||'').trim();
  const pin=String(data.get('pincode')||'').trim();
  const city=String(data.get('city')||'').trim(),state=String(data.get('state')||'').trim();
  if(!/^[1-9][0-9]{5}$/.test(pin)){notice.textContent='Enter a valid 6-digit PIN code in its separate box.';return}
  if(!city||!state){notice.textContent='Enter city and state to complete your address.';return}
  const button=form.querySelector('[type="submit"]');placing=true;button.disabled=true;notice.textContent='Placing order…';
  try{
   const headers={'Content-Type':'application/json',Authorization:'Bearer '+token};
   const catalogResponse=await fetch('/api/products',{headers});
   const catalog=await catalogResponse.json();if(!catalogResponse.ok)throw Error(catalog.error||'Product service unavailable');
   const entries=cart.map(item=>{const found=(catalog.products||[]).find(p=>p.id===item.productId);const variant=found?.variants.find(v=>v.id===item.variantId);if(!found||!variant)throw Error(item.name+' / '+item.label+' is no longer available. Remove it from the cart.');if(Number(variant.stock)<Number(item.qty))throw Error(item.name+' / '+item.label+' does not have enough stock.');return {product_id:found.id,variant_id:variant.id,quantity:Number(item.qty)}});
   const payload={items:entries,shipping_name:data.get('name'),shipping_phone:data.get('phone'),shipping_address:{line1:address,city,state,pincode:pin},offer_code:String(data.get('offer_code')||'').trim().toUpperCase(),payment_method:data.get('payment')==='upi'?'razorpay':'cod'};
   const serialized=JSON.stringify(payload);let attempt;try{attempt=JSON.parse(localStorage.getItem('mith_checkout_attempt')||'null')}catch{}
   if(!attempt||attempt.payload!==serialized){attempt={payload:serialized,key:crypto.randomUUID()};localStorage.setItem('mith_checkout_attempt',JSON.stringify(attempt))}
   const response=await fetch('/api/orders',{method:'POST',headers:{...headers,'Idempotency-Key':attempt.key},body:serialized});
   const result=await response.json();if(!response.ok)throw Error(result.error||'Order could not be placed');
   if(result.payment){
    if(!window.Razorpay)throw Error('Payment window is unavailable. Your payment is pending; contact support with order '+result.order.id);
    notice.textContent='Complete the secure Razorpay payment…';
    const verified=await new Promise((resolve,reject)=>{
      const gateway=new Razorpay({
       key:result.payment.keyId,amount:result.payment.amount,currency:'INR',
       name:'Mithilana',order_id:result.payment.providerOrderId,
       prefill:{name:String(data.get('name')||''),contact:String(data.get('phone')||'')},
       handler:async response=>{
        try{
         const check=await fetch('/api/payments/razorpay/verify',{
          method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},
          body:JSON.stringify({order_id:response.razorpay_order_id,payment_id:response.razorpay_payment_id,signature:response.razorpay_signature})
         });
         const verified=await check.json();if(!check.ok)throw Error(verified.error||'Payment verification pending. Contact support with order '+result.order.id);
         resolve(verified);
        }catch(error){reject(error)}
       },modal:{ondismiss:()=>reject(Error('Payment window closed. Your order is pending. Contact support with order '+result.order.id))}
      });
      gateway.on('payment.failed',()=>reject(Error('Payment failed. Your order is pending. Contact support with order '+result.order.id)));
      gateway.open();
    });
    result.order=verified.order;
   }
   localStorage.removeItem('mith_checkout_attempt');
   cart.length=0;localStorage.setItem('mithilana_cart','[]');if(typeof renderCart==='function')renderCart();if(typeof updateCount==='function')updateCount();
   form.reset();$('#checkoutModal')?.classList.remove('open');window.closeCart?.();
   if(window.mithilanaReceipt && result.order)window.mithilanaReceipt(result.order);
   else notice.textContent='Order received. Reference: '+(result.order?.id||'');
  }catch(error){notice.textContent=error.message||'Order service is not available.'}
  finally{placing=false;button.disabled=false}
 },true);
})();
