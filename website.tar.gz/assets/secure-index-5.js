
// V3 all-products + dry-fruit flavour + quantity fixes
(function(){
  const LS_USER='mithilana_user';
  let detailQty=1;
  function currentUser(){try{return JSON.parse(localStorage.getItem(LS_USER)||'null')}catch(e){return null}}
  function updateLoginUI(){
    const b=document.getElementById('loginBtn'); const u=currentUser();
    if(!b) return;
    b.textContent=u ? 'ACCOUNT' : 'LOGIN'; b.classList.toggle('logged',!!u);
  }
  window.openLogin=function(){document.getElementById('loginModal').classList.add('open');const u=currentUser();if(u){document.getElementById('loginStatus').textContent='Logged in as '+(u.phone||u.email||'your account')+' on this device.'}}
  window.closeLogin=function(){document.getElementById('loginModal').classList.remove('open')}
  document.getElementById('loginBtn').onclick=openLogin;
  document.getElementById('loginClose').onclick=closeLogin;

  document.getElementById('loginModal').addEventListener('click',e=>{if(e.target.id==='loginModal')closeLogin()});
  updateLoginUI();

  // Require login before checkout.
  const oldCheckout=window.openCheckout;
  window.openCheckout=function(){
    if(!currentUser()){openLogin();toast('Please login before placing your order');return}
    oldCheckout();
  };
  const checkoutBtn=document.getElementById('checkoutBtn'); if(checkoutBtn) checkoutBtn.onclick=window.openCheckout;

  // Quantity-aware add to cart.
  const oldAdd=window.addProduct;
  window.addProduct=function(id,qty=1,viOverride=null){
    const p=products.find(x=>x.id===id); if(!p)return;
    const s=document.getElementById('v-'+id); const vi=viOverride!==null?Number(viOverride):(s?Number(s.value):0); const v=p.variants[vi]||p.variants[0];
    const key=id+'-'+vi; const old=cart.find(x=>x.key===key); if(old)old.qty+=Math.max(1,Number(qty)||1); else cart.push({key,id,vi,qty:Math.max(1,Number(qty)||1),name:p.name,cat:p.cat,label:v.label,price:v.price,img:p.img}); save(); toast('Added '+(Math.max(1,Number(qty)||1))+' item(s) to cart ✓');
  };

  // Replace product detail with quantity-aware version.
  window.openProductDetail=function(id){
    const p=products.find(x=>x.id===id); if(!p)return;
    const m=document.getElementById('productDetailModal'); document.getElementById('detailImage').src=p.img; document.getElementById('detailImage').alt=p.name; document.getElementById('detailCat').textContent=p.cat; document.getElementById('detailName').textContent=p.name; document.getElementById('detailDesc').textContent=p.desc;
    const vb=document.getElementById('detailVariants'); vb.innerHTML=p.variants.map((v,i)=>`<button class="${i===0?'active':''}" data-i="${i}">${htmlEscape(v.label)} — ${money(v.price)}</button>`).join('');
    let vi=0; detailQty=1; document.getElementById('detailQty').textContent='1'; document.getElementById('detailPrice').textContent=money(p.variants[0].price*detailQty);
    vb.querySelectorAll('button').forEach(b=>b.onclick=()=>{vi=Number(b.dataset.i);vb.querySelectorAll('button').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.getElementById('detailPrice').textContent=money(p.variants[vi].price*detailQty)});
    document.getElementById('detailQtyMinus').onclick=()=>{detailQty=Math.max(1,detailQty-1);document.getElementById('detailQty').textContent=detailQty;document.getElementById('detailPrice').textContent=money(p.variants[vi].price*detailQty)};
    document.getElementById('detailQtyPlus').onclick=()=>{detailQty=Math.min(99,detailQty+1);document.getElementById('detailQty').textContent=detailQty;document.getElementById('detailPrice').textContent=money(p.variants[vi].price*detailQty)};
    document.getElementById('detailAdd').onclick=()=>{addProduct(p.id,detailQty,vi);m.classList.remove('open')};
    m.classList.add('open');
  };

  // If an old inline handler tries the original function, use our global version.
  const form=document.getElementById('checkoutForm');
  form.querySelector('button[type="submit"]').type='submit';
})();
