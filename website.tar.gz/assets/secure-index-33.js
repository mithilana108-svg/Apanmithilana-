
(function(){
 const q=s=>document.querySelector(s), qa=s=>[...document.querySelectorAll(s)];
 const feature=q('#mithFeaturePage'), body=q('#mithFeatureBody'), title=q('#mithFeatureTitle');
 const auth=q('#mithOrderAuth');
 let pendingAction=null;

 // Language chooser: first opening only. No persistent header language button.
 q('#mithLangNavBtn')?.remove();
 if(!localStorage.getItem('mithilana_language')){
   const lc=q('#languageChoice');
   if(lc){lc.classList.add('open','mith-first-language');lc.style.display='flex';}
 }
 qa('#languageChoice [data-lang]').forEach(b=>b.addEventListener('click',()=>{
   localStorage.setItem('mithLangChosen','1');
   setTimeout(()=>{const lc=q('#languageChoice');if(lc){lc.classList.remove('mith-first-language');lc.style.display='none';}},0);
 }));

 function restoreMoved(){
   qa('[data-p4-origin]').forEach(el=>{
     const id=el.getAttribute('data-p4-origin'), ph=document.getElementById(id);
     if(ph) ph.replaceWith(el);
     el.removeAttribute('data-p4-origin');
   });
 }
 function move(el){
   if(!el)return false;
   const id='p4ph_'+Math.random().toString(36).slice(2);
   const ph=document.createElement('span');ph.id=id;ph.style.display='none';
   el.parentNode.insertBefore(ph,el);el.setAttribute('data-p4-origin',id);body.appendChild(el);return true;
 }
 function openPage(kind){
   restoreMoved(); body.innerHTML='';
   if(kind==='builder'){
     const b=q('#mithBuildBox'); if(b){b.style.display='';move(b)}
     title.textContent='Build Your Own Box';
   } else if(kind==='company'){
     title.textContent=localStorage.getItem('mithilana_language')==='hi'?'हमारी कंपनी':'About Our Company';
     const hi=localStorage.getItem('mithilana_language')==='hi';
     body.innerHTML=`<div class="mith-info-grid"><div class="mith-info-card"><h3>${hi?'मिथिलाना के बारे में':'About Mithilana'}</h3><p>${hi?'मिथिला की खाद्य परंपरा और उत्पादों को आपके घर तक पहुँचाने का हमारा प्रयास।':'Mithilana brings Mithila food traditions and products to your table.'}</p></div><div class="mith-info-card"><h3>${hi?'सामग्री':'Ingredients'}</h3><p>${hi?'हर उत्पाद की सत्यापित सामग्री अंतिम पैक की जानकारी मिलने पर जोड़ी जाएगी।':'Verified ingredients for each product will be added from the final pack information.'}</p></div><div class="mith-info-card"><h3>${hi?'पोषण मूल्य':'Nutrition Value'}</h3><p>${hi?'सत्यापित पोषण मूल्य प्रत्येक उत्पाद और स्वाद के लिए अंतिम लेबल से जोड़े जाएँगे।':'Verified nutrition values for each product and flavour will be added from final labels.'}</p></div></div>`;
     move(q('#about-my-company')); 
   } else if(kind==='account'){
     title.textContent='My Account';
     body.innerHTML=`<div class="mith-account-grid">
       <div class="mith-account-tile" data-account-action="track"><h3>Track Orders</h3><p>अपने verified account के orders देखें और track करें।</p></div>
       <div class="mith-account-tile" data-account-action="review"><h3>My Reviews</h3><p>Delivered products के reviews देखें या लिखें।</p></div>
       <div class="mith-account-tile"><h3>Reorder</h3><p>Previous orders से दोबारा order करें।</p></div>
     </div>`;
   }
   feature?.classList.add('open'); feature?.setAttribute('aria-hidden','false'); document.body.style.overflow='hidden';
 }
 document.addEventListener('click',e=>{
   const p=e.target.closest('[data-mith-page]');
   if(p){e.preventDefault();openPage(p.dataset.mithPage)}
   
   const aa=e.target.closest('[data-account-action]');
   if(aa){
     const cards=qa('.mith-p2-card');
     const card=aa.dataset.accountAction==='track'
       ? cards.find(x=>/Track Your Order/i.test(x.textContent||''))
       : cards.find(x=>/^Reviews/i.test((x.textContent||'').trim()));
     if(card){body.innerHTML='';move(card);title.textContent=aa.dataset.accountAction==='track'?'Track Orders':'My Reviews'}
   }
 });
 q('#mithFeatureBack')?.addEventListener('click',()=>{restoreMoved();feature?.classList.remove('open');document.body.style.overflow=''});

 function signedIn(){return !!localStorage.getItem('mithilana_token')}
 function requireAuth(fn){
   if(signedIn()){fn();return}
   pendingAction=fn;window.openLogin?.();
 }
 function closeAuth(){auth?.classList.remove('open');auth?.setAttribute('aria-hidden','true')}
 q('#mithAuthClose')?.addEventListener('click',closeAuth);
 window.addEventListener('mithilana:login',()=>{const action=pendingAction;pendingAction=null;if(action)action();});

 // Gate checkout/order placement. Browsing and cart building remain public.
 document.addEventListener('click',e=>{
   const t=e.target.closest('button,a');
   if(!t || signedIn() || auth?.contains(t))return;
   const text=(t.textContent||'').trim().toLowerCase();
   const id=(t.id||'').toLowerCase();
   const isOrder=/checkout|place order|buy now|proceed to pay|payment/.test(text+' '+id);
   if(isOrder){
     e.preventDefault();e.stopImmediatePropagation();
     requireAuth(()=>t.click());
   }
 },true);

 // Explicitly remove old public nav items if any survived.
 qa('#mithMainNav [data-mith-page="tracking"],#mithMainNav [data-mith-page="reviews"],#mithMainNav [data-mith-page="productinfo"]').forEach(x=>x.remove());
})();
