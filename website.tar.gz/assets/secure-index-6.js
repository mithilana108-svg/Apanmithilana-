
(function(){
  // Final Mithilana fixes: one collection image, complete product range, working cart/login, and combo pricing.
  const money2=n=>"₹"+Number(n).toLocaleString("en-IN");
  function goAllProducts(){
    if(typeof renderProducts==='function') renderProducts('All');
    document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x.dataset.filter==='All'));
    const p=document.getElementById('products'); if(p) p.scrollIntoView({behavior:'smooth',block:'start'});
  }
  // Explore Mithilana must open the full product range, not the heritage section.
  const ex=document.getElementById('exploreProductsBtn');
  if(ex){ ex.onclick=e=>{e.preventDefault();goAllProducts();}; }
  // Main collection image is ONE image: no individual borders/cards around it.
  const showcase=document.querySelector('.single-collection');
  if(showcase){showcase.style.cssText='display:block!important;margin:0 auto 26px!important;padding:0!important;border:0!important;background:transparent!important;box-shadow:none!important;border-radius:0!important;overflow:hidden!important;'; const img=showcase.querySelector('img'); if(img){img.style.cssText='display:block;width:100%;height:auto;max-height:none;object-fit:contain;border:0!important;border-radius:18px;box-shadow:none;';}}
  // Use the actual Dry Fruit Flavoured Makhana product image for the third Explore card.
  const cards=document.querySelectorAll('.cat-card');
  if(cards[2] && typeof products!=='undefined'){
    const df=products.find(p=>p.id==='dry-fruit-flavour');
    if(df){const im=cards[2].querySelector('img'); if(im){im.src=df.img; im.alt=df.name;}}
    cards[2].querySelector('span').textContent='Dry Fruit Flavoured Makhana';
  }
  // Remove any duplicate "All" filter buttons if present.
  document.querySelectorAll('.filters .filter').forEach((b,i)=>{if(b.dataset.filter==='All' && i>0)b.remove();});
  // Ensure every product card opens its own detail modal, and all products really means all.
  window.showAllMithilanaProducts=goAllProducts;
  // Bulletproof cart click, including after dynamic DOM updates.
  document.addEventListener('click',e=>{
    const b=e.target.closest('#cartBtn');
    if(b){e.preventDefault();e.stopPropagation(); if(typeof openCart==='function') openCart();}
  },true);
  // Persistent local login: keep the session until the user explicitly logs out/clears site data.
  const USER_KEY='mithilana_user';
  function user(){try{return JSON.parse(localStorage.getItem(USER_KEY)||'null')}catch(e){return null}}
  function updateAccount(){const b=document.getElementById('loginBtn');if(!b)return;const u=user();b.textContent=u?'ACCOUNT':'LOGIN';b.classList.toggle('logged',!!u);}
  updateAccount();
  // Cart remains usable after login; checkout asks for login only when necessary.
  const oldOpenCheckout=window.openCheckout;
  window.openCheckout=function(){
    if(!cart.length){toast('Add a product to the cart first');return;}
    if(!user()){openLogin();toast('Please login before placing the order');return;}
    if(oldOpenCheckout) oldOpenCheckout();
  };
  const cb=document.getElementById('checkoutBtn'); if(cb) cb.onclick=window.openCheckout;
  // Detail quantity control is kept; add button uses the selected quantity.
  // Do not wipe the cart when login state changes.
  window.addEventListener('storage',updateAccount);
})();
