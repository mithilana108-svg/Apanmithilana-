
(function(){
  const USER_KEY='mithilana_user';
  // Old WhatsApp-OTP leftovers (saved phone number) are removed from this device.
  try{localStorage.removeItem('mithilana_otp_phone');localStorage.removeItem('mithilana_otp_sent')}catch(e){}
  const SUPPORT=(typeof CONFIG!=='undefined'&&CONFIG.WHATSAPP_NUMBER)?CONFIG.WHATSAPP_NUMBER:'91XXXXXXXXXX';
  const $=s=>document.querySelector(s);
  const user=()=>{try{return JSON.parse(localStorage.getItem(USER_KEY)||'null')}catch(e){return null}};
  const setUser=u=>localStorage.setItem(USER_KEY,JSON.stringify(u));
  const clearUser=()=>localStorage.removeItem(USER_KEY);
  function validPhone(v){return /^\d{10}$/.test(String(v).replace(/\D/g,''));}
  function showMsg(t,ok=false){const e=$('#loginMsg');if(e){e.textContent=t;e.style.color=ok?'#245b4a':'#8b3028';}}
  function updateAccount(){const b=$('#loginBtn');if(!b)return;const u=user();b.textContent=u?'MY ACCOUNT':'LOGIN';b.classList.toggle('logged',!!u);const shortcut=$('#mithProfileShortcut');if(shortcut)shortcut.hidden=!localStorage.getItem('mithilana_token');}
  function support(){const n=String(SUPPORT).replace(/\D/g,'');if(n.length>=10)window.open('https://wa.me/'+n+'?text='+encodeURIComponent('Hello Mithilana, I need customer help/support.'),'_blank');else toast('WhatsApp support number is not configured yet.');}
  function openLogin(){
    const m=$('#loginModal'); if(!m)return;
    // The cart has a higher stacking layer than the old login dialog.
    // Close it before showing the login choice after Checkout.
    $('#cart')?.classList.remove('open');
    $('#overlay')?.classList.remove('open');
    $('#checkoutModal')?.classList.remove('open');
    m.classList.add('open');
    const googleStatus=$('#mithGoogleStatus'); if(googleStatus)googleStatus.textContent=''; $('#loginMsg').textContent='';
    const u=user();
    $('#logoutBtn').hidden=!u; $('#loginStatus').textContent=u?'Logged in as '+(u.phone?'+91 '+u.phone:(u.email||'Google account'))+'. Login is saved on this device.':'';
    showMsg('');
  }
  function closeLogin(){const m=$('#loginModal');if(m)m.classList.remove('open');}
  window.openLogin=openLogin; window.closeLogin=closeLogin;
  // Replace old password-login handlers by cloning the modal controls.
  const lb=$('#loginBtn'), lc=$('#loginClose'); if(lb)lb.onclick=openLogin; if(lc)lc.onclick=closeLogin;
  const ls=$('#loginSupportBtn'); if(ls)ls.onclick=support;
  const lo=$('#logoutBtn'); if(lo)lo.onclick=()=>{window.dispatchEvent(new Event('mithilana:logout'));localStorage.removeItem('mithilana_token');clearUser();const gs=$('#mithGoogleStatus');if(gs)gs.textContent='';try{window.google?.accounts?.id?.disableAutoSelect()}catch(e){};updateAccount();$('#loginStatus').textContent='';$('#logoutBtn').hidden=true;showMsg('',true);};
  $('#loginModal')?.addEventListener('click',e=>{if(e.target.id==='loginModal')closeLogin()});
  updateAccount();

  // Full product range: Explore image and range cards always go to all products.
  window.showAllMithilanaProducts=function(){
    if(typeof renderProducts==='function')renderProducts('All');
    document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x.dataset.filter==='All'));
    document.querySelector('#products')?.scrollIntoView({behavior:'smooth',block:'start'});
  };
  const ex=$('#exploreProductsBtn'); if(ex)ex.onclick=e=>{e.preventDefault();window.showAllMithilanaProducts();};
  document.querySelector('.single-collection')?.addEventListener('click',()=>window.showAllMithilanaProducts());

  // Combo pricing: Adhori + Kumrauri ₹700; Flavoured Makhana Combo ₹1400.
  const comboText=document.querySelector('.combo-intro p'); if(comboText)comboText.textContent='Choose your Mithilana combo — Adhori + Kumrauri is ₹700; Flavoured Makhana Combo is ₹1400.';
  document.querySelectorAll('.combo-actions .primary').forEach((b,i)=>{b.textContent=i===0?'Adhori + Kumrauri · ₹700':'Flavoured Makhana Combo · ₹1400';});
  const flavCombo=products.find(p=>p.id==='flav-combo'); if(flavCombo){flavCombo.variants=[{label:'Combo',price:1400}];}

  // Remove any extra All filter buttons, keep one internal All state for Explore.
  const filters=document.querySelector('.filters'); if(filters){let seen=false;filters.querySelectorAll('.filter').forEach(b=>{if(b.dataset.filter==='All'){if(seen)b.remove();else seen=true;}})}

  // Cart must always open. Checkout requires Google login, but cart itself is viewable.
  document.addEventListener('click',e=>{const b=e.target.closest('#cartBtn');if(b){e.preventDefault();e.stopPropagation();if(typeof openCart==='function')openCart();}},true);
  const checkout=document.querySelector('#checkoutBtn'); if(checkout){checkout.onclick=()=>{if(!cart.length){toast('Add a product to the cart first');return;}if(!user()){openLogin();toast('Login with Google to continue');return;}if(typeof openCheckout==='function')openCheckout();};}

  // Keep account/login session and cart across refreshes. No password is stored.
  updateAccount();
})();
