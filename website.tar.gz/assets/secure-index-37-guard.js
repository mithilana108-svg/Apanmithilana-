/* Must be the FIRST script on the page: it runs before every other Back-button handler,
   so the image viewer / About window can close without the page behind it also closing. */
window.addEventListener('popstate', function (e) {
  if (typeof window.__pmBack === 'function' && window.__pmBack(e)) e.stopImmediatePropagation();
}, true);
