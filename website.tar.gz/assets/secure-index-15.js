
(function(){
  'use strict';
  var PRODUCT_STATE='mithProductDetail';
  var CATEGORY_STATE='mithCategoryPage';
  var closingFromPop=false;

  function categoryIsOpen(){
    var p=document.getElementById('categoryPage');
    return !!(p && p.classList.contains('open'));
  }
  function detailIsOpen(){
    var p=document.getElementById('productDetailModal');
    return !!(p && p.classList.contains('open'));
  }
  function currentCategory(){
    var p=document.getElementById('categoryPage');
    return p && p.querySelector('.category-title') ? p.querySelector('.category-title').textContent : 'All Products';
  }

  /* Category page gets its own browser history entry. */
  var observer=new MutationObserver(function(records){
    records.forEach(function(r){
      if(r.type!=='attributes' || r.attributeName!=='class') return;
      var page=r.target;
      if(page.id!=='categoryPage' || !page.classList.contains('open')) return;
      if(closingFromPop) return;
      if(!(history.state && history.state.mithCategoryPage)){
        try{history.pushState({mithCategoryPage:true,filter:currentCategory()},'',location.pathname+location.search+'#products');}catch(e){}
      }
    });
  });
  function startCategoryObserver(){
    var p=document.getElementById('categoryPage');
    if(p) observer.observe(p,{attributes:true});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',startCategoryObserver,{once:true}); else startCategoryObserver();

  /* Product detail gets one history step above the Product Range/category page. */
  var originalOpen=window.openProductDetail;
  if(originalOpen){
    window.openProductDetail=function(id){
      var already=detailIsOpen();
      originalOpen(id);
      if(!already && detailIsOpen() && !closingFromPop){
        if(!(history.state && history.state.mithProductDetail)){
          try{history.pushState({mithProductDetail:true,productId:id},'',location.pathname+location.search+'#product');}catch(e){}
        }
      }
    };
  }

  var originalClose=window.closeProductDetail;
  window.closeProductDetail=function(){
    if(originalClose) originalClose();
    else {var m=document.getElementById('productDetailModal');if(m)m.classList.remove('open');}
    if(!closingFromPop && history.state && history.state.mithProductDetail){
      try{history.back();}catch(e){}
    }
  };

  /* Android/browser Back: product -> Product Range, category -> main page. */
  window.addEventListener('popstate',function(e){
    closingFromPop=true;
    try{
      if(detailIsOpen() && !(e.state && e.state.mithProductDetail)){
        if(originalClose) originalClose(); else {var m=document.getElementById('productDetailModal');if(m)m.classList.remove('open');}
        return;
      }
      if(categoryIsOpen() && !(e.state && e.state.mithCategoryPage)){
        var page=document.getElementById('categoryPage');
        if(page) page.classList.remove('open');
        document.body.style.overflow='';
        return;
      }
    }finally{setTimeout(function(){closingFromPop=false;},0);}
  },true);

  /* Close-cart X: bind directly + capture pointer/click, after every older handler. */
  function hardCloseCart(){
    var c=document.getElementById('cart'),o=document.getElementById('overlay');
    if(c)c.classList.remove('open');
    if(o)o.classList.remove('open');
    document.body.classList.remove('cart-open');
    document.body.style.overflow='';
    document.documentElement.style.overflow='';
  }
  function bindCartX(){
    var b=document.getElementById('closeCart');
    if(!b)return;
    b.onclick=function(e){e.preventDefault();e.stopPropagation();hardCloseCart();};
    b.ontouchend=function(e){e.preventDefault();e.stopPropagation();hardCloseCart();};
    b.onpointerup=function(e){e.preventDefault();e.stopPropagation();hardCloseCart();};
  }
  function cartCapture(e){
    var b=e.target && e.target.closest ? e.target.closest('#closeCart') : null;
    if(!b)return;
    e.preventDefault();e.stopPropagation();
    if(e.stopImmediatePropagation)e.stopImmediatePropagation();
    hardCloseCart();
  }
  document.addEventListener('pointerup',cartCapture,true);
  document.addEventListener('touchend',cartCapture,true);
  document.addEventListener('click',cartCapture,true);
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',bindCartX,{once:true}); else bindCartX();
  setTimeout(bindCartX,300);
})();
