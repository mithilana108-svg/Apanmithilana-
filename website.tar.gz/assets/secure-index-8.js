
(function(){
  function moveComboLast(){
    const productsSec=document.getElementById('products');
    const combo=document.getElementById('combo');
    if(!productsSec||!combo)return;
    const parent=productsSec.parentNode;
    if(parent && combo.parentNode===parent) parent.appendChild(combo);
    else if(productsSec.parentNode && combo.parentNode!==productsSec.parentNode) productsSec.parentNode.appendChild(combo);
  }
  function showCompleteRange(){
    const grid=document.getElementById('productGrid');
    if(!grid||typeof products==='undefined')return;
    const list=products.filter(p=>p.cat!=='Combo');
    grid.innerHTML=list.map(productCard).join('')||'<div class="empty">No products found.</div>';
    list.forEach(p=>{
      const s=document.getElementById('v-'+p.id);
      if(s)s.addEventListener('change',()=>{
        const price=document.getElementById('price-'+p.id);
        if(price)price.textContent=money(p.variants[s.value].price);
      });
    });
    document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x.dataset.filter==='All'));
  }
  window.showCompleteMithilanaRange=showCompleteRange;
  moveComboLast();
  // Explore / collection image => Complete Product Range.
  const ex=document.getElementById('exploreProductsBtn');
  if(ex)ex.onclick=function(e){e.preventDefault();showCompleteRange();document.getElementById('products')?.scrollIntoView({behavior:'smooth',block:'start'});};
  const collection=document.querySelector('.single-collection');
  if(collection){
    collection.onclick=function(e){
      e.preventDefault();showCompleteRange();document.getElementById('products')?.scrollIntoView({behavior:'smooth',block:'start'});
    };
  }
  // HOME/CATEGORIES stay normal; COMBO goes to the final Combo section.
  document.querySelectorAll('.nav a').forEach(a=>{
    if((a.getAttribute('href')||'')==='#combo'){
      a.onclick=function(e){e.preventDefault();moveComboLast();document.getElementById('combo')?.scrollIntoView({behavior:'smooth',block:'start'});};
    }
  });
  // Ensure complete range is rendered after all earlier patches have finished.
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',showCompleteRange,{once:true});
  else showCompleteRange();
})();
