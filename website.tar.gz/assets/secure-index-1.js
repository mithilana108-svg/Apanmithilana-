function htmlEscape(value){return String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function safeImageUrl(value){try{const u=new URL(String(value||''),location.href);return ['https:','http:','blob:'].includes(u.protocol)||String(value).startsWith('data:image/')?String(value):''}catch{return ''}}
document.addEventListener('click',function(event){
 const el=event.target.closest('[data-mith-action]');if(!el)return;
 const action=el.dataset.mithAction;event.stopPropagation();
 if(action==='detail')openProductDetail(el.dataset.mithId);
 else if(action==='add')addProduct(el.dataset.mithId);
 else if(action==='close-cart')closeCart();
 else if(action==='quantity')changeQty(Number(el.dataset.mithIndex),Number(el.dataset.mithDelta));
 else if(action==='remove')removeItem(Number(el.dataset.mithIndex));
});
// Public website configuration. Do NOT put Meta access tokens or other secrets here.
window.MITHILANA_CONFIG = {
  WHATSAPP_NUMBER: "919220866696"
};
