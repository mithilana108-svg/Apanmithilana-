/* Original uploaded product photographs; no image pixels altered. */
(function(){
const gallery={"jaggery-biscuits":["/assets/product-images/jaggery-biscuits-front.jpg","/assets/product-images/jaggery-biscuits-ingredients.jpg","/assets/product-images/jaggery-biscuits-back.jpg"],"peri":["/assets/product-images/peri-front.jpg","/assets/product-images/peri-ingredients.jpg","/assets/product-images/peri-back.jpg"],"chocolate":["/assets/product-images/chocolate-front.jpg","/assets/product-images/chocolate-ingredients.jpg","/assets/product-images/chocolate-back.jpg"],"pudina-mint":["/assets/product-images/pudina-mint-front.jpg","/assets/product-images/pudina-mint-ingredients.jpg","/assets/product-images/pudina-mint-back.jpg"],"pink-salt":["/assets/product-images/pink-salt-front.jpg","/assets/product-images/pink-salt-ingredients.jpg","/assets/product-images/pink-salt-back.jpg"],"tangy-tomato":["/assets/product-images/tangy-tomato-front.jpg","/assets/product-images/tangy-tomato-ingredients.jpg","/assets/product-images/tangy-tomato-back.jpg"],"murauri":["/assets/product-images/murauri-front.jpg","/assets/product-images/murauri-ingredients.jpg"],"adhori":["/assets/product-images/adhori-front.jpg","/assets/product-images/adhori-ingredients.jpg"],"kumrauri":["/assets/product-images/kumrauri-front.jpg","/assets/product-images/kumrauri-ingredients.jpg"]};
window.MITH_ORIGINAL_PHOTOS=gallery;
window.mithApplyOriginalPhotos=function(){
 for(const p of window.products||[]){
  const imgs=gallery[p.id]; if(!imgs)return;
  p.img=imgs[0];p.catalogDefaultImage=imgs[0];p.originalPhotoGallery=imgs;
  for(const v of p.variants||[])v.originalPhoto=imgs[0];
 }
};
window.mithApplyOriginalPhotos();
})();
