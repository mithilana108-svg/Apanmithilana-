
// Mithilana interaction fixes: range taps always open the product list.
function showCategory(filter){
  document.querySelectorAll(".filter").forEach(x=>{
    x.classList.toggle("active",x.dataset.filter===filter);
  });
  renderProducts(filter);
  const target=document.getElementById("products");
  if(target) target.scrollIntoView({behavior:"smooth",block:"start"});
}
document.addEventListener("DOMContentLoaded",()=>{
  // Make the main collection image itself a gateway to all products, not to the heritage section.
  const collection=document.querySelector(".single-collection");
  if(collection){
    collection.setAttribute("role","button");
    collection.setAttribute("tabindex","0");
    collection.addEventListener("click",()=>showCategory("All"));
    collection.addEventListener("keydown",e=>{
      if(e.key==="Enter"||e.key===" "){e.preventDefault();showCategory("All");}
    });
  }
  // Ensure every category card has a direct range action.
  document.querySelectorAll(".cat-card").forEach(card=>{
    card.addEventListener("click",e=>{
      e.preventDefault(); e.stopPropagation();
      showCategory(card.dataset.filter||"All");
    });
  });
});
