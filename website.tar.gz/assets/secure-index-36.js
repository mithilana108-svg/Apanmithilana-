
(()=>{
 const button=document.getElementById('mithStickyCart'),count=document.getElementById('cartCount'),stage=document.getElementById('mithCartAnimation');
 const getCart=()=>{if(Array.isArray(window.cart))return window.cart;try{return JSON.parse(localStorage.getItem('mithilana_cart')||'[]')}catch(e){return []}};
 function update(){
  const items=getCart(),computed=items.reduce((n,x)=>n+(Number(x.qty)||0),0),quantity=Math.max(computed,Number(count?.textContent)||0);
  const total=items.reduce((n,x)=>n+(Number(x.price)||0)*(Number(x.qty)||0),0);
  const route=document.getElementById('mithRouteOverlay'),body=document.getElementById('mithRouteBody');
  const shopping=!route?.classList.contains('open')||!body?.querySelector('#about-my-company');
  const blocking=['#cart','#checkoutModal','#loginModal','#mithilanaAccount','#whatsappSupportModal','#mithFeaturePage','#mithSearchPage','#languageChoice','#mithOrderSuccess','#orderReceipt'].some(id=>document.querySelector(id)?.classList.contains('open'));
  button.hidden=!(quantity>0&&shopping&&!blocking);
  document.getElementById('mithStickyCartLabel').textContent=(localStorage.getItem('mithilana_language')==='hi'?'कार्ट देखें':'View Cart')+' · '+quantity;
  document.getElementById('mithStickyCartTotal').textContent=total?'₹'+total.toLocaleString('en-IN'):'';
 }
 button.addEventListener('click',()=>{window.openCart?.();update()});
 const observer=new MutationObserver(()=>requestAnimationFrame(update));
 if(count)observer.observe(count,{childList:true,characterData:true,subtree:true});
 ['mithRouteOverlay','cart','checkoutModal','loginModal','mithilanaAccount','whatsappSupportModal','mithFeaturePage','productDetailModal','mithSearchPage','languageChoice','mithOrderSuccess','orderReceipt'].forEach(id=>{const el=document.getElementById(id);if(el)observer.observe(el,{attributes:true,attributeFilter:['class']})});
 const body=document.getElementById('mithRouteBody');if(body)observer.observe(body,{childList:true});
 window.addEventListener('popstate',update);window.addEventListener('storage',update);
 document.addEventListener('click',()=>requestAnimationFrame(update));
 window.mithUpdateStickyCart=update;
 const palette={peri:['#f5ad8e','#ce6042'],tandoori:['#f9bd79','#d97837'],'pudina-mint':['#d2edbc','#8dba70'],chocolate:['#c79676','#72462f'],classic:['#fff1bc','#d7b875'],plain:['#f4e6c4','#cfb895'],'tangy-tomato':['#f6ad89','#cc6548'],jaggery:['#edcb95','#b88954']};
 let soundContext;
 function sound(){
  try{
   const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;
   soundContext=soundContext||new Audio();if(soundContext.state==='suspended')soundContext.resume();
   const t=soundContext.currentTime,osc=soundContext.createOscillator(),gain=soundContext.createGain();
   osc.type='sine';osc.frequency.setValueAtTime(520,t);osc.frequency.exponentialRampToValueAtTime(750,t+.10);
   gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(.035,t+.018);gain.gain.exponentialRampToValueAtTime(.0001,t+.17);
   osc.connect(gain);gain.connect(soundContext.destination);osc.start(t);osc.stop(t+.18);
  }catch(e){}
 }
 function kindOf(p){
  const id=String(p.id||''),cat=String(p.cat||'').toLowerCase(),name=String(p.name||'').toLowerCase();
  if(cat.includes('accessor'))return 'accessory';
  if(id==='adho-kum')return 'mixed';
  if(cat.includes('adhori')||name.includes('adhori'))return 'adhori';
  if(cat.includes('kumrauri')||name.includes('kumrauri'))return 'kumrauri';
  if(id==='almonds'||name.includes('almond')||name.includes('badam'))return 'almond';
  if(id==='cashews'||name.includes('cashew')||name.includes('kaju'))return 'cashew';
  if(id==='raisins'||name.includes('raisin')||name.includes('kishmish'))return 'raisin';
  if(cat.includes('dry fruit'))return 'almond';
  if(name.includes('makhana')||cat.includes('makhana')||id==='flav-combo')return 'makhana';
  return 'product';
 }
 function settle(target){setTimeout(()=>{if(target?.isConnected&&target.animate)target.animate([{transform:'scale(1)'},{transform:'scale(1.09)'},{transform:'scale(1)'}],{duration:260,easing:'ease-out'})},1150)}
 function animate(product,source){
  if(!product)return;
  sound(); // Called synchronously by the Add button's user gesture.
  if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  requestAnimationFrame(()=>{
   update();
   const target=button.hidden?document.getElementById('cartBtn'):button;
   if(!target)return;
   const dest=target.getBoundingClientRect(),endX=dest.left+dest.width/2,endY=dest.top+dest.height/2;
   const type=kindOf(product),accessory=type==='accessory'||type==='product';
   const colors=palette[product.id]||['#f4e6c8','#cdb58a'];
   const count=accessory?3:11;
   for(let i=0;i<count;i++){
    const item=document.createElement(accessory?'img':'i');
    if(accessory){item.className='mith-fly-image';item.src=product.img;item.alt='';item.style.width=(i===0?76:52)+'px';item.style.height=(i===0?76:52)+'px'}
    else{
     const piece=type==='mixed'?(i%2?'adhori':'kumrauri'):type;
     item.className='mith-grain'+(piece==='makhana'?'':' mith-grain--'+piece);
     if(piece==='makhana')item.style.background=`radial-gradient(circle at 28% 24%,#fffef4,${colors[0]} 38%,${colors[1]} 88%)`;
    }
    stage.append(item);
    const x=innerWidth*(.10+.78*((i*7%count)/(count-1))),y=accessory?-85-i*20:-35-i*9;
    const dx=endX-x,dy=endY-y,drift=(i%2?-1:1)*(20+i*3);
    item.style.left=x+'px';item.style.top=y+'px';
    const duration=accessory?1550+i*75:1450+i*38,delay=i*(accessory?95:46);
    const motion=item.animate([
     {transform:'translate3d(0,0,0) rotateY(0deg) rotateZ(-15deg) scale(.72)',opacity:0},
     {transform:`translate3d(${dx*.14+drift}px,${dy*.58}px,0) rotateY(${accessory?14:110}deg) rotateZ(${i*34}deg) scale(${accessory?1.14:1.28})`,opacity:1,offset:.55},
     {transform:`translate3d(${dx*.73}px,${dy*.79}px,0) rotateY(${accessory?28:225}deg) rotateZ(${i*50}deg) scale(.8)`,opacity:1,offset:.78},
     {transform:`translate3d(${dx}px,${dy}px,0) rotateY(360deg) rotateZ(${i*72}deg) scale(.22)`,opacity:0}
    ],{duration,delay,easing:'cubic-bezier(.20,.47,.33,1)',fill:'forwards'});
    motion.finished.then(()=>item.remove(),()=>item.remove());
   }
   settle(target);
  });
 }
 window.mithAnimateCart=animate;
 update();
})();
