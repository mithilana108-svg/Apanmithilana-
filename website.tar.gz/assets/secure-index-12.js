
(function(){
  'use strict';
  var PRODUCT='mithProductPage';
  var CATEGORY='mithCategoryPage';
  var ROOT='mithBasePage';
  var internalPop=false;

  function copyState(){
    return (history.state && typeof history.state==='object') ? Object.assign({},history.state) : {};
  }
  function productOpen(){
    var m=document.getElementById('productDetailModal');
    return !!(m && m.classList.contains('open'));
  }
  function categoryOpen(){
    var p=document.getElementById('categoryPage');
    return !!(p && p.classList.contains('open'));
  }
  function setRoot(){
    try{
      var s=copyState();
      delete s[PRODUCT]; delete s[CATEGORY];
      s[ROOT]=true;
      history.replaceState(s,'',location.href);
    }catch(e){}
  }
  setRoot();

  function pushProduct(id){
    var s=copyState();
    delete s[CATEGORY];
    s[PRODUCT]=true;
    s.productId=id||null;
    history.pushState(s,'',location.href);
  }
  function pushCategory(filter){
    var s=copyState();
    s[CATEGORY]=filter||'All';
    delete s[PRODUCT];
    history.pushState(s,'',location.href);
  }

  // There is exactly one history entry for the foreground product page.
  var openProduct=window.openProductDetail;
  if(openProduct && !window.__mithV33ProductOpen){
    window.openProductDetail=function(id){
      if(!productOpen() && !(history.state && history.state[PRODUCT])) pushProduct(id);
      return openProduct.apply(this,arguments);
    };
    window.__mithV33ProductOpen=true;
  }

  // Category pages also get one entry, so Android Back returns to the page underneath.
  var showCategory=window.showCategory;
  if(showCategory && !window.__mithV33CategoryOpen){
    window.showCategory=function(filter){
      if(!categoryOpen() && !(history.state && history.state[CATEGORY])) pushCategory(filter);
      return showCategory.apply(this,arguments);
    };
    window.__mithV33CategoryOpen=true;
  }

  function closeProductVisual(){
    internalPop=true;
    try{
      var m=document.getElementById('productDetailModal');
      if(typeof window.__mithV33BaseClose==='function') window.__mithV33BaseClose();
      else if(typeof window.closeProductDetail==='function') window.closeProductDetail();
      if(m)m.classList.remove('open');
      document.documentElement.classList.remove('mith-product-open');
      document.body.classList.remove('mith-product-open');
      document.body.style.top='';
      var y=Number(document.body.dataset.mithSavedScroll||0);
      window.scrollTo(0,y);
    }finally{internalPop=false;}
  }

  // Preserve the underlying close function; X should go back one history step, not quit the page.
  var baseClose=window.closeProductDetail;
  if(baseClose && !window.__mithV33CloseWrapped){
    window.__mithV33BaseClose=baseClose;
    window.closeProductDetail=function(){
      if(!internalPop && history.state && history.state[PRODUCT]){
        history.back();
        return;
      }
      return baseClose.apply(this,arguments);
    };
    window.__mithV33CloseWrapped=true;
  }

  function closeCategoryVisual(){
    var p=document.getElementById('categoryPage');
    if(p){p.classList.remove('open');p.setAttribute('aria-hidden','true');}
    document.body.style.overflow='';
  }

  // Product/category foreground Back buttons use the same browser history as Android Back.
  document.addEventListener('click',function(e){
    var b=e.target.closest && e.target.closest('#detailClose');
    if(b && productOpen()){
      e.preventDefault(); e.stopImmediatePropagation();
      if(history.state && history.state[PRODUCT]) history.back();
    }
  },true);
  document.addEventListener('click',function(e){
    var b=e.target.closest && e.target.closest('#categoryPage .category-back');
    if(b && categoryOpen()){
      e.preventDefault(); e.stopImmediatePropagation();
      if(history.state && history.state[CATEGORY]) history.back();
      else closeCategoryVisual();
    }
  },true);

  window.addEventListener('popstate',function(e){
    var s=e.state||{};
    // Returning from Product -> its underlying page: close only the foreground product.
    if(productOpen() && !s[PRODUCT]){
      closeProductVisual();
      return;
    }
    // Returning from Category -> the underlying home page: close only the category.
    if(categoryOpen() && !s[CATEGORY]){
      closeCategoryVisual();
      return;
    }
  },true);
})();
