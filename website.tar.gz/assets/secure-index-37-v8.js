/* Har category (Phool Makhana, Flavoured Makhana, Dry Fruits, Adhori, Kumrauri, Combo, Accessories)
   landscape layout mein khulti hai: har product ka alag card, har quantity ki alag image.
   -----------------------------------------------------------------------------------------
   IMAGES BAAD MEIN YAHAN DAALEIN: har size ke aage image ka path likh dein.
   Example:  "50 g": "/assets/premium-50g.webp"   (image ko assets folder mein rakhein)
   Ya bina is file ko chhue: image ko assets/product-images/ folder mein is naam se rakh dein: <id>-<size>.webp
   (jaise premium-raw-50g.webp). Poori naam-suchi IMAGE-NAMES.txt mein hai. Image daalne ke baad site redeploy karein.
   Jab tak image nahi daalte, us product ki abhi wali image dikhegi (image mein koi badlav nahi hota).                              */
window.MITH_VARIANT_IMAGES = {
  "classic": { "100 g": "", "200 g": "" }, // Flavoured Makhana | Classic Butter Makhana
  "plain": { "100 g": "", "200 g": "" }, // Flavoured Makhana | Plain Salted Makhana
  "peri": { "100 g": "", "200 g": "" }, // Flavoured Makhana | Peri Peri Makhana
  "tandoori": { "100 g": "", "200 g": "" }, // Flavoured Makhana | Tandoori Makhana
  "raisins": { "100 g": "" }, // Dry Fruits | Golden Raisins (Kishmish)
  "almonds": { "100 g": "" }, // Dry Fruits | Golden Almonds (Badam)
  "cashews": { "100 g": "" }, // Dry Fruits | Golden Cashews (Kaju)
  "kumrauri": { "250 g": "", "500 g": "" }, // Kumrauri | Authentic Mithila Kumrauri
  "adhori": { "250 g": "", "500 g": "" }, // Adhori | Authentic Mithila Adhori
  "flav-combo": { "Combo": "" }, // Combo | Flavoured Makhana Combo
  "adho-kum": { "Combo": "" }, // Combo | Adhori + Kumrauri Combo
  "premium-raw": { "50 g": "", "100 g": "", "250 g": "" }, // Phool Makhana | Premium Raw Makhana
  "normal-raw": { "50 g": "", "100 g": "", "250 g": "" }, // Phool Makhana | 22 Carat / Normal Raw Makhana
  "tangy-tomato": { "50 g": "", "100 g": "" }, // Flavoured Makhana | Tangy Tomato Makhana
  "pudina-mint": { "50 g": "", "100 g": "" }, // Flavoured Makhana | Pudina Mint Makhana
  "chocolate": { "50 g": "", "100 g": "" }, // Flavoured Makhana | Chocolate Makhana
  "jaggery": { "50 g": "", "100 g": "" }, // Flavoured Makhana | Jaggery Makhana
  "saree": { "One size": "" }, // Accessories | Mithilana Madhubani Printed Saree
  "paag": { "One size": "" }, // Accessories | Mithilana Madhubani Printed Paag
  "dupatta": { "One size": "" }, // Accessories | Mithilana Madhubani Printed Dupatta
  "shawl": { "One size": "" }, // Accessories | Mithilana Madhubani Printed Shawl
  "gamchha": { "One size": "" }, // Accessories | Mithilana Madhubani Printed Gamchha
  "handbag": { "One size": "" }, // Accessories | Mithilana Madhubani Handbag
  "carry-bag": { "One size": "" }, // Accessories | Mithilana Madhubani Carry Bag
  "phone-cover": { "One size": "" }, // Accessories | Mithilana Madhubani Phone Cover
  "mithila-painting": { "Artwork": "" } // Accessories | Mithilana Mithila Painting (Trial)
};


/* "About product" wali window mein dikhne wala extra text (optional). Page ke upar kuch nahi dikhta. */
window.MITH_CATEGORY_INFO = {
  "Phool Makhana": {
    desc: "Premium handpicked, naturally grown makhana with superior size, crunch and nutrition. A healthy snack for your everyday lifestyle.",
    badges: ["🌿 100% Natural", "💪 Rich in Protein", "🌾 Good Source of Fiber", "❤️ Zero Cholesterol"]
  }
};

(() => {
  const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const original = window.renderProducts;
  if (typeof original !== 'function') return;

  // ---- Back-button support for the image viewer and About window ----
  // Opening one adds a history entry; Back (or closing with ✕) removes it, and the category page stays open behind.
  let activeClose = null, pushed = false, swallow = false;
  function openViewer(closeDom) {
    if (activeClose) { activeClose(); activeClose = closeDom; return; }
    activeClose = closeDom;
    try { history.pushState({ pmViewer: true }, '', location.href); pushed = true; } catch (e) { pushed = false; }
  }
  function closeViewer() {
    if (!activeClose) return;
    const f = activeClose; activeClose = null; f();
    if (pushed) { pushed = false; swallow = true; history.back(); }
  }
  // Called first by assets/secure-index-37-guard.js on every Back press; returning true stops all other Back handlers.
  window.__pmBack = () => {
    if (swallow) { swallow = false; return true; }
    if (activeClose) { const f = activeClose; activeClose = null; pushed = false; f(); return true; }
    return false;
  };

  // Image order: 1) path written in MITH_VARIANT_IMAGES above, 2) file in /assets/product-images/<id>-<size>.<ext>
  // (e.g. premium-raw-50g.webp; the server lists which files exist, so nothing missing is ever requested),
  // 3) the product's current image (shown instantly).
  const sizeKey = l => String(l).toLowerCase().replace(/[^a-z0-9]+/g, '');
  let found = {}; // filename -> version
  const pick = (p, label) => {
    const originalGallery = window.MITH_ORIGINAL_PHOTOS && window.MITH_ORIGINAL_PHOTOS[p.id];
    if (originalGallery && originalGallery[0]) return originalGallery[0];
    const variant=p.variants.find(v=>v.label===label);
    if(variant?.originalPhoto)return variant.originalPhoto;
    if(variant?.liveImage)return variant.liveImage;
    const set = (window.MITH_VARIANT_IMAGES[p.id] || {})[label] || '';
    if (set) return set;
    const stem = `${p.id}-${sizeKey(label)}`;
    for (const ext of ['webp', 'png', 'jpg', 'jpeg', 'avif']) {
      const f = `${stem}.${ext}`;
      if (found[f]) return `/assets/product-images/${f}?v=${found[f]}`;
    }
    return (p.catalogDefaultImage || p.img) || '';
  };
  function imgBox(p, label) {
    const src = pick(p, label);
    return src
      ? `<img src="${esc(src)}" data-pid="${esc(p.id)}" data-label="${esc(label)}" alt="${esc(p.name)} ${esc(label)}" decoding="async">`
      : `<div class="pm-ph"><b>${esc(label)}</b><span>Image coming soon</span></div>`;
  }
  // Ask the server once which size images exist, then upgrade any card still showing the default image.
  if (location.protocol !== 'file:') {
    fetch('/api/product-images').then(r => r.ok ? r.json() : { files: {} }).then(d => {
      found = d.files || {};
      document.querySelectorAll('.pm-img img[data-pid]').forEach(img => {
        const p = window.products.find(x => x.id === img.dataset.pid); if (!p) return;
        const src = pick(p, img.dataset.label);
        if (src && img.getAttribute('src') !== src) img.src = src;
      });
    }).catch(() => {});
  }

  function render(filter) {
    const list = window.products.filter(p => p.cat === filter);
    const grid = document.getElementById('productGrid');
    if (!list.length) { grid.innerHTML = '<div class="empty">No products found in this category.</div>'; return; }
    const multi = true; // har product apni poori screen par (badi image)
    grid.innerHTML = `<div class="pm-page"><div class="pm-wrap${multi ? ' pm-multi' : ''}">` + list.map((p, n) => `
      <section class="pm-card" data-pm-id="${esc(p.id)}">
        <h3><span class="pm-name">${esc(p.name)}</span><span class="pm-h3r">${multi ? `<small>${n + 1} / ${list.length}</small>` : ''}<button type="button" class="pm-about">ℹ️ About</button></span></h3>
        <div class="pm-row${p.variants.length === 1 ? ' pm-one' : ''}" style="--cols:${Math.min(p.variants.length, 3)}">${p.variants.map((v, i) => `
          <div class="pm-vcard" data-i="${i}">
            <div class="pm-img">${imgBox(p, v.label)}</div>
            <div class="pm-size">${esc(v.label)}</div>
            <div class="pm-price">${money(v.price)}</div>
            <button type="button" class="pm-add">🛒 Add to Cart</button>
          </div>`).join('')}
        </div>
        <select id="v-${esc(p.id)}" hidden>${p.variants.map((v, i) => `<option value="${i}">${esc(v.label)}</option>`).join('')}</select>
      </section>`).join('') + `</div></div>`;
  }

  window.renderProducts = function (filter = 'All') {
    const sec = document.getElementById('products');
    if (filter !== 'All') { sec?.classList.add('pm-mode'); render(filter); }
    else { sec?.classList.remove('pm-mode'); original.apply(this, arguments); }
  };

  document.addEventListener('click', e => {
    const btn = e.target.closest('.pm-add'); if (!btn) return;
    const card = btn.closest('.pm-card'), v = btn.closest('.pm-vcard');
    const p = window.products.find(x => x.id === card.dataset.pmId); if (!p) return;
    card.querySelector('select').value = v.dataset.i;
    addProduct(p.id);
  });

  // ---- Image click -> full-screen viewer with zoom in / zoom out (buttons, pinch, wheel, double-tap) ----
  function openLightbox(src, alt, gallery) {
    document.getElementById('pmLightbox')?.remove();
    const box = document.createElement('div'); box.id = 'pmLightbox';
    box.innerHTML = `<div class="pm-lb-bar"><span>${esc(alt || '')}</span><button type="button" data-z="out" aria-label="Zoom out">−</button><button type="button" data-z="in" aria-label="Zoom in">+</button><button type="button" data-z="close" aria-label="Close">✕</button></div><div class="pm-lb-stage"><img alt="${esc(alt || '')}" draggable="false"></div>`;
    document.body.appendChild(box);
    const stage = box.querySelector('.pm-lb-stage'), img = box.querySelector('img');
    img.src = src;
    if (gallery && gallery.length > 1) {
      const tray=document.createElement('div');tray.className='mith-photo-tray';
      tray.style.cssText='position:absolute;bottom:10px;left:50%;transform:translateX(-50%);display:flex;gap:8px;z-index:10;background:#ffffffee;padding:7px;border-radius:9px;max-width:96vw;overflow-x:auto';
      gallery.forEach((url,i)=>{const thumb=document.createElement('img');thumb.src=url;thumb.alt=['Front','Ingredients','Back'][i]||'Photo';thumb.title=thumb.alt;thumb.style.cssText='height:60px;width:48px;object-fit:contain;cursor:pointer;border:2px solid #8b2c22;border-radius:4px';thumb.addEventListener('click',()=>{img.src=url;scale=1;tx=0;ty=0;apply();});tray.appendChild(thumb)});
      box.appendChild(tray);
    }
    let scale = 1, tx = 0, ty = 0; const ptr = new Map(); let d0 = 0, s0 = 1, moved = 0;
    const clamp = v => Math.min(5, Math.max(1, v));
    const apply = () => { if (scale <= 1) { tx = 0; ty = 0; } img.style.transform = `translate(${tx}px,${ty}px) scale(${scale})`; };
    const closeDom = () => { box.remove(); document.removeEventListener('keydown', onKey); };
    const close = closeViewer;
    const onKey = e => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);
    openViewer(closeDom);
    box.querySelector('.pm-lb-bar').addEventListener('click', e => {
      const z = e.target.closest('[data-z]')?.dataset.z; if (!z) return;
      if (z === 'close') close(); else { scale = clamp(scale + (z === 'in' ? 0.5 : -0.5)); apply(); }
    });
    stage.addEventListener('pointerdown', e => { stage.setPointerCapture(e.pointerId); ptr.set(e.pointerId, { x: e.clientX, y: e.clientY }); moved = 0;
      if (ptr.size === 2) { const [a, b] = [...ptr.values()]; d0 = Math.hypot(a.x - b.x, a.y - b.y); s0 = scale; } });
    stage.addEventListener('pointermove', e => { const q = ptr.get(e.pointerId); if (!q) return;
      const dx = e.clientX - q.x, dy = e.clientY - q.y; moved += Math.abs(dx) + Math.abs(dy);
      q.x = e.clientX; q.y = e.clientY;
      if (ptr.size === 2) { const [a, b] = [...ptr.values()]; scale = clamp(s0 * Math.hypot(a.x - b.x, a.y - b.y) / d0); apply(); }
      else if (scale > 1) { tx += dx; ty += dy; apply(); } });
    const up = e => { ptr.delete(e.pointerId); if (ptr.size === 0 && moved < 6 && e.target === stage) close(); };
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', e => ptr.delete(e.pointerId));
    stage.addEventListener('dblclick', () => { scale = scale > 1 ? 1 : 2.5; apply(); });
    stage.addEventListener('wheel', e => { e.preventDefault(); scale = clamp(scale + (e.deltaY < 0 ? 0.25 : -0.25)); apply(); }, { passive: false });
  }
  document.addEventListener('click', e => {
    const img = e.target.closest('.pm-img img'); if (!img) return;
    const p=window.products.find(x=>x.id===img.dataset.pid);
    openLightbox(img.currentSrc || img.src, img.alt, (window.MITH_ORIGINAL_PHOTOS && window.MITH_ORIGINAL_PHOTOS[p?.id]) || p?.originalPhotoGallery);
  });

  // ---- "About product" window: description + (optional) category info ----
  document.addEventListener('click', e => {
    const b = e.target.closest('.pm-about'); if (!b) return;
    const p = window.products.find(x => x.id === b.closest('.pm-card').dataset.pmId); if (!p) return;
    const info = (window.MITH_CATEGORY_INFO || {})[p.cat] || {};
    document.getElementById('pmAbout')?.remove();
    const m = document.createElement('div'); m.id = 'pmAbout';
    m.innerHTML = `<div class="pm-ab-card"><button type="button" class="pm-ab-x" aria-label="Close">✕</button><h4>${esc(p.name)}</h4><p>${esc(p.desc || '')}</p>${info.desc ? `<p>${esc(info.desc)}</p>` : ''}${(info.badges || []).length ? `<div class="pm-badges">${info.badges.map(x => `<span>${esc(x)}</span>`).join('')}</div>` : ''}</div>`;
    m.addEventListener('click', ev => { if (ev.target === m || ev.target.closest('.pm-ab-x')) closeViewer(); });
    document.body.appendChild(m);
    openViewer(() => m.remove());
  });
})();
