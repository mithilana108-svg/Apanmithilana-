(()=>{
 const modal=document.getElementById('loginModal');if(!modal)return;
 const ids=['loginMsg','loginStatus','mithGoogleStatus'];
 const clear=()=>ids.forEach(id=>{const el=document.getElementById(id);if(el)el.textContent='';});
 const hasSession=()=>{try{return Boolean(localStorage.getItem('mithilana_token'))}catch{return false}};
 let wasOpen=modal.classList.contains('open');
 function onOpen(){if(!hasSession())clear();}
 // Login panel opening should never reuse a previous success message.
 const observer=new MutationObserver(()=>{const isOpen=modal.classList.contains('open');if(isOpen&&!wasOpen)onOpen();wasOpen=isOpen;});
 observer.observe(modal,{attributes:true,attributeFilter:['class']});
 document.getElementById('loginBtn')?.addEventListener('click',()=>{if(!hasSession())clear()},true);
 document.getElementById('logoutBtn')?.addEventListener('click',()=>{clear();queueMicrotask(clear);setTimeout(clear,50)},true);
 window.addEventListener('mithilana:logout',()=>{clear();queueMicrotask(clear);setTimeout(clear,50)});
 window.addEventListener('pageshow',()=>{if(modal.classList.contains('open')&&!hasSession())clear()});
 if(wasOpen&&!hasSession())clear();
})();
