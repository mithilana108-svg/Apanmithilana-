# Mithilana — Full website project

यह ZIP पूरी वेबसाइट के कोड का पैकेज है। `index.html` फ्रंटएंड है; `server.js`, `schema.sql`, `catalog-draft.sql` और `admin.html` बैकएंड, डेटाबेस और एडमिन के हिस्से हैं। फोन पर HTML सीधे खोलना केवल प्रीव्यू है।

## सेटअप

1. Node.js 20+, PostgreSQL और `npm ci` चाहिए। Render पर `render.yaml` परीक्षण Web Service और अलग PostgreSQL बनाएगा। उत्पादन के लिए `render-live.yaml` दूसरा अलग प्रोजेक्ट है। दोनों को एक ही डेटाबेस से न जोड़ें।
2. `npm start` अब schema, migration और 43 draft product packs खुद शुरू करता है; प्रत्येक दोबारा चलने पर पुराने उत्पाद/दाम नहीं बदलता। सभी नए पैक **inactive, zero stock** से शुरू होते हैं। सही MRP और स्टॉक जाँचकर एडमिन में सक्रिय करें।
3. `.env.example` के नामों वाली environment variables सेट करें। `DATABASE_URL`, अलग `JWT_SECRET` और `ADMIN_JWT_SECRET` आवश्यक हैं। Render पर `PUBLIC_ORIGIN` उसके hostname से तय होता है; custom domain पर इसे खुद सही HTTPS origin से सेट करें। `NODE_ENV=production` रखें। Secret values ZIP में नहीं हैं।
4. `ADMIN_BOOTSTRAP_EMAIL` और कम से कम 12 अक्षर वाला `ADMIN_BOOTSTRAP_PASSWORD` देकर पहला एडमिन स्वतः बनाया जा सकता है; बन जाने के बाद password वाला variable हटा दें। या `node scripts/create-admin.js EMAIL PASSWORD` चलाएँ। साइट `/`, एडमिन `/admin.html`, health `/api/health`।

## WhatsApp (केवल ऑर्डर अपडेट)

लॉगिन अब **सिर्फ Google** से होता है; WhatsApp OTP हटा दिया गया है। WhatsApp केवल ऑर्डर स्टेटस संदेशों के लिए है: `META_ACCESS_TOKEN`, `META_PHONE_NUMBER_ID`, `WHATSAPP_ORDER_STATUS_TEMPLATE`, webhook के लिए `/webhook`, `WHATSAPP_VERIFY_TOKEN` और `META_APP_SECRET` सेट करें। इनके बिना भी साइट चलती है (संदेश नहीं जाएँगे)।

## Google login (एकमात्र लॉगिन)

`GOOGLE_CLIENT_ID` के बिना कोई ग्राहक लॉगिन या ऑर्डर नहीं कर पाएगा, इसलिए इसे सबसे पहले सेट करें।

Google Cloud में Web OAuth client बनाकर लाइव डोमेन को Authorized JavaScript origins में रखें। `GOOGLE_CLIENT_ID` सेट करें। Google Identity Services बटन तभी दिखेगा; सर्वर Google signed ID token के issuer, audience, expiry और signature जाँचता है। Google account को फोन account से सिर्फ ईमेल मिलने पर स्वतः merge नहीं किया जाता। Google users को डिलीवरी के लिए checkout में अपना मोबाइल नंबर देना होगा।

## Razorpay

Razorpay के **test** keys से शुरू करें: `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` सेट करें। Razorpay Dashboard में webhook URL `https://YOUR-DOMAIN/api/payments/razorpay/webhook` तथा `payment.captured` event चुनें। तीनों values मौजूद हों तभी ऑनलाइन विकल्प दिखता है। ऑर्डर रकम सर्वर निकालता है; server Razorpay order बनाता है; भुगतान signature और Razorpay API से `captured` सत्यापित होने के बाद ही ऑर्डर paid बनता है। Payment बंद/असफल हो तो cart साफ़ नहीं किया जाता और order pending रहता है। Pending order को एडमिन में देखकर संभालें; payment अटकने पर Razorpay Dashboard से मिलान ज़रूरी है। Live keys लगाने से पहले test payment, webhook, cancel, duplicate callback और refund के मामलों को जाँचें।

## सीमाएँ

Meta, Google, Razorpay credentials और live PostgreSQL इस पैकेज में नहीं हैं। इन सेवाओं के साथ end-to-end run/test अभी नहीं हुआ है। Online payment का refund और pending order के automatic expiry/reconciliation का workflow अभी नहीं है; इसे production लॉन्च से पहले पूरा करें। लाइव ZIP में इमेज `/assets` में अलग रखी हैं, इसलिए `index.html` हल्का है। साथ दिया अलग HTML ऑफलाइन प्रीव्यू के लिए अपनी इमेज खुद रखता है और बड़ा है।

## टेस्ट से लाइव — क्रम

1. ZIP का पूरा `Ready to Go Website` फ़ोल्डर GitHub repository की root में रखें। Render Blueprint में `render.yaml` से test Web Service + test PostgreSQL बनाएँ। Free Render instance केवल परीक्षण के लिए है; उसकी सीमाएँ Render पर जाँचें।
2. टेस्ट साइट के URL को Google Authorized JavaScript origins में और Meta/Razorpay webhook URLs को उनके Dashboard में दर्ज करें। Render Environment में Meta credentials, Google client ID, Razorpay **test** key ID/secret और test webhook secret डालें। `APP_MODE=test` पर ऊपर साफ़ test banner दिखेगा।
3. `/api/health` देखें; `database:true`, संबंधित integrations `true` और `activeProducts` की गिनती जाँचें। एडमिन में कीमत/स्टॉक जाँचकर परीक्षण प्रोडक्ट active करें। OTP, Google login, COD, कूपन, Razorpay test success/failure और Razorpay webhook परीक्षण करें।
4. लाइव के लिए अलग `render-live.yaml` Blueprint path से **अलग सर्वर और अलग डेटाबेस** बनाएँ। वह paid plans दिखाता है; अपनी लागत स्वीकार करने के बाद ही बनाएँ। Live domain को Google/Meta/Razorpay Dashboard में जोड़ें और उनके live credentials दें। `LIVE_ORDERS_ENABLED=true` केवल परीक्षण के बाद दें; live service उससे पहले start नहीं होगा। नया डेटाबेस फिर से draft inactive catalog बनाएगा—वास्तविक MRP/स्टॉक और एडमिन सेटअप दोहराना पड़ेगा।
5. Razorpay test और live keys अलग होते हैं। `APP_MODE` के विपरीत key prefix पर सर्वर चालू नहीं होगा। Test site और उसके नकली orders को live database में न ले जाएँ। Live webhook, live payment capture, failed payment और सहायता/रिफंड की प्रक्रिया जाँचे बिना ग्राहकों को लिंक न भेजें।

सिर्फ API key बदलना पर्याप्त नहीं है: बाहरी सेवा में domain/webhook अनुमति, डेटाबेस, एडमिन द्वारा कीमत/स्टॉक की पुष्टि और वास्तविक payment test भी आवश्यक हैं।
