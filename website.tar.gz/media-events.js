'use strict';
const clients=new Set();
function broadcast(){for(const res of clients){try{if(res.writableEnded||res.destroyed){clients.delete(res);continue}res.write('event: media-changed\ndata: {}\n\n')}catch{clients.delete(res)}}}
function register(app){app.get('/api/media-events',(req,res)=>{if(clients.size>=100)return res.status(503).end();res.setHeader('Content-Type','text/event-stream');res.setHeader('Cache-Control','no-store');res.setHeader('X-Accel-Buffering','no');res.flushHeaders();clients.add(res);res.write('retry: 3000\nevent: media-changed\ndata: {}\n\n');const ping=setInterval(()=>{if(!res.destroyed)res.write(': keepalive\n\n')},25000);ping.unref();res.on('close',()=>{clearInterval(ping);clients.delete(res)})})}
module.exports={register,broadcast};
