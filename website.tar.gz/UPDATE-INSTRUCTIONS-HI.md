## नई एडमिन स्क्रीन — लैंडस्केप अपडेट

- आपकी reference image के अनुसार डार्क sidebar, dashboard metrics और charts।
- Products में फोटो वाले चौड़े कार्ड बाएँ से दाएँ; मोबाइल पर horizontal swipe।
- कार्ड पर क्लिक करके edit window खोलें; हर weight का rate, quality, visibility और stock वहीं है।
- URL slug अब भरने की जरूरत नहीं; backend पहचान अपने-आप बनाता है।
- Weight / quantity पैक का वजन है; Stock उपलब्ध पैकेटों की संख्या है।
- Add Product और Manage photos दोनों में एक बार में 4 तस्वीरें चुनें। Preview के नीचे Front, Back, Ingredients / Nutrition और Additional चुन सकते हैं। एक role दो तस्वीरों को न दें।
- फोटो बदलने पर केवल चुने roles/slots बदलेंगे; सफल अपलोड के बाद पुरानी unreferenced photo deletion queue में जाएगी।

# Mithilana — corrected website package (12 October 2026)

इस पैकेज में एडमिन, कस्टम पैक, फोटो, रेट, स्टॉक और checkout के सुधार हैं। यह अभी लाइव वेबसाइट पर लागू नहीं किया गया है।

## GitHub / Render पर लगाने का क्रम

1. GitHub में पुराने `website.tar.gz` को इसी नाम वाली अपडेटेड फ़ाइल से बदलें। बाहर की `render.yaml` भी अपडेट करें। `website.tar.gz` को GitHub में extract करके अलग-अलग फ़ाइलें डालने की जरूरत नहीं; आपकी वर्तमान deployment प्रक्रिया archive को खुद extract करती है।
2. **अपना मौजूदा Render service और DATABASE_URL ही रखें। नया database/service बनाकर पुराने orders खोने वाली प्रक्रिया न करें।** बाकी existing login secrets तथा Google Client ID को नया/खाली न करें।
3. Render → Environment में `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` के सही मौजूदा values होने चाहिए। ये secrets frontend में नहीं जाते। इनके बिना upload और provider deletion काम नहीं कर सकते। पासवर्ड/API secret चैट में भेजने की जरूरत नहीं।
4. `PUBLIC_ORIGIN=https://www.apanmithilana.com`, `APP_MODE=live`, `LIVE_ORDERS_ENABLED=true`, `CSP_MODE=enforce` रखें। DB_SSL की मौजूदा सही setting बनाए रखें; internal database connection और external connection की TLS जरूरत अलग हो सकती है।
5. उसी service पर नया deploy करें। `npm start` पहले transaction में database migration चलाता है, फिर server शुरू करता है। Migration fail होने पर नया server शुरू नहीं होगा।
6. `/api/health` में `ok:true` और `mode:live` मिलने के बाद admin खोलें: `https://www.apanmithilana.com/admin.html`। पुराने cached page को बंद करके नई बार खोलें।
7. पहले एक pack की photo/price/stock बदलकर देखें; एक अलग weight में अलग photo रखें; चुने weight का cart label और price देखें। फिर वास्तविक delivery settings के अनुसार छोटा COD checkout verify करें। कोई वास्तविक test order इस संशोधन के दौरान नहीं बनाया गया।

## एडमिन का उपयोग

- **Add Product:** नाम, अपनी category, custom weight/pack label (`75 g`, `150 g`, `1 kg`, `One size` आदि), quality, rate/MRP और opening stock भरें।
- उसी product के नीचे **Add custom weight / pack** से अतिरिक्त weights और qualities जोड़ें। फोटो और कीमत हर pack की अलग हैं।
- Stock **पैकेटों की संख्या** है। `Adjust stock` में `+10` से दस पैक बढ़ेंगे, `-3` से तीन घटेंगे। कारण लिखें; history उपलब्ध है। Price save अब stock नहीं बदलता।
- पुराने inactive weights migration में अपने-आप फिर active नहीं किए जाते। Admin में उस pack का Visible checkbox चुनकर Save करें और सही stock जोड़ें।
- Delete product/pack उसे बिक्री से हटाता है; पुराने orders और उनकी items सुरक्षित रहते हैं।
- Seller / contact / license settings में अपना सत्यापित पूरा address, email, FSSAI तथा grievance details स्वयं भरें। इनके नंबर अनुमान से नहीं बनाए गए हैं।

## नई फोटो और पुरानी फोटो का हटना

- Manage photos हमेशा **चुने गए pack** के लिए है। नई फोटो उसी slot (Front / Ingredients / Additional) की पुरानी photo rows को सचमुच DELETE करती है; केवल hidden/archived नहीं करती।
- Upload/asset verification fail होने पर पुरानी फोटो बनी रहती है। Successful upload के बाद unreferenced पुरानी Cloudinary photo delete/invalidate request के लिए queue में जाती है। सामान्यतः worker अगली 10-second cycle में कोशिश करता है; failure पर automatic retry है।
- `Check photo upload / deletion status` से missing configuration और pending/failed deletion देख सकते हैं। Pending होने को “provider से पूरी तरह delete हो गया” न समझें।
- अगर वही पुराना image asset दूसरे pack में अभी लगा है, तो उसकी वह जरूरत पूरी होने तक asset रखा जाता है; चुने pack की पुरानी association हटती है। दूसरे pack की फोटो गलती से नहीं मिटती।
- अपने server के retired `/assets/` images के लिए database tombstone और startup purge है, ताकि उसी पुराने file को अगली deploy से वापस serve न किया जाए। Cloudinary वाले पुराने images provider API से हटते हैं।
- दूसरे image-host की पुरानी URL वाली photo उस host के credentials के बिना वहाँ से delete नहीं की जा सकती; ऐसी deletion job में साफ error दिखेगा।
- नए signed uploads में `backup=false` है। पहले से बने provider backups या किसी visitor की डाउनलोड की हुई copy को इस website package से पूरी तरह मिटाने का दावा नहीं किया जा सकता। Cloudinary CDN invalidation में कुछ समय लग सकता है। आधिकारिक व्यवहार: https://cloudinary.com/documentation/image_upload_api_reference#destroy_method

## Migration में क्या होता है

- `catalog-v2.sql` versioned/idempotent migration है। पुराने parent products, numbered legacy pack records, customer data और order amounts/snapshots DELETE नहीं होते।
- मौजूदा numbered packs का rate, stock और visibility corresponding actual variants में जाते हैं; historical numbered-pack order items को उसी variant से link किया जाता है।
- Original seed-photo galleries केवल तभी सुधारती हैं जब संबंधित पुराने default path अभी database में है; administrator-selected photo override नहीं होती।
- पुराने parent orders में कौन सा pack था, यदि एक से अधिक variants के कारण पता नहीं चलता, तो अनुमान से कोई नया variant नहीं चुना जाता। ऐसे पुराने orders को manual reconciliation की जरूरत हो सकती है।
- बाद की restarts migration mapping/seed से नए rates, stock या photo को फिर overwrite नहीं करतीं।
- कोई backup file इस संशोधन के दौरान नहीं बनाई गई और live migration नहीं चलाई गई।

## जाँचें

- Included offline commands: `npm run check`, `npm run test:catalog`, `npm run test:security`। इनमें real orders/uploads/provider calls नहीं होते।
- अलग isolated PostgreSQL-compatible PGlite database पर migration, catalog CRUD, stock, COD checkout, retry idempotency, cancellation, photo replacement/deletion queue और logout revocation जाँचे गए।
- Desktop/mobile admin और mobile selected-pack cart को browser में जाँचा गया; upload/provider responses simulated थे। असली Cloudinary credentials और Google OAuth console इस environment में उपलब्ध नहीं थे।
- Razorpay credentials, connection और payment-provider flows इस काम में verify नहीं किए गए; उनकी existing integration छोड़ी गई है।


## कैटेगरी की कवर फोटो
Admin → Categories → Load categories. मौजूदा सातों कैटेगरी और प्रोडक्ट में दी गई नई कस्टम कैटेगरी उपलब्ध हैं। Change cover photo में JPG/PNG/WebP/AVIF (अधिकतम 8 MB) चुनें, प्रीव्यू देखें और Save category दबाएं। कार्ड पर दिखने वाला नाम और क्रम भी बदल सकते हैं। नाम केवल डिस्प्ले का है; प्रोडक्ट का category संबंध नहीं बदलता।
Delete cover photo दबाने से कवर हटता है; कैटेगरी/प्रोडक्ट नहीं मिटते। नई फोटो सफलतापूर्वक सेव होने के बाद पुरानी अनयूज्ड फोटो का रिकॉर्ड हटता है और Cloudinary deletion worker asset मिटाता है। साझा फोटो दूसरे पैक/कैटेगरी में इस्तेमाल हो तो सुरक्षित रहती है। लाइव Cloudinary credentials जरूरी हैं; वास्तविक provider deletion अभी सत्यापित नहीं है।
नई कवर सेटिंग वेबसाइट पर अगले catalog/cover refresh या पेज खोलने पर दिखती है (लगभग 30 सेकंड)। डेटा redeploy पर रीसेट नहीं होता।
Festival & About → Festival उसी होम पेज के माँ दुर्गा बैनर और क्लिक पर खुलने वाली दिनवार फोटो/कथा को बदलता है। Categories की सेटिंग उससे अलग है।
इस अपडेट में 38 API/database integration checks और 13 browser UI checks पास हुए; browser run के बाद admin logout का एक अतिरिक्त integration check भी पास हुआ। Provider calls tests में mock थे। लाइव deployment नहीं किया गया।


## Home Slider, स्वाइप और Company/Culture मीडिया अपडेट
- Admin → Home Slider: माँ दुर्गा/Festival के नीचे बड़ी प्रोडक्ट फोटो और डॉट्स वाला Carousel। Load slides, Change slide photo, प्रीव्यू और Save slide। नाम, क्रम और Visible भी बदलें। Add slide से नई स्लाइड बनाएं; Delete slide photo से फोटो हटाएं। फोटो के बिना स्लाइड वेबसाइट पर नहीं दिखती। यह प्रोडक्ट की पैक फोटो से अलग है।
- Product → कार्ड → Manage photos: Front/Back/Ingredients/Additional फोटो चुनें। एडमिन प्रीव्यू और ग्राहक की पैक फोटो में बाएं-दाएं स्वाइप, डॉट्स और Previous/Next उपलब्ध हैं। वजन बदलने पर उसी पैक की गैलरी आती है। Full-screen viewer में भी स्वाइप है; zoom होने पर drag फोटो को पैन करता है।
- Admin → Company & Culture Media: About My Company और About My Culture की घूमती गैलरी अलग हैं। सेक्शन चुनें, फोटो/वीडियो चुनकर प्रीव्यू देखें, नाम और क्रम भरें और Upload media दबाएं। हर सेक्शन में अधिकतम 50 फोटो और 10 वीडियो। फोटो अधिकतम 8 MB; वीडियो अधिकतम 25 MB और 30 सेकंड (5–10 सेकंड की वीडियो स्वीकार हैं)। MP4/WebM/MOV/M4V समर्थित, MP4 इस्तेमाल करें ताकि मोबाइल पर बेहतर चले। वीडियो पर controls हैं; वीडियो चलते समय गैलरी रुकती है। Delete image / Delete video से रिकॉर्ड हटता है और अनयूज्ड Cloudinary asset deletion queue में जाता है।
- Redeploy पर saved gallery और slider settings नहीं बदलतीं। वही live database और Cloudinary environment values रखें। नए Home Slider/Company/Culture विकल्प पाने के लिए इस नई website.tar.gz को deploy करें। render.yaml में इस पास में बदलाव नहीं है।
- वास्तविक लाइव स्थिति: अपडेट किया हुआ landscape admin और Categories लाइव दिखे। Admin status में Cloudinary configured और कोई pending deletion job नहीं दिखी। यह असली deletion सफल होने का प्रमाण नहीं है। Gud biscuit (Archived) के अंदर Hidden / stock 0 वाला अलग Cloudinary deletion TEST 20261012 pack बनाया गया; browser credential protection ने test photo chooser रोक दिया। मौजूदा फोटो नहीं हटाई गई; वास्तविक Cloudinary deletion अभी सत्यापित नहीं है।
- असली deletion की जाँच: अलग Hidden test pack में केवल disposable फोटो अपलोड करें, Delete photo दबाएं, फिर Check photo upload / deletion status देखें। Cloudinary Media Library में उस exact public ID को खोजकर asset गायब होने की पुष्टि करें। Jobs empty होना अकेले प्रमाण नहीं है; delete error हो तो status में दिखेगा और worker retry करेगा। API secret चैट में न भेजें।
- नए फीचर की जाँच: database/API और browser UI परीक्षण स्थानीय fixture में हुए; Cloudinary responses नकली थे। किसी provider पुराने backup या पहले से डाउनलोड की गई कॉपी के मिटने का दावा नहीं है।

इस पूरे पैकेज के अंतिम परिणाम: 50 API/database checks, 19 browser UI checks, 18 catalog assertions, 38 security assertions और 69 JavaScript syntax checks पास। Cloudinary network responses स्थानीय जाँच में mock थे।


## Invalid Signature सुधार
पुराना admin upload client केवल folder/timestamp भेज रहा था; नए सर्वर में allowed_formats/backup भी signed थे। नए admin assets के URL version बदले गए और dashboard का नया filename है। सभी फोटो/वीडियो uploads अब server-returned upload_params को भेजते हैं।
नई website.tar.gz deploy करें, पुराना admin tab बंद करके फिर खोलें। प्रोडक्ट पहले सेव हो चुका हो तो Add Product फिर न दबाएं। उस प्रोडक्ट का कार्ड → सही पैक → Manage photos से फोटो फिर अपलोड करें। Cloudinary keys और Render values इस error की वजह से न बदलें। लाइव upload/delete का सत्यापन अभी बाकी है।


## हटाई/छिपाई फोटो फिर दिखने का सुधार
लाइव public home-slides सूची खाली मिली, फिर भी पुराने slider fallback/cache से तस्वीर दिख सकती थी। नए slider का अलग filename, storefront scripts के नए version URL और bundled image fallback हटाए गए हैं। Slider, Categories और Company/Culture केवल saved API media पढ़ते हैं। पेज focus/वापस आने और लगभग 5 सेकंड में सूची refresh होती है; एक ही browser की अलग tabs में save पर सूचना से refresh होता है। खाली slider में फोटो/डॉट्स नहीं रहते। शुरुआती static category/culture फोटो भी हटाए गए, ताकि deleted फोटो सूची आने से पहले वापस न दिखें। saved DB images और पुराने product/photo records इस बदलाव से नहीं मिटते।
नई website.tar.gz deploy करें और पुराने वेबसाइट/एडमिन tabs बंद करके फिर खोलें। Render values वही रखें। Cloudinary deletion अभी लाइव खाते पर सत्यापित नहीं है; यह UI/API visibility सुधार है।

Admin media save/delete सफल होने और DB transaction commit के बाद server खुले storefront को media-change event भेजता है। पेज अपने आप saved सूची पढ़ता है। यह Home Slider, Categories और Company/Culture पर लागू है। कनेक्शन टूटने पर reconnect, focus और 5-second refresh fallback हैं; किसी agent की manual deletion पर निर्भरता नहीं है। Cloudinary physical cleanup worker अलग चलता है और failure पर retry/error status दिखता है।

इस सुधार की अंतिम जाँच: 52 API/database checks और 25 browser UI checks पास; actual signed upload parameter verification भी mock provider tests में शामिल है।


## Company/Culture visibility, category cover और पूरी स्लाइड डिलीट
- About My Company की अपलोड की हुई फोटो DB में थीं, लेकिन पुराने CSS ने गैलरी छिपाई थी। अब Company होम और Company foreground पेज दोनों पर दिखाई देती है। होम में About My Company (Right → Left) और About My Culture (Left → Right) अलग घूमती गैलरी हैं।
- Company/Culture में फोटो/वीडियो पर कोई admin name/caption नहीं दिखता। Admin label वैकल्पिक है और केवल प्रबंधन के लिए है। पुरानी saved फोटो फिर upload न करें।
- लाइव उत्पाद category 'Flavour makahna' थी, लेकिन cover 'Flavoured Makhana' में सेव था। इन स्पष्ट spelling aliases को canonical 'Flavoured Makhana' से जोड़ने का migration और future save normalization शामिल है। Uploaded canonical cover सुरक्षित रहता है; arbitrary custom categories अलग रहती हैं।
- Home Slider में Delete slide photo के अलावा Delete slide बटन है। उससे पूरा card/DB slide record हटता है, storefront को automatic event मिलता है और unused photo deletion queued होता है। केवल 4–5 slides रखना संभव है; 26 slides अनिवार्य नहीं। Shared product/category photo सुरक्षित रहती है। Deleted slides redeploy पर वापस seed नहीं होतीं।
- नई website.tar.gz deploy करें; वही DB और Render environment रखें। पुराने tabs बंद करके नए tabs खोलें ताकि नया script version आए। यह नई फ़ाइल का सुधार है, live deployment हमने नहीं किया। असली Cloudinary physical deletion अभी सत्यापित नहीं है।

लेआउट स्पष्टता: About My Company ऊपर और About Our Culture उसके ठीक नीचे अलग rows में हैं; Company दाएँ से बाएँ और Culture बाएँ से दाएँ चलता है।

इस अपडेट की अंतिम जाँच: 57 API/database checks और 30 browser UI checks पास। ग्राहक पेज पर category cover, Company gallery, ऊपर-नीचे दोनों rows, उलटी animation directions और बिना caption की फोटो दिखाई देने की जाँच हुई। Provider calls स्थानीय परीक्षण में mock थे।
