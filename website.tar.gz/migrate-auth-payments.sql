-- Run once on a database created from an older Mithilana schema.
-- Fresh databases only need schema.sql.
ALTER TABLE customers ALTER COLUMN phone DROP NOT NULL;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS google_sub varchar(255);
CREATE UNIQUE INDEX IF NOT EXISTS customers_google_sub_unique ON customers(google_sub);
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='customer_identity_required') THEN
    ALTER TABLE customers ADD CONSTRAINT customer_identity_required
      CHECK (phone IS NOT NULL OR google_sub IS NOT NULL);
  END IF;
END $$;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS razorpay_order_id varchar(100);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS razorpay_payment_id varchar(100);
CREATE UNIQUE INDEX IF NOT EXISTS orders_razorpay_order_unique ON orders(razorpay_order_id);
CREATE UNIQUE INDEX IF NOT EXISTS orders_razorpay_payment_unique ON orders(razorpay_payment_id);
