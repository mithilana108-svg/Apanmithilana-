# Mithilana security update — 10 October 2026

This archive contains fixes to the uploaded source. It has not been deployed to the existing Render website.

## Changes

- Reject unrelated browser origins with HTTP 403 instead of an internal error.
- Remove blanket inline JavaScript permission from CSP. Move 37 original script blocks to local assets, preserving execution order. Replace HTML click attributes with event listeners and update existing product navigation readers.
- Escape review names/text, stored cart text, search text and legacy receipt/tracking fields before HTML rendering. Validate image URL schemes and escape image attributes. Clamp review ratings.
- Check active admin status and current password hash for every authorized admin request. Old admin tokens are rejected, including after passwords change or accounts are disabled.
- Require distinct production JWT secrets of at least 32 bytes and enforced CSP. Existing Render-generated secrets normally meet this requirement.
- Verify database certificates in the admin creation utility. Limit new bcrypt passwords to 72 UTF-8 bytes and require at least 12 characters; apply the same limit during admin login and bootstrap.
- Reject unsigned Meta webhooks in every environment, validate exact signature format, and safely handle unequal UTF-8 byte lengths when comparing signatures.
- Reject fractional/boolean order quantities; rate-limit creation to 30 orders per customer per hour. Bound PIN-code cache size.
- Return generic JSON parser errors without reflecting malformed request contents. Refuse dotfile page paths.
- Fix an existing product-detail initialization timing error: bind its initial controls after the markup is ready.

The product photos, CSS, prices, and database schema/catalog are unchanged. Render database configuration remains unchanged: its supplied Blueprint uses an internal database connection with DB_SSL=false. For external database connections use DB_SSL=true and a valid trusted certificate; do not disable certificate verification to fix connection errors.

## Validation

- JavaScript syntax checks for server, scripts and extracted browser scripts.
- 44 automated security assertions covering account/admin access, origin enforcement, source-file restrictions, malformed JSON, Meta signatures, invalid cart quantities, disabled/changed-password admin sessions, payment amount/currency/status/order mismatches, and output escaping. Database and payment provider responses are mocked; these are not live provider tests.
- npm audit of the installed lockfile reported zero known vulnerabilities at review time. This is not a guarantee of absence of vulnerabilities.
- Frontend DOM simulation passed: product cards render, details open, add-to-cart/quantity/remove controls work, and injected review markup renders as text. No application script errors in this simulation. This does not test real browser CSP enforcement or provider popups.

Run locally after installing dependencies:

```sh
npm ci
npm run check
npm run test:security
```

## Deploy on the existing Render service

1. Keep a backup of the old source. Extract this archive and update the existing repository, including **all assets/secure-*.js** files. Deploy using the existing service rather than creating a new database.
2. Preserve existing database/provider environment values. Set NODE_ENV=production and CSP_MODE=enforce. Ensure JWT_SECRET and ADMIN_JWT_SECRET are distinct randomly generated secrets of at least 32 bytes each. Use PUBLIC_ORIGIN equal to the actual HTTPS website origin, without a trailing slash; Render hostname is the fallback.
3. Keep APP_MODE=test until Google login and Razorpay TEST payments have been tested. The live-mode environment checks are unchanged. Do not change provider credentials to live merely to deploy this update.
4. Admins must log in again. Existing admin tokens intentionally stop working. This update does not change admin passwords or migrate schema.
5. Test Google login, profile, product/category/search pages, add/remove/quantity controls, COD checkout, Razorpay success/failure/cancel flows, admin login and password changes, and signed webhook delivery. Confirm payments independently in the Razorpay dashboard and verify stored order totals.
6. Confirm the homepage response has script-src without unsafe-inline and the browser console has no blocked legitimate scripts. Styles still use unsafe-inline to preserve the current design. If provider behavior differs, adjust specific CSP sources rather than disabling CSP.

## Limits and follow-up

No live database or provider credentials were used. Real Google/WhatsApp/Razorpay interactions, deployment settings, database network restrictions/backups, and concurrent production transactions require staging/live verification. A full browser engine was unavailable in the review environment.

Customer tokens remain in localStorage and admin tokens in sessionStorage to preserve the existing authentication flow. They are JavaScript-accessible: a future migration to server-managed HttpOnly sessions would reduce the consequences of an XSS issue. Customer logout removes the local token but does not revoke a stolen copy before its existing expiration. Per-instance in-memory rate limits should be replaced with a shared store if deploying multiple instances. Unpaid orders still reserve stock until cancellation; automatic expiry/idempotency and broader fraud controls are separate follow-ups.

This is a targeted security hardening review, not a penetration-test certificate or a promise that the site is fully secure.
