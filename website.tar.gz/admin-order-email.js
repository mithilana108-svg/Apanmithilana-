'use strict';
// Admin-only notifications. No customer email addresses are used.
function config(){return {key:process.env.RESEND_API_KEY,from:process.env.ORDER_ALERT_FROM,to:process.env.ADMIN_ORDER_EMAIL};}
function enabled(){const c=config();return !!(c.key&&c.from&&/^\S+@\S+\.\S+$/.test(c.to||''));}
async function queue(client,orderId){if(enabled())await client.query('INSERT INTO admin_email_outbox(order_id) VALUES($1) ON CONFLICT(order_id) DO NOTHING',[orderId]);}
async function sendPending(pool){
 if(!pool||!enabled())return;
 const c=config(),client=await pool.connect();
 try{
  await client.query('BEGIN');
  const q=await client.query(`SELECT n.order_id,n.attempts,o.shipping_name,o.total_amount,o.status,o.payment_method
   FROM admin_email_outbox n JOIN orders o ON o.id=n.order_id
   WHERE n.state='pending' AND n.next_attempt_at<=NOW() ORDER BY n.created_at LIMIT 3 FOR UPDATE OF n SKIP LOCKED`);
  for(const o of q.rows){
   try{
    const items=await client.query('SELECT product_name,quantity,line_total FROM order_items WHERE order_id=$1 ORDER BY created_at',[o.order_id]);
    const origin=(process.env.PUBLIC_ORIGIN||(process.env.RENDER_EXTERNAL_HOSTNAME?'https://'+process.env.RENDER_EXTERNAL_HOSTNAME:'')).replace(/\/+$/,'');
    const subject=(process.env.APP_MODE==='test'?'[TEST] ':'')+'Mithilana: new order #'+o.order_id.slice(0,8);
    const text=[subject,'Order ID: '+o.order_id,'Customer: '+(o.shipping_name||'Customer'),'Status: '+o.status,'Payment method: '+o.payment_method,'Total: INR '+Number(o.total_amount).toFixed(2),'',...items.rows.map(i=>i.product_name+' × '+i.quantity+' — INR '+Number(i.line_total).toFixed(2)),'',origin?'Manage order: '+origin+'/admin.html':'Open your Mithilana admin panel.'].join('\n');
    const r=await fetch('https://api.resend.com/emails',{method:'POST',signal:AbortSignal.timeout(10000),headers:{Authorization:'Bearer '+c.key,'Content-Type':'application/json','Idempotency-Key':'mithilana-admin-order-'+o.order_id},body:JSON.stringify({from:c.from,to:[c.to],subject,text})});
    if(!r.ok)throw Error('Email provider HTTP '+r.status);
    const result=await r.json();if(!result.id)throw Error('Email provider returned no message ID');
    await client.query("UPDATE admin_email_outbox SET state='sent',sent_at=NOW(),attempts=attempts+1 WHERE order_id=$1",[o.order_id]);
   }catch(e){const delay=Math.min(3600,30*2**Math.min(o.attempts,7));await client.query("UPDATE admin_email_outbox SET attempts=attempts+1,next_attempt_at=NOW()+($2::integer*INTERVAL '1 second') WHERE order_id=$1",[o.order_id,delay]);console.error('Admin email alert will retry:',o.order_id,e.name);}
  }
  await client.query('COMMIT');
 }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e;}finally{client.release();}
}
module.exports={queue,sendPending,enabled};
