# v3.1 — bug fixes and security hardening (8 Oct 2026)

Changed: `server.js`, `index.html` (login window), `.env.example`, `render*.yaml`, `package.json` and the Hindi setup note. Database schema is untouched.

## Bugs fixed
1. **Source code was downloadable.** The whole folder was served publicly. Now only `index.html`, `admin.html`, `privacy.html`, `refund-cancellation.html` and `/assets` are served; `/server.js`, `/schema.sql`, `/scripts/*` and notes return 404.
2. **Login lockouts.** OTP request, OTP verify and Google login each have their own rate limit (5 / 20 / 20 per 15 min per IP) instead of one shared limit of 5.
3. **Test-mode cancel no longer adds fake stock.**
4. **Bad IDs return 404/400**, not "Server error". Duplicate values return 409.
5. **Admin product and offer edits are validated** (name, slug, price, stock, true/false fields, dates, percent coupons capped at 100). Empty/null prices are no longer accepted as 0.
6. **Razorpay is called before any database locks**, so slow payment calls no longer block other customers. If prices change in between, the order is refused and the customer retries.
7. **Money is calculated in whole paise.** Percent coupons could previously create a 1-paisa mismatch between the saved total and the Razorpay amount, leaving a paid order stuck. Fixed.
8. Stock deduction is guarded (`stock >= qty`) so it can never go negative.
9. Image URL errors in admin give a clear message instead of a 500.

## Data security added
- Content-Security-Policy turned on (scripts only from this site, Google sign-in and Razorpay; no other servers can receive data). `CSP_MODE=report-only` or `off` if it ever blocks something.
- OTP codes are stored as a keyed hash (secret pepper from `JWT_SECRET`), so a leaked database cannot reveal them.
- JWT algorithm pinned to HS256. Admin login takes the same time whether or not the email exists.
- All `/api` responses are `Cache-Control: no-store`.
- Only known address fields (length-limited) are saved on orders.
- Razorpay payment records keep only reconciliation fields (no card, email or phone data).
- Expired OTP rows are deleted hourly and WhatsApp webhook payloads after 90 days.
- Error logs no longer print request data.
- `AUTO_CONFIRM_SECONDS` (new, default 5; 0 = off) lets you review orders before they auto-confirm.

## Not changed (needs real Razorpay/Meta testing, or a schema change)
Online-payment refunds, automatic expiry of unpaid orders, coupon usage limits.

## Before going live
Run through login (OTP + Google), COD, Razorpay test payment and the admin page once on the test site. Existing OTPs requested before the upgrade stop working (5-minute lifetime).

## Login is Google-only (added)
- WhatsApp/OTP login removed from the site and the server (`/api/auth/request-otp` and `/api/auth/verify-otp` no longer exist). The login window shows only the Google button.
- `WHATSAPP_OTP_TEMPLATE` and `WHATSAPP_TEMPLATE_LANGUAGE` settings are gone. WhatsApp is still used for order-status messages.
- **`GOOGLE_CLIENT_ID` is now required for anyone to log in or order.** The server prints a warning at start if it is missing.
- Google customers give their mobile number at checkout (already required there).
- Customers who earlier signed up with a phone number only cannot log in with Google into the same account (Google accounts are never auto-merged by email). Their old orders stay in the database but are not visible to them.
- Old OTP data (saved phone number in the browser, leftover database rows) is cleaned up automatically.
