'use strict';
const crypto=require('crypto'),lifecycle=require('./image-lifecycle');
const {transaction}=require('./catalog-v2');
const fail=(message,status=400)=>Object.assign(new Error(message),{status});
async function assetFor(id){const cloud=process.env.CLOUDINARY_CLOUD_NAME,key=process.env.CLOUDINARY_API_KEY,secret=process.env.CLOUDINARY_API_SECRET;if(!cloud||!key||!secret)throw fail('Cloudinary is not configured.',503);if(!/^mithilana\/products\/[a-zA-Z0-9_\/-]{1,180}$/.test(id))throw fail('Invalid image ID.');const r=await fetch(`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/resources/image/upload/${id.split('/').map(encodeURIComponent).join('/')}`,{headers:{Authorization:'Basic '+Buffer.from(key+':'+secret).toString('base64')},signal:AbortSignal.timeout(10000)});if(!r.ok)throw fail('Could not verify uploaded slide.');const a=await r.json();if(a.public_id!==id||a.resource_type!=='image'||a.type!=='upload'||!a.secure_url?.startsWith('https://res.cloudinary.com/'))throw fail('Invalid slide asset.');lifecycle.validateAsset(a);return a}
function register(app,{requireDb,requireAdmin}){
 const list=admin=>async(req,res,next)=>{try{res.setHeader('Cache-Control','no-store');res.json({slides:(await requireDb().query('SELECT * FROM home_slides'+(admin?'':' WHERE is_active=true AND image_url IS NOT NULL')+' ORDER BY sort_order,id')).rows})}catch(e){next(e)}};
 app.get('/api/home-slides',list(false));app.get('/api/admin/home-slides',requireAdmin,list(true));
 app.put('/api/admin/home-slides',requireAdmin,async(req,res,next)=>{try{
 const b=req.body,id=b.id||crypto.randomUUID(),name=String(b.name||'').trim(),order=Number(b.sort_order),version=Number(b.expected_version??0),remove=b.remove_image===true;
 if(!/^[0-9a-f-]{36}$/i.test(id)||!name||name.length>200||!Number.isInteger(order)||order<0||order>10000||!Number.isInteger(version)||version<0||typeof b.is_active!=='boolean'||(remove&&b.public_id))throw fail('Enter a slide name, order, visibility and current version.');
 const asset=b.public_id?await assetFor(String(b.public_id)):null;
 const slide=await transaction(requireDb(),async c=>{await c.query('SELECT pg_advisory_xact_lock(hashtext($1))',['slide:'+id]);let old=(await c.query('SELECT * FROM home_slides WHERE id=$1 FOR UPDATE',[id])).rows[0];if(b.id&&!old)throw fail('Slide not found.',404);if(old&&old.version!==version)throw fail('Slide changed. Load slides again before saving.',409);if(!old){const count=await c.query('SELECT count(*)::int n FROM home_slides');if(count.rows[0].n>=100)throw fail('Maximum 100 slides.');await c.query('INSERT INTO home_slides(id,name) VALUES($1,$2)',[id,name]);old=(await c.query('SELECT * FROM home_slides WHERE id=$1',[id])).rows[0]}
 if(asset){await c.query('SELECT pg_advisory_xact_lock(hashtext($1))',[asset.secure_url]);if((await c.query('SELECT image_url FROM retired_asset_urls WHERE image_url=$1',[asset.secure_url])).rowCount)throw fail('Photo deleted. Upload a fresh image.')}
 const r=await c.query('UPDATE home_slides SET name=$2,sort_order=$3,is_active=$4,image_url=$5,cloud_public_id=$6,version=version+1 WHERE id=$1 RETURNING *',[id,name,order,b.is_active,remove?null:asset?asset.secure_url:old.image_url,remove?null:asset?asset.public_id:old.cloud_public_id]);if(old.image_url&&(remove||(asset&&asset.secure_url!==old.image_url)))await lifecycle.retire(c,[old]);return r.rows[0]});res.json({ok:true,slide});
 }catch(e){next(e)}});
}
module.exports={register};
